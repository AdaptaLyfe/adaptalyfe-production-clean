import XCTest
@testable import SplashScreenPlugin

class SplashScreenTests: XCTestCase {
}
