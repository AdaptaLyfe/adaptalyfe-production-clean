export declare const Capacitor: import("./definitions").CapacitorGlobal;
export declare const registerPlugin: import("./definitions").RegisterPlugin;
