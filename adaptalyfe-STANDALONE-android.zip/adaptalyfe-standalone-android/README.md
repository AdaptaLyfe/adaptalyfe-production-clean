# Adaptalyfe Standalone Android Build

**Build Date:** November 6, 2025  
**Version:** Clean build - No Replit dependencies  
**Production URL:** https://app.getadaptalyfeapp.com

## What's Included

This standalone Android build package contains:

1. **android/** - Complete Android Studio project
2. **capacitor-plugins/** - All Capacitor plugin source code (@capacitor)
   - @capacitor/app
   - @capacitor/haptics
   - @capacitor/keyboard
   - @capacitor/splash-screen
   - @capacitor/status-bar

## Latest Updates

✅ Removed all Replit dependencies  
✅ Fixed CORS configuration for Railway production  
✅ Added aggressive no-cache headers  
✅ Clean CSP headers (only Stripe.js allowed)  
✅ Synced with latest web build (index-DoYwBJC0.js)

## How to Use in Android Studio

### Step 1: Open Project
1. Extract this ZIP file
2. Open **Android Studio**
3. Click **"Open"** (not "New Project")
4. Navigate to the extracted `android` folder
5. Click **"OK"**

### Step 2: Gradle Sync
Android Studio will automatically:
- Detect the Capacitor plugins from `capacitor-plugins/` folder
- Sync Gradle dependencies
- Build the project

### Step 3: Build APK
1. **Menu:** Build → Build Bundle(s) / APK(s) → Build APK(s)
2. **Wait:** Build process takes 2-5 minutes
3. **Success:** APK generated in `android/app/build/outputs/apk/debug/`

### Step 4: Install on Device
```bash
adb install android/app/build/outputs/apk/debug/app-debug.apk
```

## Production Configuration

The app is configured to connect to:
- **Backend:** https://app.getadaptalyfeapp.com
- **Database:** External Neon PostgreSQL (managed by Railway)

### App Configuration (capacitor.config.ts)
```json
{
  "appId": "com.adaptalyfe.app",
  "appName": "Adaptalyfe",
  "webDir": "public",
  "server": {
    "url": "https://app.getadaptalyfeapp.com",
    "cleartext": true
  }
}
```

## Required Permissions

The app requests these Android permissions:
- ✅ INTERNET (for API calls)
- ✅ CAMERA (for photo uploads)
- ✅ READ/WRITE_EXTERNAL_STORAGE (for file uploads)
- ✅ ACCESS_FINE_LOCATION (for location features)
- ✅ VIBRATE (for haptic feedback)

All permissions are configured in `android/app/src/main/AndroidManifest.xml`

## Troubleshooting

### Build Errors
If you get Capacitor plugin errors:
1. Ensure `capacitor-plugins/` folder is in the same directory as `android/`
2. File → Invalidate Caches / Restart in Android Studio
3. Rebuild project

### Runtime Errors
- Check that your device has internet connection
- Verify backend is running: https://app.getadaptalyfeapp.com/api/health
- Check logcat for error messages

## App Store Deployment

For production release:
1. **Build signed APK/AAB** (Build → Generate Signed Bundle/APK)
2. **Create keystore** if you don't have one
3. **Upload to Google Play Console**
4. **Submit for review**

See `MOBILE_DEPLOYMENT_GUIDE.md` in the main repository for detailed instructions.

## Support

For issues or questions:
- Production App: https://app.getadaptalyfeapp.com
- GitHub: https://github.com/Adaptalyfe/adaptalyfe-production-clean

---

**Built with:** React + TypeScript + Capacitor + Express + PostgreSQL  
**Target Platform:** Android 7.0+ (API Level 24+)
