# Adaptalyfe - Standalone Android Project

This is a **standalone Android project** that can be opened directly in Android Studio.

## 📱 App Information

- **App Name:** Adaptalyfe
- **Package ID:** com.adaptalyfe.app
- **Production URL:** https://app.getadaptalyfeapp.com
- **Capacitor Version:** 7.x

## 🚀 Quick Start

### 1. Open in Android Studio

1. Extract this ZIP file to a folder
2. Open **Android Studio**
3. Click **File → Open**
4. Navigate to the `android` folder inside this extracted folder
5. Click **OK**

### 2. Wait for Gradle Sync

- Android Studio will automatically sync Gradle dependencies
- This may take 2-5 minutes on first open
- Wait for "Gradle sync complete" message

### 3. Run the App

1. Connect an Android device (with USB debugging enabled) **OR** start an Android emulator
2. Click the green **Play button (▶)** in the toolbar
3. Select your device from the dropdown
4. The app will build, install, and launch automatically

## 📦 What's Included

```
adaptalyfe-standalone/
├── android/                         ← Main Android project (open this in Android Studio)
│   ├── app/
│   │   ├── src/main/
│   │   │   ├── assets/public/      ← Your web app
│   │   │   ├── java/               ← Android app code
│   │   │   ├── res/                ← Icons, splash screens
│   │   │   └── AndroidManifest.xml
│   │   └── build.gradle
│   ├── gradlew                      ← Gradle wrapper (Linux/Mac)
│   ├── gradlew.bat                  ← Gradle wrapper (Windows)
│   └── build.gradle
├── node_modules/@capacitor/         ← Capacitor plugin source code
│   ├── android/
│   ├── app/
│   ├── haptics/
│   ├── keyboard/
│   ├── splash-screen/
│   └── status-bar/
├── capacitor.config.ts              ← Capacitor configuration
└── README.md                        ← This file
```

## 🔧 Build APK

### Debug Build (For Testing)

**In Android Studio:**
1. Build → Build Bundle(s) / APK(s) → Build APK(s)
2. Wait for build to complete
3. APK location: `android/app/build/outputs/apk/debug/app-debug.apk`

**Or using Command Line:**
```bash
cd android
./gradlew assembleDebug
```

### Release Build (For Production)

**In Android Studio:**
1. Build → Generate Signed Bundle / APK
2. Choose **APK** or **AAB** (for Play Store)
3. Create or select your keystore
4. Choose **release** build variant
5. Click **Finish**

**Important:** Keep your keystore file safe! You'll need it for all future app updates.

## ✅ Pre-configured Features

- ✅ Production server: `https://app.getadaptalyfeapp.com`
- ✅ Splash screen with Adaptalyfe branding
- ✅ App icons (all sizes)
- ✅ Status bar styling
- ✅ Keyboard management
- ✅ Haptic feedback support
- ✅ All permissions configured

## 📱 System Requirements

- **Android Studio:** Flamingo or newer (latest recommended)
- **JDK:** 11 or newer (bundled with Android Studio)
- **Android SDK:** API 21+ (Android 5.0 Lollipop or higher)
- **RAM:** Minimum 8GB, 16GB recommended
- **Storage:** 10GB free space

## 🆘 Troubleshooting

### "SDK not found"
**Solution:** Android Studio → Tools → SDK Manager → Install Android SDK (API 21+)

### "Gradle sync failed"
**Solution:** File → Invalidate Caches → Restart

### "Device not detected"
**Solution:** 
1. Enable Developer Options on your Android device:
   - Settings → About Phone → Tap "Build Number" 7 times
2. Enable USB Debugging:
   - Settings → Developer Options → USB Debugging (ON)
3. Reconnect device and authorize the computer

### "Build failed"
**Solution:** 
1. Build → Clean Project
2. Build → Rebuild Project

### Missing Capacitor plugins error
**Solution:** This package includes all necessary Capacitor plugins in `node_modules/@capacitor/`. Make sure you opened the entire extracted folder structure in Android Studio, not just the `android` subfolder.

## 📝 Notes

- This is a **hybrid app** - it loads a web app from the production server
- The web app runs inside a native WebView with Capacitor plugins
- All app logic and UI is served from: `https://app.getadaptalyfeapp.com`
- No internet connection = app won't work (except cached pages)

## 🔐 Play Store Submission

1. Build a signed **AAB** (Android App Bundle)
2. Go to: https://play.google.com/console
3. Create new app or select existing app
4. Upload the AAB file
5. Fill in app details (description, screenshots, etc.)
6. Submit for review

## 📞 Support

If you encounter issues:
1. Check this README first
2. Clean and rebuild the project
3. Check Android Studio logs (Logcat)

---

**Built with Capacitor 7.x**
**Server: https://app.getadaptalyfeapp.com**
