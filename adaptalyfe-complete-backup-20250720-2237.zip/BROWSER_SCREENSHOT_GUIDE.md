# Perfect iPhone Screenshots Using Browser Tools

## Method 1: Chrome Developer Tools (Recommended)

### Step-by-Step Instructions:

1. **Open Chrome and go to your app**: www.adaptalyfeapp.com

2. **Open Developer Tools**: 
   - Press `F12` or `Ctrl+Shift+I` (Windows)
   - Or `Cmd+Option+I` (Mac)

3. **Enable Device Simulation**:
   - Click the **device/mobile icon** in the toolbar (looks like a phone/tablet)
   - Or press `Ctrl+Shift+M` / `Cmd+Shift+M`

4. **Set Custom Device Size**:
   - Click the device dropdown (probably says "Responsive")
   - Select **"Edit..."** at the bottom
   - Click **"Add custom device"**
   - Enter these exact settings:
     - **Device Name**: iPhone 15 Pro Max
     - **Width**: 1290
     - **Height**: 2796
     - **Device pixel ratio**: 1
     - **User agent**: Mobile

5. **Take Screenshot**:
   - Right-click anywhere on the page
   - Select **"Capture screenshot"**
   - Or press `Ctrl+Shift+P` / `Cmd+Shift+P` and type "screenshot"
   - Select **"Capture full size screenshot"**

## Method 2: Safari (Mac Users)

1. **Enable Developer Menu**:
   - Safari > Preferences > Advanced
   - Check "Show Develop menu in menu bar"

2. **Set Device Size**:
   - Go to www.adaptalyfeapp.com
   - Develop > Enter Responsive Design Mode
   - Set width to **1290** and height to **2796**

3. **Take Screenshot**:
   - Cmd+Shift+4 and select the viewport area
   - Or use Web Inspector screenshot tool

## Method 3: Firefox Developer Tools

1. **Open Developer Tools**: `F12`
2. **Click Responsive Design Mode**: Icon that looks like a phone
3. **Set Custom Size**: 1290 × 2796
4. **Take Screenshot**: Settings menu > "Take a screenshot"

## Method 4: Online Alternative - ResponsivelyApp

If browser methods don't work:

1. **Download ResponsivelyApp**: https://responsively.app/
2. **Set custom device**: 1290 × 2796
3. **Enter URL**: www.adaptalyfeapp.com
4. **Screenshot tool** built-in

## Key Points for Perfect Screenshots

### Exact Dimensions Required:
- **iPhone 6.7"**: 1290 × 2796 pixels
- **No approximations** - must be exact
- **Portrait orientation only**

### Screenshot Content Tips:
1. **Dashboard page** - Show main interface
2. **Daily tasks** - Show task management
3. **Medical section** - Show health features
4. **Student planner** - Show academic tools
5. **Emergency features** - Show safety options

### File Requirements:
- **Format**: PNG (preferred) or JPEG
- **Size**: Under 8MB each
- **Color**: RGB color space
- **Quality**: High resolution, crisp text

## Verification Steps

Before uploading to Apple:

1. **Check file dimensions**:
   - Right-click file > Properties/Get Info
   - Verify exactly 1290 × 2796 pixels

2. **Test upload**:
   - Try uploading one screenshot first
   - If Apple accepts it, dimensions are correct

3. **File naming**:
   - Use descriptive names: `dashboard.png`, `tasks.png`, etc.

## If You're Still Having Issues

**Alternative approach**:
1. Use any device size close to iPhone 15 Pro Max
2. Take screenshots at high resolution
3. Use image editing software (like GIMP, free) to:
   - Resize canvas to exactly 1290 × 2796
   - Position your screenshot content properly
   - Export as PNG

The key is getting those exact pixel dimensions - Apple's system is very strict about this requirement.