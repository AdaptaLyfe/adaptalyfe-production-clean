// School Therapist Permission Setup Demo
// This demonstrates how to set up granular permissions for a school therapist

const apiRequest = async (method, endpoint, data) => {
  const response = await fetch(`http://localhost:5000${endpoint}`, {
    method,
    headers: { 'Content-Type': 'application/json' },
    credentials: 'include',
    body: data ? JSON.stringify(data) : undefined
  });
  return response.json();
};

async function setupSchoolTherapistPermissions() {
  const userId = 1; // Alex (demo user)
  const caregiverId = 2; // School therapist caregiver ID

  console.log('🎯 Setting up School Therapist Permission Scenario...\n');

  // STEP 1: Lock Academic Progress Settings (ALLOW ACCESS)
  const academicSettings = [
    {
      settingKey: "academic_progress_tracking",
      settingValue: "enabled",
      lockReason: "School therapist needs access to academic performance data for educational support",
      canUserView: true
    },
    {
      settingKey: "assignment_completion_tracking", 
      settingValue: "enabled",
      lockReason: "Required for monitoring academic task completion and providing support",
      canUserView: true
    },
    {
      settingKey: "study_session_monitoring",
      settingValue: "enabled", 
      lockReason: "Therapist needs to track study patterns for academic intervention planning",
      canUserView: true
    }
  ];

  // STEP 2: Lock Mood Tracking (ALLOW ACCESS)
  const moodSettings = [
    {
      settingKey: "mood_tracking_access",
      settingValue: "enabled",
      lockReason: "School therapist requires mood data for emotional support and intervention planning",
      canUserView: true
    },
    {
      settingKey: "emotional_wellness_monitoring",
      settingValue: "enabled",
      lockReason: "Essential for providing appropriate therapeutic support in educational environment",
      canUserView: true
    }
  ];

  // STEP 3: Hide Financial Information (NO ACCESS)
  const financialSettings = [
    {
      settingKey: "financial_monitoring",
      settingValue: "disabled",
      lockReason: "Financial information not relevant for educational therapy - privacy protection",
      canUserView: false // USER CANNOT EVEN SEE THIS SETTING
    },
    {
      settingKey: "banking_access",
      settingValue: "disabled",
      lockReason: "Banking data restricted to family members only",
      canUserView: false
    },
    {
      settingKey: "budget_tracking_visibility",
      settingValue: "disabled", 
      lockReason: "Budget information not within scope of educational therapy",
      canUserView: false
    }
  ];

  // STEP 4: Hide Medical Information (NO ACCESS)
  const medicalSettings = [
    {
      settingKey: "medication_management",
      settingValue: "disabled",
      lockReason: "Medical information restricted to healthcare providers and family",
      canUserView: false
    },
    {
      settingKey: "medical_appointments_access",
      settingValue: "disabled",
      lockReason: "Healthcare appointments outside scope of educational therapy",
      canUserView: false
    }
  ];

  // STEP 5: Hide Location Tracking (NO ACCESS)
  const locationSettings = [
    {
      settingKey: "location_sharing",
      settingValue: "disabled",
      lockReason: "Location tracking not necessary for school-based therapy sessions",
      canUserView: false
    },
    {
      settingKey: "geofencing_alerts",
      settingValue: "disabled",
      lockReason: "Location alerts restricted to primary caregivers for safety",
      canUserView: false
    }
  ];

  // Apply all settings
  const allSettings = [
    ...academicSettings, 
    ...moodSettings, 
    ...financialSettings, 
    ...medicalSettings, 
    ...locationSettings
  ];

  console.log('📋 Applying permission settings...\n');

  for (const setting of allSettings) {
    try {
      const lockData = {
        userId,
        settingKey: setting.settingKey,
        settingValue: setting.settingValue,
        isLocked: true,
        lockedBy: caregiverId,
        lockReason: setting.lockReason,
        canUserView: setting.canUserView
      };

      const result = await apiRequest('POST', '/api/locked-settings', lockData);
      
      const accessLevel = setting.canUserView ? '✅ VISIBLE' : '❌ HIDDEN';
      const permission = setting.settingValue === 'enabled' ? 'ALLOWED' : 'BLOCKED';
      
      console.log(`${accessLevel} | ${permission} | ${setting.settingKey}`);
      console.log(`   Reason: ${setting.lockReason}\n`);
    } catch (error) {
      console.error(`Failed to set ${setting.settingKey}:`, error);
    }
  }

  console.log('🎓 School Therapist Permission Setup Complete!\n');
  console.log('SUMMARY:');
  console.log('✅ CAN ACCESS: Academic progress, mood tracking, emotional wellness');
  console.log('❌ CANNOT ACCESS: Financial data, medical records, location tracking');
  console.log('👁️ HIDDEN: Settings user cannot even see are completely hidden');
  console.log('\nThe therapist now has precisely the information needed for educational support while protecting sensitive family data.');
}

// Run the setup
setupSchoolTherapistPermissions().catch(console.error);