# CodeMagic Build Error Fixes

## Common Build Issues and Solutions

### 1. Missing Provisioning Profile
**Make sure you've uploaded BOTH files:**
- ✅ Distribution Certificate: `ADAPTALYFE_DISTRIBUTION_CERT`
- ❓ Provisioning Profile: `ADAPTALYFE_APP_STORE_PROFILE`

**Upload the provisioning profile:**
1. Go to Team settings → Code signing identities
2. Click "Add provisioning profile"
3. Reference name: `ADAPTALYFE_APP_STORE_PROFILE`
4. Upload: `AdaptaLyfe_App_Store_Distribution (3).mobileprovision`

### 2. Bundle ID Mismatch
**Verify your provisioning profile matches:**
- Bundle ID in provisioning profile: `com.adaptalyfe.app`
- Bundle ID in Capacitor config: `com.adaptalyfe.app`
- Bundle ID in Xcode project: `com.adaptalyfe.app`

### 3. Certificate Password Issues
**If certificate upload fails:**
- Password: `adaptalyfe2025`
- Make sure there are no extra spaces
- Re-upload the .p12 file if needed

### 4. Build Configuration
**Updated codemagic.yaml includes:**
- CocoaPods installation
- Proper code signing setup
- Enhanced error logging
- Correct build flags

### 5. Node.js Version
**Changed to Node 18 for better compatibility**

## Next Steps:
1. Upload the provisioning profile with reference name `ADAPTALYFE_APP_STORE_PROFILE`
2. Start a new build
3. Check build logs for specific errors
4. The updated configuration should resolve most common issues

## If Build Still Fails:
- Check the build logs in CodeMagic
- Verify all certificates are valid and not expired
- Ensure the provisioning profile contains your distribution certificate
- Contact CodeMagic support with specific error messages