# GitHub Repository Update Guide

## Current Files to Update:
- `codemagic.yaml` (updated build configuration)
- `Adaptalyfe_Distribution.p12` (iOS certificate)
- `AdaptaLyfe_App_Store_Distribution (3).mobileprovision` (provisioning profile)
- All new documentation files (*.md guides)

## Option 1: Update via GitHub Web Interface

### Upload Updated Files:
1. **Go to your GitHub repository**
2. **Click "Add file" → "Upload files"**
3. **Drag and drop these files:**
   - `codemagic.yaml`
   - `Adaptalyfe_Distribution.p12`
   - `AdaptaLyfe_App_Store_Distribution (3).mobileprovision`
   - All new `.md` files

### Delete Old Files (if needed):
1. **Navigate to the old file** in GitHub
2. **Click the file** → **Delete button** (trash icon)
3. **Commit the deletion**

## Option 2: Download and Re-upload

### Download Updated Files from Replit:
1. **Right-click each file** in Replit file explorer
2. **Select "Download"**
3. **Save to your computer**

### Upload to GitHub:
1. **Go to GitHub repository**
2. **Upload the downloaded files**
3. **Commit changes**

## Option 3: Git Commands (if repository is properly configured)

```bash
# Remove git lock (already done)
rm -f .git/index.lock

# Add remote repository (replace with your GitHub URL)
git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPO.git

# Add all changes
git add .

# Commit changes
git commit -m "Updated iOS certificates and CodeMagic configuration"

# Push to GitHub
git push origin main
```

## Key Files to Update:
✅ `codemagic.yaml` - Simplified build configuration
✅ Certificate files - Ready for CodeMagic
✅ Documentation - Setup guides and troubleshooting

The easiest method is **Option 1** - using GitHub's web interface to upload the updated files directly.