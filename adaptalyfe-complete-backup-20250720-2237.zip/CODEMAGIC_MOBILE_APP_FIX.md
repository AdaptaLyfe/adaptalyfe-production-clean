# CodeMagic Mobile App Detection Fix

## Common Issue: CodeMagic Not Detecting Mobile App

If CodeMagic shows "No mobile apps detected" or similar errors, try these fixes:

### 1. Verify Project Structure
CodeMagic needs to detect this as a mobile project. Check that you have:
- ✅ `ios/` directory
- ✅ `capacitor.config.ts` 
- ✅ `package.json` with Capacitor dependencies

### 2. Alternative Build Configuration
Replace the current codemagic.yaml with this simplified version:

```yaml
workflows:
  ios-workflow:
    name: Adaptalyfe iOS Build
    max_build_duration: 120
    instance_type: mac_mini_m1
    environment:
      ios_signing:
        distribution_type: app_store
        bundle_identifier: com.adaptalyfe.app
      vars:
        CAPACITOR_PROJECT: "true"
      node: 18
      xcode: latest
      cocoapods: default
    scripts:
      - name: Install dependencies
        script: |
          npm install
          npm install @capacitor/cli @capacitor/core @capacitor/ios
      - name: Build web app
        script: |
          npm run build
      - name: Initialize Capacitor iOS
        script: |
          npx cap add ios || echo "iOS already added"
          npx cap sync ios
      - name: Install CocoaPods
        script: |
          cd ios/App && pod install
      - name: Build iOS
        script: |
          xcode-project build-ipa \
            --workspace "ios/App/App.xcworkspace" \
            --scheme "App"
    artifacts:
      - build/ios/ipa/*.ipa
```

### 3. Check Bundle ID Consistency
Verify these match exactly:
- Capacitor config: `com.adaptalyfe.app`
- Xcode project: `com.adaptalyfe.app`
- Provisioning profile: `com.adaptalyfe.app`
- CodeMagic signing: `com.adaptalyfe.app`

### 4. Manual Capacitor Sync
If the build fails on Capacitor sync:
```bash
npx cap sync ios --force
```

### 5. Check Certificate References
In CodeMagic Team settings, verify:
- Certificate reference: `ADAPTALYFE_DISTRIBUTION_CERT`
- Provisioning profile reference: `ADAPTALYFE_APP_STORE_PROFILE`

## What's the Specific Error?
To provide targeted help, share the exact error message from CodeMagic build logs.

Common error patterns:
- "No mobile apps detected" → Project structure issue
- "Code signing failed" → Certificate/profile issue  
- "Workspace not found" → Path issue
- "Pod install failed" → Dependencies issue