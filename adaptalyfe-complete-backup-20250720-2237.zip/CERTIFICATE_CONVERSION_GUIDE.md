# Convert Apple Certificate to .p12 Format

## The Problem
Downloaded Apple certificates (.cer files) don't open directly and need to be converted to .p12 format for CodeMagic.

## Solution: Use the Converter Script

I created a Python script to handle the conversion automatically.

### Step 1: Place Your Files
1. **Download** your Apple Distribution Certificate (.cer file) from Apple Developer
2. **Place** the .cer file in your project directory (same folder as this README)
3. **Ensure** `adaptalyfe_private.key` is present (I generated this earlier)

### Step 2: Run the Converter
```bash
python3 convert_certificate.py
```

The script will:
- Find your .cer file automatically
- Use the private key I generated
- Convert to .p12 format
- Set a password for CodeMagic

### Step 3: Upload to CodeMagic
You'll get:
- `Adaptalyfe_Distribution.p12` file
- Password for the certificate
- Instructions for CodeMagic upload

## Alternative: Manual Conversion (if script fails)

```bash
# Install OpenSSL if needed
sudo apt install openssl

# Convert certificate
openssl pkcs12 -export \
  -out Adaptalyfe_Distribution.p12 \
  -in YourCertificate.cer \
  -inkey adaptalyfe_private.key \
  -name "Adaptalyfe Distribution" \
  -passout pass:yourpassword
```

## Files You Need for CodeMagic
1. **Certificate:** `Adaptalyfe_Distribution.p12` + password
2. **Provisioning Profile:** `.mobileprovision` file from Apple Developer

## Common Certificate Names
- `ios_distribution.cer`
- `Adaptalyfe.cer` 
- `distribution_certificate.cer`

The converter script handles all these automatically.