# CodeMagic Reference Name Setup

## When CodeMagic Asks for "Reference Name"

This is an identifier that CodeMagic uses to reference your certificate in builds.

## For Your Certificate Upload:

### iOS Distribution Certificate
- **Reference Name:** `ADAPTALYFE_DISTRIBUTION_CERT`
- **File:** `Adaptalyfe_Distribution.p12`
- **Password:** `adaptalyfe2025`

### Provisioning Profile
- **Reference Name:** `ADAPTALYFE_APP_STORE_PROFILE`
- **File:** `AdaptaLyfe_App_Store_Distribution (3).mobileprovision`

## How to Use These Names:

1. **Upload Certificate:**
   - Click "Add certificate"
   - Reference name: `ADAPTALYFE_DISTRIBUTION_CERT`
   - Upload your .p12 file
   - Enter password: `adaptalyfe2025`

2. **Upload Provisioning Profile:**
   - Click "Add provisioning profile"
   - Reference name: `ADAPTALYFE_APP_STORE_PROFILE`
   - Upload your .mobileprovision file

3. **Build Configuration:**
   - CodeMagic will use these reference names in your build
   - The codemagic.yaml file will automatically reference them

## Alternative Simple Names:
- Certificate: `ios_cert`
- Profile: `app_store_profile`

The reference name is just a label - use any descriptive name you prefer.