import React from "react";
import WearableDevicesModule from "@/components/wearable-devices-module";

function WearableDevicesPage() {
  return (
    <div className="container mx-auto p-6">
      <div className="mb-6">
        <h1 className="text-3xl font-bold text-gray-900">Wearable Devices</h1>
        <p className="text-gray-600 mt-2">
          Connect and monitor your health data from smartwatches and fitness trackers
        </p>
      </div>
      <WearableDevicesModule />
    </div>
  );
}

export default WearableDevicesPage;