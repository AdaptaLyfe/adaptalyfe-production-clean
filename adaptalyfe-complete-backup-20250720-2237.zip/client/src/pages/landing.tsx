import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Link } from "wouter";
import { 
  Brain, 
  Heart, 
  Shield, 
  Smartphone, 
  Users, 
  DollarSign,
  CheckCircle,
  Star,
  ArrowRight,
  Zap
} from "lucide-react";

export default function Landing() {
  const features = [
    {
      icon: Brain,
      title: "AI-Powered Support",
      description: "AdaptAI assistant provides personalized guidance and reminders"
    },
    {
      icon: Heart,
      title: "Mental Health Focus", 
      description: "Daily mood tracking and emotional wellness monitoring"
    },
    {
      icon: Shield,
      title: "Safety Features",
      description: "Emergency contacts, location sharing, and crisis support"
    },
    {
      icon: Smartphone,
      title: "Mobile Ready",
      description: "Works on all devices - install like a native app"
    },
    {
      icon: Users,
      title: "Caregiver Network",
      description: "Keep family and support team connected and informed"
    },
    {
      icon: DollarSign,
      title: "Financial Management",
      description: "Banking integration and automated bill pay"
    }
  ];

  const plans = [
    {
      name: "Basic",
      price: "$4.99",
      description: "Essential independence tools",
      features: [
        "Up to 25 daily tasks",
        "Basic mood tracking",
        "2 caregiver connections",
        "Emergency contacts",
        "Mobile app access"
      ],
      popular: false
    },
    {
      name: "Premium", 
      price: "$12.99",
      description: "Complete independence platform",
      features: [
        "Unlimited tasks and features",
        "AI life coach (AdaptAI)",
        "Advanced mood insights",
        "Banking integration",
        "Unlimited caregivers",
        "Academic planning tools",
        "Medication management",
        "Location safety features"
      ],
      popular: true
    },
    {
      name: "Family",
      price: "$24.99", 
      description: "Support for the whole family",
      features: [
        "Everything in Premium",
        "Up to 5 user accounts",
        "Family dashboard",
        "Shared calendars",
        "Progress reports",
        "Priority support"
      ],
      popular: false
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-50">

      {/* Hero Section */}
      <section className="pt-16 pb-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <Badge className="mb-6 bg-blue-100 text-blue-700 border-blue-300">
            🎉 Now Available as Web App - Install Instantly
          </Badge>
          
          <h1 className="text-5xl font-bold text-gray-900 mb-6">
            Grow with Guidance.<br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-purple-600">
              Thrive with Confidence.
            </span>
          </h1>
          
          <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto">
            The first independence-building platform designed specifically for teens and adults 
            with neurodevelopmental differences. Build life skills, manage daily tasks, and 
            stay connected with your support network.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/dashboard">
              <Button size="lg" className="text-lg px-8 py-4">
                Access Full App
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
            </Link>
            <Link href="/admin">
              <Button size="lg" variant="outline" className="text-lg px-8 py-4">
                Admin Dashboard
                <Zap className="ml-2 h-5 w-5" />
              </Button>
            </Link>
          </div>
          
          <p className="text-sm text-gray-500 mt-4">
            No app store required • Works on all devices • Full access immediately
          </p>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Everything You Need to Build Independence
            </h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Comprehensive tools designed with neurodevelopmental differences in mind
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {features.map((feature, index) => (
              <Card key={index} className="text-center hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="bg-gradient-to-r from-blue-100 to-purple-100 p-3 rounded-lg w-fit mx-auto mb-4">
                    <feature.icon className="h-6 w-6 text-blue-600" />
                  </div>
                  <CardTitle className="text-xl">{feature.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-base">
                    {feature.description}
                  </CardDescription>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Simple, Transparent Pricing
            </h2>
            <p className="text-lg text-gray-600">
              Choose the plan that works best for your independence journey
            </p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            {plans.map((plan, index) => (
              <Card key={index} className={`relative ${plan.popular ? 'border-2 border-blue-500 shadow-lg' : ''}`}>
                {plan.popular && (
                  <Badge className="absolute -top-3 left-1/2 transform -translate-x-1/2 bg-blue-500">
                    Most Popular
                  </Badge>
                )}
                <CardHeader className="text-center">
                  <CardTitle className="text-2xl">{plan.name}</CardTitle>
                  <div className="text-4xl font-bold text-gray-900">
                    {plan.price}
                    <span className="text-lg font-normal text-gray-600">/month</span>
                  </div>
                  <CardDescription className="text-base">
                    {plan.description}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-3 mb-6">
                    {plan.features.map((feature, featureIndex) => (
                      <li key={featureIndex} className="flex items-center gap-3">
                        <CheckCircle className="h-5 w-5 text-green-500 flex-shrink-0" />
                        <span className="text-sm">{feature}</span>
                      </li>
                    ))}
                  </ul>
                  <Link href="/pricing">
                    <Button 
                      className="w-full" 
                      variant={plan.popular ? "default" : "outline"}
                    >
                      Get Started
                    </Button>
                  </Link>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-gradient-to-r from-blue-600 to-purple-600 text-white">
        <div className="max-w-4xl mx-auto text-center px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold mb-4">
            Ready to Start Your Independence Journey?
          </h2>
          <p className="text-xl mb-8 opacity-90">
            Join thousands of individuals building confidence and life skills with Adaptalyfe
          </p>
          <Link href="/pricing">
            <Button size="lg" variant="secondary" className="text-lg px-8 py-4">
              Start Your Free Trial
              <Zap className="ml-2 h-5 w-5" />
            </Button>
          </Link>
          <p className="text-sm mt-4 opacity-75">
            7-day free trial • No credit card required • Cancel anytime
          </p>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center gap-3 mb-4">
                <div className="bg-gradient-to-r from-blue-600 to-purple-600 p-2 rounded-lg">
                  <Brain className="h-6 w-6 text-white" />
                </div>
                <span className="text-xl font-bold">Adaptalyfe</span>
              </div>
              <p className="text-gray-400">
                Empowering independence through adaptive technology
              </p>
            </div>
            <div>
              <h3 className="font-semibold mb-4">Product</h3>
              <ul className="space-y-2 text-gray-400">
                <li><Link href="/pricing">Pricing</Link></li>
                <li><Link href="/demo-login">Demo</Link></li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold mb-4">Support</h3>
              <ul className="space-y-2 text-gray-400">
                <li>Help Center</li>
                <li>Privacy Policy</li>
                <li>Terms of Service</li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold mb-4">Contact</h3>
              <ul className="space-y-2 text-gray-400">
                <li>support@adaptalyfe.com</li>
                <li>1-800-ADAPT-LYFE</li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
            <p>&copy; 2025 Adaptalyfe. All rights reserved.</p>
            <Link href="/demo-login" className="text-xs opacity-30 hover:opacity-50 transition-opacity">
              Admin
            </Link>
          </div>
        </div>
      </footer>
    </div>
  );
}