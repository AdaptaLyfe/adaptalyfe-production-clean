import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { useQuery } from "@tanstack/react-query";
import { Heart, Bell, User as UserIcon, Menu, X, Pill, Stethoscope, GraduationCap, AlertTriangle } from "lucide-react";
import { useState } from "react";
import NotificationCenter from "./notification-center";
import type { User } from "@shared/schema";

export default function Navigation() {
  const [location] = useLocation();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  
  const { data: user } = useQuery<User>({
    queryKey: ["/api/user"],
  });

  return (
    <header className="bg-card shadow-lg border-b border-border backdrop-blur-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <Link href="/">
            <div className="flex items-center space-x-3 cursor-pointer">
              <div className="w-12 h-12 bg-gradient-to-br from-purple-600 to-pink-500 rounded-xl flex items-center justify-center shadow-lg border-2 border-white">
                <Heart className="text-white" size={20} />
              </div>
              <div>
                <h1 className="text-xl font-semibold text-foreground">Adaptalyfe</h1>
                <p className="text-xs text-muted-foreground">Grow with Guidance. Thrive with Confidence.</p>
              </div>
            </div>
          </Link>
          
          <div className="hidden md:flex items-center space-x-2">
            <Link href="/">
              <Button 
                variant={location === "/" ? "default" : "ghost"}
                size="sm"
                className={location === "/" ? "bg-primary hover:bg-primary/90 text-primary-foreground" : "text-muted-foreground hover:text-foreground"}
              >
                Dashboard
              </Button>
            </Link>
            <Link href="/daily-tasks">
              <Button 
                variant={location === "/daily-tasks" ? "default" : "ghost"}
                size="sm"
                className={location === "/daily-tasks" ? "bg-primary hover:bg-primary/90 text-primary-foreground" : "text-muted-foreground hover:text-foreground"}
              >
                Daily Tasks
              </Button>
            </Link>
            <Link href="/financial">
              <Button 
                variant={location === "/financial" ? "default" : "ghost"}
                size="sm"
                className={location === "/financial" ? "bg-primary hover:bg-primary/90 text-primary-foreground" : "text-muted-foreground hover:text-foreground"}
              >
                Financial
              </Button>
            </Link>
            <Link href="/mood-tracking">
              <Button 
                variant={location === "/mood-tracking" ? "default" : "ghost"}
                size="sm"
                className={location === "/mood-tracking" ? "bg-primary hover:bg-primary/90 text-primary-foreground" : "text-muted-foreground hover:text-foreground"}
              >
                Mood
              </Button>
            </Link>
            <Link href="/meal-shopping">
              <Button 
                variant={location === "/meal-shopping" ? "default" : "ghost"}
                size="sm"
                className={location === "/meal-shopping" ? "bg-primary hover:bg-primary/90 text-primary-foreground" : "text-muted-foreground hover:text-foreground"}
              >
                Meals & Shopping
              </Button>
            </Link>
            <Link href="/calendar">
              <Button 
                variant={location === "/calendar" ? "default" : "ghost"}
                size="sm"
                className={location === "/calendar" ? "bg-primary hover:bg-primary/90 text-primary-foreground" : "text-muted-foreground hover:text-foreground"}
              >
                Calendar
              </Button>
            </Link>
            <Link href="/academic-planner">
              <Button 
                variant={location === "/academic-planner" ? "default" : "ghost"}
                size="sm"
                className={location === "/academic-planner" ? "bg-primary hover:bg-primary/90 text-primary-foreground" : "text-muted-foreground hover:text-foreground"}
              >
                <GraduationCap className="w-4 h-4 mr-2" />
                Student
              </Button>
            </Link>
            <Link href="/pharmacy">
              <Button 
                variant={location === "/pharmacy" ? "default" : "ghost"}
                size="sm"
                className={location === "/pharmacy" ? "bg-primary hover:bg-primary/90 text-primary-foreground" : "text-muted-foreground hover:text-foreground"}
              >
                <Pill className="w-4 h-4 mr-2" />
                Pharmacy
              </Button>
            </Link>
            <Link href="/medical">
              <Button 
                variant={location === "/medical" ? "default" : "ghost"}
                size="sm"
                className={location === "/medical" ? "bg-primary hover:bg-primary/90 text-primary-foreground" : "text-muted-foreground hover:text-foreground"}
              >
                <Stethoscope className="w-4 h-4 mr-2" />
                Medical
              </Button>
            </Link>
            <Link href="/resources">
              <Button 
                variant={location === "/resources" ? "default" : "ghost"}
                className={location === "/resources" ? "bg-sunny-orange hover:bg-sunny-orange" : ""}
              >
                Resources
              </Button>
            </Link>
            <Link href="/caregiver">
              <Button 
                variant={location === "/caregiver" ? "default" : "ghost"}
                className={location === "/caregiver" ? "bg-calm-teal hover:bg-calm-teal" : ""}
              >
                Support
              </Button>
            </Link>
            <Link href="/caregiver-demo">
              <Button 
                variant={location === "/caregiver-demo" ? "default" : "ghost"}
                size="sm"
                className={location === "/caregiver-demo" ? "bg-red-500 hover:bg-red-600 text-white" : "text-red-600 hover:text-red-700 border-red-200"}
              >
                Demo
              </Button>
            </Link>
          </div>
          
          <div className="flex items-center space-x-4">
            {/* Emergency Button */}
            <Link href="/resources">
              <Button 
                size="sm"
                className="bg-red-600 hover:bg-red-700 text-white border-red-700 shadow-lg"
              >
                <AlertTriangle className="w-4 h-4 mr-2" />
                Emergency
              </Button>
            </Link>
            
            <div className="hidden md:flex items-center space-x-3 bg-gray-100 rounded-lg p-2">
              <div className="w-8 h-8 bg-vibrant-green rounded-full flex items-center justify-center">
                <UserIcon className="text-white" size={16} />
              </div>
              <span className="text-sm font-medium text-gray-700">
                {user?.name || "Loading..."}
              </span>
            </div>

            {/* Mobile menu button */}
            <Button
              variant="ghost"
              className="md:hidden"
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            >
              {isMobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </Button>
          </div>
        </div>

        {/* Mobile Navigation Menu */}
        {isMobileMenuOpen && (
          <div className="md:hidden bg-white border-t border-gray-200">
            <div className="px-4 py-3 space-y-2">
              <Link href="/">
                <Button 
                  variant={location === "/" ? "default" : "ghost"}
                  className={`w-full justify-start ${location === "/" ? "bg-bright-blue hover:bg-bright-blue" : ""}`}
                  onClick={() => setIsMobileMenuOpen(false)}
                >
                  Dashboard
                </Button>
              </Link>
              <Link href="/daily-tasks">
                <Button 
                  variant={location === "/daily-tasks" ? "default" : "ghost"}
                  className={`w-full justify-start ${location === "/daily-tasks" ? "bg-vibrant-green hover:bg-vibrant-green" : ""}`}
                  onClick={() => setIsMobileMenuOpen(false)}
                >
                  Daily Tasks
                </Button>
              </Link>
              <Link href="/financial">
                <Button 
                  variant={location === "/financial" ? "default" : "ghost"}
                  className={`w-full justify-start ${location === "/financial" ? "bg-bright-blue hover:bg-bright-blue" : ""}`}
                  onClick={() => setIsMobileMenuOpen(false)}
                >
                  Financial
                </Button>
              </Link>
              <Link href="/mood-tracking">
                <Button 
                  variant={location === "/mood-tracking" ? "default" : "ghost"}
                  className={`w-full justify-start ${location === "/mood-tracking" ? "bg-happy-purple hover:bg-happy-purple" : ""}`}
                  onClick={() => setIsMobileMenuOpen(false)}
                >
                  Mood
                </Button>
              </Link>
              <Link href="/meal-shopping">
                <Button 
                  variant={location === "/meal-shopping" ? "default" : "ghost"}
                  className={`w-full justify-start ${location === "/meal-shopping" ? "bg-cheerful-pink hover:bg-cheerful-pink" : ""}`}
                  onClick={() => setIsMobileMenuOpen(false)}
                >
                  Meals & Shopping
                </Button>
              </Link>
              <Link href="/calendar">
                <Button 
                  variant={location === "/calendar" ? "default" : "ghost"}
                  className={`w-full justify-start ${location === "/calendar" ? "bg-indigo-500 hover:bg-indigo-600" : ""}`}
                  onClick={() => setIsMobileMenuOpen(false)}
                >
                  Calendar
                </Button>
              </Link>
              <Link href="/academic-planner">
                <Button 
                  variant={location === "/academic-planner" ? "default" : "ghost"}
                  className={`w-full justify-start ${location === "/academic-planner" ? "bg-purple-500 hover:bg-purple-600" : ""}`}
                  onClick={() => setIsMobileMenuOpen(false)}
                >
                  <GraduationCap className="w-4 h-4 mr-2" />
                  Student
                </Button>
              </Link>
              <Link href="/pharmacy">
                <Button 
                  variant={location === "/pharmacy" ? "default" : "ghost"}
                  className={`w-full justify-start ${location === "/pharmacy" ? "bg-pink-500 hover:bg-pink-600" : ""}`}
                  onClick={() => setIsMobileMenuOpen(false)}
                >
                  <Pill className="w-4 h-4 mr-2" />
                  Pharmacy
                </Button>
              </Link>
              <Link href="/medical">
                <Button 
                  variant={location === "/medical" ? "default" : "ghost"}
                  className={`w-full justify-start ${location === "/medical" ? "bg-blue-500 hover:bg-blue-600" : ""}`}
                  onClick={() => setIsMobileMenuOpen(false)}
                >
                  <Stethoscope className="w-4 h-4 mr-2" />
                  Medical
                </Button>
              </Link>
              <Link href="/resources">
                <Button 
                  variant={location === "/resources" ? "default" : "ghost"}
                  className={`w-full justify-start ${location === "/resources" ? "bg-sunny-orange hover:bg-sunny-orange" : ""}`}
                  onClick={() => setIsMobileMenuOpen(false)}
                >
                  Resources
                </Button>
              </Link>
              <Link href="/caregiver">
                <Button 
                  variant={location === "/caregiver" ? "default" : "ghost"}
                  className={`w-full justify-start ${location === "/caregiver" ? "bg-calm-teal hover:bg-calm-teal" : ""}`}
                  onClick={() => setIsMobileMenuOpen(false)}
                >
                  Support
                </Button>
              </Link>
              
              {/* Emergency Button for Mobile */}
              <Link href="/resources">
                <Button 
                  className="w-full justify-start bg-red-600 hover:bg-red-700 text-white mt-2"
                  onClick={() => setIsMobileMenuOpen(false)}
                >
                  <AlertTriangle className="w-4 h-4 mr-2" />
                  Emergency Contacts
                </Button>
              </Link>
              
              {/* Mobile user info */}
              <div className="flex items-center space-x-3 bg-gray-100 rounded-lg p-3 mt-4">
                <div className="w-8 h-8 bg-vibrant-green rounded-full flex items-center justify-center">
                  <UserIcon className="text-white" size={16} />
                </div>
                <span className="text-sm font-medium text-gray-700">
                  {user?.name || "Loading..."}
                </span>
              </div>
            </div>
          </div>
        )}
      </div>
    </header>
  );
}
