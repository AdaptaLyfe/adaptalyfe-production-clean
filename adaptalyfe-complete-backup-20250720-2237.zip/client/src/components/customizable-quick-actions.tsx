import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { 
  Settings, Plus, X, Smile, Calendar, CheckSquare, Users, 
  Heart, Pill, Stethoscope, Car, MapPin, BookOpen, 
  ShoppingCart, Star, Home, Clock, Target, Phone,
  GraduationCap
} from "lucide-react";
import { DragDropContext, Droppable, Draggable } from "@hello-pangea/dnd";

// Available quick action options
const availableActions = [
  { key: "mood-tracking", label: "Mood Check-in", description: "How are you feeling?", icon: Smile, color: "purple", route: "/mood-tracking" },
  { key: "daily-tasks", label: "Daily Tasks", description: "Complete activities", icon: CheckSquare, color: "green", route: "/daily-tasks" },
  { key: "financial", label: "Bill Reminders", description: "Manage payments", icon: Calendar, color: "blue", route: "/financial" },
  { key: "caregiver", label: "Contact Support", description: "Reach out for help", icon: Users, color: "orange", route: "/caregiver" },
  { key: "pharmacy", label: "Medications", description: "Manage prescriptions", icon: Pill, color: "red", route: "/pharmacy" },
  { key: "medical", label: "Medical Info", description: "Health records", icon: Stethoscope, color: "pink", route: "/medical" },
  { key: "meal-shopping", label: "Meals & Shopping", description: "Plan and shop", icon: ShoppingCart, color: "yellow", route: "/meal-shopping" },
  { key: "calendar", label: "Calendar", description: "View schedule", icon: Calendar, color: "indigo", route: "/calendar" },
  { key: "resources", label: "Resources", description: "Helpful tools", icon: BookOpen, color: "teal", route: "/resources" },
  { key: "achievements", label: "Achievements", description: "View progress", icon: Star, color: "amber", route: "/rewards" },
  { key: "academic-planner", label: "Academic Planner", description: "Manage classes & assignments", icon: GraduationCap, color: "purple", route: "/academic-planner" },
  { key: "task-builder", label: "Life Skills Guide", description: "Step-by-step task tutorials", icon: BookOpen, color: "emerald", route: "/task-builder" },
];

const colorClasses = {
  purple: { bg: "from-purple-500 to-pink-500", border: "border-purple-200", hover: "hover:border-purple-400" },
  green: { bg: "from-green-500 to-emerald-500", border: "border-green-200", hover: "hover:border-green-400" },
  emerald: { bg: "from-emerald-500 to-green-500", border: "border-emerald-200", hover: "hover:border-emerald-400" },
  blue: { bg: "from-blue-500 to-cyan-500", border: "border-blue-200", hover: "hover:border-blue-400" },
  orange: { bg: "from-orange-500 to-red-500", border: "border-orange-200", hover: "hover:border-orange-400" },
  red: { bg: "from-red-500 to-rose-500", border: "border-red-200", hover: "hover:border-red-400" },
  pink: { bg: "from-pink-500 to-rose-500", border: "border-pink-200", hover: "hover:border-pink-400" },
  yellow: { bg: "from-yellow-500 to-orange-500", border: "border-yellow-200", hover: "hover:border-yellow-400" },
  indigo: { bg: "from-indigo-500 to-blue-500", border: "border-indigo-200", hover: "hover:border-indigo-400" },
  teal: { bg: "from-teal-500 to-cyan-500", border: "border-teal-200", hover: "hover:border-teal-400" },
  amber: { bg: "from-amber-500 to-orange-500", border: "border-amber-200", hover: "hover:border-amber-400" },
};

export default function CustomizableQuickActions() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isCustomizing, setIsCustomizing] = useState(false);
  const [selectedActions, setSelectedActions] = useState<string[]>([]);

  // Fetch user preferences
  const { data: userPreferences, isLoading } = useQuery({
    queryKey: ["/api/user-preferences"],
    queryFn: () => apiRequest("GET", "/api/user-preferences").then(res => res.json())
  });

  // Get current quick actions (default or saved)
  const currentQuickActions = userPreferences?.themeSettings?.quickActions || [
    "mood-tracking", "daily-tasks", "financial", "caregiver"
  ];

  // Update user preferences mutation
  const updatePreferencesMutation = useMutation({
    mutationFn: (newActions: string[]) => 
      apiRequest("POST", "/api/user-preferences", {
        themeSettings: {
          ...(userPreferences?.themeSettings || {}),
          quickActions: newActions
        }
      }).then(res => res.json()),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/user-preferences"] });
      toast({
        title: "Quick Actions Updated",
        description: "Your personalized quick actions have been saved.",
      });
      setIsCustomizing(false);
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: "Failed to update quick actions: " + error.message,
        variant: "destructive",
      });
    }
  });

  const handleDragEnd = (result: any) => {
    if (!result.destination) return;

    const items = Array.from(selectedActions);
    const [reorderedItem] = items.splice(result.source.index, 1);
    items.splice(result.destination.index, 0, reorderedItem);

    setSelectedActions(items);
  };

  const addAction = (actionKey: string) => {
    if (!selectedActions.includes(actionKey) && selectedActions.length < 6) {
      setSelectedActions([...selectedActions, actionKey]);
    }
  };

  const removeAction = (actionKey: string) => {
    setSelectedActions(selectedActions.filter(key => key !== actionKey));
  };

  const saveActions = () => {
    updatePreferencesMutation.mutate(selectedActions);
  };

  const startCustomizing = () => {
    setSelectedActions([...currentQuickActions]);
    setIsCustomizing(true);
  };

  if (isLoading) {
    return (
      <div className="mb-8">
        <div className="h-8 bg-gray-200 rounded animate-pulse mb-6" />
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
          {[1, 2, 3, 4].map(i => (
            <div key={i} className="h-32 bg-gray-200 rounded-2xl animate-pulse" />
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="mb-8">
      <div className="flex justify-between items-center mb-6">
        <h3 className="text-3xl font-bold text-gray-800 drop-shadow-sm">Quick Actions</h3>
        <Dialog open={isCustomizing} onOpenChange={setIsCustomizing}>
          <DialogTrigger asChild>
            <Button
              variant="outline"
              size="sm"
              onClick={startCustomizing}
              className="bg-white/80 backdrop-blur-sm border-2 hover:shadow-lg transition-all"
            >
              <Settings className="w-4 h-4 mr-2" />
              Customize
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Customize Your Quick Actions</DialogTitle>
              <DialogDescription>
                Choose up to 6 features you use most often. Drag to reorder them.
              </DialogDescription>
            </DialogHeader>
            
            <div className="space-y-6">
              {/* Selected Actions (Draggable) */}
              <div>
                <h4 className="font-semibold mb-3">Your Quick Actions ({selectedActions.length}/6)</h4>
                <DragDropContext onDragEnd={handleDragEnd}>
                  <Droppable droppableId="selected-actions" direction="horizontal">
                    {(provided) => (
                      <div
                        {...provided.droppableProps}
                        ref={provided.innerRef}
                        className="grid grid-cols-2 md:grid-cols-3 gap-3 min-h-[100px] p-4 border-2 border-dashed border-gray-300 rounded-lg"
                      >
                        {selectedActions.map((actionKey, index) => {
                          const action = availableActions.find(a => a.key === actionKey);
                          if (!action) return null;
                          
                          const IconComponent = action.icon;
                          const colors = colorClasses[action.color as keyof typeof colorClasses];
                          
                          return (
                            <Draggable key={actionKey} draggableId={actionKey} index={index}>
                              {(provided, snapshot) => (
                                <div
                                  ref={provided.innerRef}
                                  {...provided.draggableProps}
                                  {...provided.dragHandleProps}
                                  className={`relative bg-white rounded-xl p-4 shadow-md border-2 ${colors.border} ${
                                    snapshot.isDragging ? 'shadow-xl scale-105' : ''
                                  } transition-all cursor-move`}
                                >
                                  <Button
                                    variant="ghost"
                                    size="sm"
                                    className="absolute -top-2 -right-2 w-6 h-6 p-0 bg-red-500 text-white hover:bg-red-600 rounded-full"
                                    onClick={() => removeAction(actionKey)}
                                  >
                                    <X className="w-3 h-3" />
                                  </Button>
                                  <div className={`w-8 h-8 bg-gradient-to-br ${colors.bg} rounded-lg flex items-center justify-center mb-2`}>
                                    <IconComponent className="text-white" size={16} />
                                  </div>
                                  <h5 className="font-medium text-sm">{action.label}</h5>
                                  <p className="text-xs text-gray-600">{action.description}</p>
                                </div>
                              )}
                            </Draggable>
                          );
                        })}
                        {provided.placeholder}
                        {selectedActions.length === 0 && (
                          <div className="col-span-full text-center text-gray-500 py-8">
                            Choose your favorite features from below
                          </div>
                        )}
                      </div>
                    )}
                  </Droppable>
                </DragDropContext>
              </div>

              {/* Available Actions */}
              <div>
                <h4 className="font-semibold mb-3">Available Features</h4>
                <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
                  {availableActions.map((action) => {
                    const IconComponent = action.icon;
                    const colors = colorClasses[action.color as keyof typeof colorClasses];
                    const isSelected = selectedActions.includes(action.key);
                    const canAdd = selectedActions.length < 6;
                    
                    return (
                      <Card 
                        key={action.key} 
                        className={`cursor-pointer transition-all ${
                          isSelected 
                            ? 'opacity-50 cursor-not-allowed' 
                            : canAdd 
                              ? 'hover:shadow-md hover:scale-105' 
                              : 'opacity-30 cursor-not-allowed'
                        }`}
                        onClick={() => !isSelected && canAdd && addAction(action.key)}
                      >
                        <CardContent className="p-4 text-center">
                          <div className={`w-10 h-10 bg-gradient-to-br ${colors.bg} rounded-lg flex items-center justify-center mb-2 mx-auto`}>
                            <IconComponent className="text-white" size={20} />
                          </div>
                          <h5 className="font-medium text-sm mb-1">{action.label}</h5>
                          <p className="text-xs text-gray-600">{action.description}</p>
                          {isSelected && (
                            <Badge variant="secondary" className="mt-2 text-xs">Added</Badge>
                          )}
                        </CardContent>
                      </Card>
                    );
                  })}
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex justify-end gap-3 pt-4 border-t">
                <Button variant="outline" onClick={() => setIsCustomizing(false)}>
                  Cancel
                </Button>
                <Button 
                  onClick={saveActions}
                  disabled={selectedActions.length === 0 || updatePreferencesMutation.isPending}
                >
                  {updatePreferencesMutation.isPending ? "Saving..." : "Save Changes"}
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Display Current Quick Actions */}
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-6">
        {currentQuickActions.slice(0, 6).map((actionKey: string) => {
          const action = availableActions.find(a => a.key === actionKey);
          if (!action) return null;
          
          const IconComponent = action.icon;
          const colors = colorClasses[action.color as keyof typeof colorClasses];
          
          return (
            <Link key={actionKey} href={action.route}>
              <Button
                variant="outline"
                className={`bg-white/80 backdrop-blur-sm rounded-2xl p-6 shadow-xl border-2 ${colors.border} ${colors.hover} hover:shadow-2xl transition-all duration-300 h-auto flex-col space-y-3 w-full`}
              >
                <div className={`w-14 h-14 bg-gradient-to-br ${colors.bg} rounded-xl flex items-center justify-center shadow-lg`}>
                  <IconComponent className="text-white" size={28} />
                </div>
                <div className="text-center px-1">
                  <h4 className="font-bold text-gray-900 text-xs leading-tight">{action.label}</h4>
                  <p className="text-[10px] text-gray-700 font-medium mt-1 leading-tight">{action.description}</p>
                </div>
              </Button>
            </Link>
          );
        })}
      </div>
    </div>
  );
}