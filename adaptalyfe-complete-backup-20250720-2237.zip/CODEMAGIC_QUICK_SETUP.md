# CodeMagic Setup for Adaptalyfe iOS Build

## Step 1: Create GitHub Repository

1. **Go to GitHub.com** and sign in
2. **Click "New Repository"**
3. **Name:** `adaptalyfe-ios-app`
4. **Description:** "Adaptalyfe - Independence building app for iOS"
5. **Set to Public** (for free CodeMagic builds)
6. **Create Repository**

## Step 2: Upload Your Project Files

Since Git is locked in Replit, you'll need to manually upload:

### Required Files to Upload:
- `capacitor.config.ts`
- `package.json`
- `package-lock.json`
- `tsconfig.json`
- `vite.config.ts`
- `tailwind.config.ts`
- `codemagic.yaml` (I created this for you)
- `README.md`
- `.gitignore`
- **Entire `client/` folder**
- **Entire `server/` folder**
- **Entire `shared/` folder**
- **Entire `ios/` folder**

### Quick Upload Method:
1. **Download** your `adaptalyfe-ios-build.zip` from earlier
2. **Extract** it locally
3. **Add** the files I just created (`codemagic.yaml`, `README.md`, `.gitignore`)
4. **Upload** all files to your GitHub repository

## Step 3: Connect to CodeMagic

1. **Go to** https://codemagic.io
2. **Sign up** with your GitHub account
3. **Click "Add application"**
4. **Select** your `adaptalyfe-ios-app` repository
5. **Choose "Capacitor"** as project type

## Step 4: Configure iOS Build

In CodeMagic dashboard:

### Build Settings:
- **Branch:** main
- **Workflow:** ios-adaptalyfe (from codemagic.yaml)
- **Build triggers:** Manual (for now)

### iOS Signing (Required):
You'll need these from Apple Developer:
- **Distribution Certificate** (.p12 file + password)
- **Provisioning Profile** (.mobileprovision file)
- **Bundle ID:** `com.adaptalyfe.app`

## Step 5: Apple Developer Requirements

Before building, you need:

1. **Apple Developer Account** ($99/year)
   - Go to https://developer.apple.com
   - Enroll in Apple Developer Program

2. **App Store Connect**
   - Create new app record
   - Bundle ID: `com.adaptalyfe.app`
   - App name: "Adaptalyfe"

3. **Certificates & Profiles**
   - iOS Distribution Certificate
   - App Store Provisioning Profile

## Step 6: Start Build

1. **Upload certificates** to CodeMagic
2. **Configure environment variables**
3. **Click "Start new build"**
4. **Wait 15-30 minutes** for build completion
5. **Download .ipa file**

## What Happens Next

CodeMagic will:
- Install dependencies (`npm ci`)
- Build your web app (`npm run build`)
- Sync Capacitor (`npx cap sync ios`)
- Build iOS app with Xcode
- Generate signed .ipa file
- Email you when complete

## Cost

- **CodeMagic Free:** 500 build minutes/month
- **Your build:** ~20-30 minutes
- **Total cost:** FREE for first builds

## Need Help?

The main steps are:
1. ✅ Upload project to GitHub
2. ✅ Connect to CodeMagic
3. ⏳ Get Apple Developer certificates
4. ⏳ Configure iOS signing
5. ⏳ Build and download .ipa

Would you like me to help with any specific step?