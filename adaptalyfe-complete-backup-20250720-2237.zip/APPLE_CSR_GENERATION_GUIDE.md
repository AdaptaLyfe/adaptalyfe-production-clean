# Apple CSR File Generation Guide

## What is a CSR File?
A Certificate Signing Request (CSR) is required by Apple to generate certificates for iOS app development and distribution.

## Generate CSR on Mac

### Step 1: Open Keychain Access
1. Open **Keychain Access** (Applications > Utilities)
2. Select **Keychain Access** > **Certificate Assistant** > **Request a Certificate From a Certificate Authority**

### Step 2: Certificate Information
Fill in the form:
- **User Email Address**: Your Apple Developer account email
- **Common Name**: Your name or company name (e.g., "Adaptalyfe Development")
- **CA Email Address**: Leave blank
- **Request is**: Select "Saved to disk"
- **Let me specify key pair information**: Check this box

### Step 3: Key Pair Information
- **Key Size**: 2048 bits
- **Algorithm**: RSA

### Step 4: Save CSR File
- Save as: `Adaptalyfe_CSR.certSigningRequest`
- Location: Desktop or Documents folder

## Generate CSR on Windows/Linux

### Using OpenSSL Command Line:
```bash
# Generate private key
openssl genrsa -out adaptalyfe_private.key 2048

# Generate CSR
openssl req -new -key adaptalyfe_private.key -out Adaptalyfe_CSR.certSigningRequest

# When prompted, enter:
# Country Name: US
# State: Your state
# City: Your city  
# Organization: Adaptalyfe
# Organizational Unit: Development
# Common Name: Adaptalyfe Development
# Email: your-apple-developer-email@domain.com
# Challenge password: (leave blank)
# Optional company name: (leave blank)
```

### Using Online CSR Generators:
1. **SSL Shopper CSR Generator**: https://www.sslshopper.com/csr-generator.html
2. **DigiCert CSR Generator**: https://www.digicert.com/easy-csr/openssl.htm

Fill in:
- **Common Name**: Adaptalyfe Development  
- **Organization**: Adaptalyfe
- **Department**: Development
- **City**: Your city
- **State**: Your state
- **Country**: Your country code (US, etc.)
- **Email**: Your Apple Developer account email

## Upload CSR to Apple Developer

### Step 1: Access Certificates
1. Go to: https://developer.apple.com/account/
2. Sign in with your Apple Developer account
3. Navigate to **Certificates, Identifiers & Profiles**
4. Click **Certificates** in the sidebar

### Step 2: Create New Certificate
1. Click the **+** button to add a new certificate
2. Select certificate type:
   - **iOS Development** (for testing)
   - **iOS Distribution** (for App Store)
3. Click **Continue**

### Step 3: Upload CSR
1. Click **Choose File**
2. Select your `Adaptalyfe_CSR.certSigningRequest` file
3. Click **Continue**
4. Download the generated certificate (.cer file)

## Certificate Types Needed

### For App Development:
- **iOS Development Certificate** - Test on devices
- **iOS Distribution Certificate** - Submit to App Store

### For Push Notifications:
- **Apple Push Notification service SSL (Sandbox & Production)**

## What to Do With Downloaded Certificate

### On Mac:
1. Double-click the downloaded .cer file
2. It will automatically install in Keychain Access
3. Export as .p12 file for use in build tools

### For React Native/Expo:
1. Convert .cer to .p8 format if needed
2. Use in EAS Build configuration
3. Store securely for automated builds

## Troubleshooting

**Common Issues:**
- **"Invalid CSR"**: Ensure 2048-bit RSA key
- **"CSR already used"**: Generate a new CSR file
- **"Keychain issues"**: Restart Keychain Access

**Security Notes:**
- Keep your private key secure
- Never share private keys
- Regenerate if compromised
- Use different CSRs for development vs distribution

## Next Steps After CSR Upload

1. **Download certificates** from Apple Developer portal
2. **Install certificates** in development environment
3. **Create App ID** for Adaptalyfe
4. **Generate provisioning profiles**
5. **Configure Xcode project** with certificates
6. **Build and sign iOS app**

Your CSR file is the first step in the iOS app certificate chain required for App Store submission.