# CodeMagic Setup Guide for Adaptalyfe iOS Build

## Why CodeMagic for Your Capacitor Project

CodeMagic specializes in building React Native and Capacitor apps in the cloud. It's the easiest option for your Adaptalyfe iOS submission.

## Step-by-Step Setup

### 1. Create CodeMagic Account
- Go to https://codemagic.io
- Sign up with GitHub, GitLab, or Bitbucket
- Choose the free plan to start

### 2. Upload Your Project to Repository

First, you need to push your project to a Git repository:

```bash
# Initialize git in your project
git init
git add .
git commit -m "Initial Adaptalyfe iOS project"

# Create repository on GitHub/GitLab
# Then push your code
git remote add origin https://github.com/yourusername/adaptalyfe-ios.git
git push -u origin main
```

### 3. Connect Repository to CodeMagic
1. In CodeMagic dashboard, click "Add application"
2. Select your Git provider (GitHub/GitLab)
3. Choose your Adaptalyfe repository
4. Select "Capacitor" as the project type

### 4. Configure iOS Build Settings

In CodeMagic, configure:

**Build Configuration:**
- **Platform:** iOS
- **Xcode Version:** Latest stable
- **Build Scheme:** App
- **Configuration:** Release

**Code Signing:**
- Upload your Apple Developer Certificate (.p12 file)
- Upload Provisioning Profile
- Set Bundle ID: `com.adaptalyfe.app`

### 5. Add Required Files

CodeMagic needs these from your Apple Developer account:
- **Distribution Certificate** (.p12 file + password)
- **Provisioning Profile** (.mobileprovision file)
- **Apple ID** and **App-Specific Password**

### 6. Build Configuration File

Create `codemagic.yaml` in your project root:

```yaml
workflows:
  ios-workflow:
    name: iOS Build
    max_build_duration: 120
    environment:
      ios_signing:
        distribution_type: app_store
        bundle_identifier: com.adaptalyfe.app
      vars:
        XCODE_WORKSPACE: "ios/App/App.xcworkspace"
        XCODE_SCHEME: "App"
    scripts:
      - name: Install dependencies
        script: |
          npm install
      - name: Capacitor sync
        script: |
          npx cap sync ios
      - name: Build iOS
        script: |
          xcode-project build-ipa \
            --workspace "$XCODE_WORKSPACE" \
            --scheme "$XCODE_SCHEME"
    artifacts:
      - build/ios/ipa/*.ipa
    publishing:
      app_store_connect:
        auth: integration
        submit_to_testflight: true
```

### 7. Start Build Process
1. Click "Start your first build"
2. Select the iOS workflow
3. Monitor build progress (15-30 minutes)
4. Download the .ipa file when complete

### 8. Submit to App Store
- CodeMagic can automatically submit to TestFlight
- Or download .ipa and upload manually via Xcode/Transporter

## Alternative: Quick Setup Without Repository

If you want to avoid Git setup:

### Local Upload Option
1. Create a private GitHub repository
2. Upload your `adaptalyfe-ios-build.zip` contents
3. Extract and commit files
4. Follow CodeMagic setup above

## Costs
- **CodeMagic Free:** 500 build minutes/month
- **Your build:** ~20-30 minutes
- **Cost:** Free for initial builds

## Apple Developer Account Requirements
- $99/year Apple Developer membership
- App Store Connect access
- iOS Distribution Certificate
- App Store Provisioning Profile

Would you like me to help you set up the GitHub repository first, or do you have questions about the Apple Developer certificate setup?