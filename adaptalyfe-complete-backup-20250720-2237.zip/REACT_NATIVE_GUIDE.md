# SkillBridge React Native Implementation Guide

## Setup & Environment

### Prerequisites
```bash
# Install Node.js 18+ and npm
# Install Expo CLI
npm install -g @expo/cli

# Install React Native CLI (for bare workflow)
npm install -g react-native-cli

# For iOS development
# Install Xcode from App Store (macOS only)

# For Android development
# Install Android Studio
```

### Project Structure
```
SkillBridge-Mobile/
├── App.js                    # Main entry point
├── app.json                  # Expo configuration
├── package.json              # Dependencies
├── src/
│   ├── components/           # Reusable UI components
│   │   ├── ui/              # Base UI components (Button, Input, etc.)
│   │   ├── modules/         # Feature modules
│   │   └── common/          # Shared components
│   ├── screens/             # Screen components
│   │   ├── auth/           # Login, register screens
│   │   ├── dashboard/      # Main dashboard
│   │   ├── tasks/          # Task management
│   │   ├── mood/           # Mood tracking
│   │   ├── calendar/       # Calendar view
│   │   └── settings/       # Settings and preferences
│   ├── navigation/          # Navigation configuration
│   ├── services/           # API calls and external services
│   ├── hooks/              # Custom React hooks
│   ├── utils/              # Helper functions
│   ├── constants/          # App constants and config
│   └── store/              # State management
├── assets/                  # Images, fonts, sounds
│   ├── images/
│   ├── icons/
│   └── sounds/
└── android/                # Android-specific code
└── ios/                    # iOS-specific code
```

## Component Migration Strategy

### 1. UI Component Mapping
```javascript
// Web to React Native component mapping
Web Component -> React Native Component
div -> View
span -> Text
button -> TouchableOpacity + Text
input -> TextInput
select -> Picker
img -> Image
a -> TouchableOpacity + Linking

// Navigation
wouter Router -> React Navigation
Link -> navigation.navigate()
```

### 2. Core Components
```javascript
// Base Button Component
import { TouchableOpacity, Text, StyleSheet } from 'react-native';

export const Button = ({ title, onPress, variant = 'primary', disabled }) => {
  return (
    <TouchableOpacity 
      style={[styles.button, styles[variant], disabled && styles.disabled]}
      onPress={onPress}
      disabled={disabled}
      accessibilityRole="button"
      accessibilityLabel={title}
    >
      <Text style={[styles.text, styles[`${variant}Text`]]}>{title}</Text>
    </TouchableOpacity>
  );
};

// Base Input Component
import { TextInput, View, Text } from 'react-native';

export const Input = ({ label, value, onChangeText, placeholder, error, ...props }) => {
  return (
    <View style={styles.container}>
      {label && <Text style={styles.label}>{label}</Text>}
      <TextInput
        style={[styles.input, error && styles.errorInput]}
        value={value}
        onChangeText={onChangeText}
        placeholder={placeholder}
        accessibilityLabel={label}
        {...props}
      />
      {error && <Text style={styles.errorText}>{error}</Text>}
    </View>
  );
};
```

### 3. Navigation Setup
```javascript
// App.js
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';

const Stack = createStackNavigator();
const Tab = createBottomTabNavigator();

function MainTabs() {
  return (
    <Tab.Navigator
      screenOptions={{
        tabBarActiveTintColor: '#8B5CF6',
        tabBarInactiveTintColor: '#6B7280',
        tabBarStyle: { height: 70, paddingBottom: 10 }
      }}
    >
      <Tab.Screen name="Dashboard" component={DashboardScreen} />
      <Tab.Screen name="Tasks" component={TasksScreen} />
      <Tab.Screen name="Mood" component={MoodScreen} />
      <Tab.Screen name="Calendar" component={CalendarScreen} />
      <Tab.Screen name="More" component={MoreScreen} />
    </Tab.Navigator>
  );
}

export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator>
        <Stack.Screen name="Login" component={LoginScreen} />
        <Stack.Screen name="Register" component={RegisterScreen} />
        <Stack.Screen 
          name="Main" 
          component={MainTabs} 
          options={{ headerShown: false }}
        />
      </Stack.Navigator>
    </NavigationContainer>
  );
}
```

## Feature Implementation

### 1. Task Management Module
```javascript
// screens/tasks/TasksScreen.js
import React, { useState } from 'react';
import { View, FlatList, Text, Alert } from 'react-native';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { TaskCard } from '../../components/modules/TaskCard';
import { AddTaskModal } from '../../components/modules/AddTaskModal';

export const TasksScreen = () => {
  const [showAddModal, setShowAddModal] = useState(false);
  const queryClient = useQueryClient();

  const { data: tasks, isLoading } = useQuery({
    queryKey: ['/api/daily-tasks'],
  });

  const toggleTaskMutation = useMutation({
    mutationFn: async ({ taskId, isCompleted }) => {
      const response = await fetch(`/api/daily-tasks/${taskId}/completion`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ isCompleted })
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['/api/daily-tasks']);
    }
  });

  const renderTask = ({ item }) => (
    <TaskCard 
      task={item}
      onToggle={() => toggleTaskMutation.mutate({
        taskId: item.id,
        isCompleted: !item.isCompleted
      })}
    />
  );

  return (
    <View style={styles.container}>
      <FlatList
        data={tasks}
        renderItem={renderTask}
        keyExtractor={item => item.id.toString()}
        refreshing={isLoading}
      />
      <AddTaskModal 
        visible={showAddModal}
        onClose={() => setShowAddModal(false)}
      />
    </View>
  );
};
```

### 2. Mood Tracking with Native Features
```javascript
// screens/mood/MoodScreen.js
import React, { useState } from 'react';
import { View, Text, Alert, Vibration } from 'react-native';
import * as Notifications from 'expo-notifications';
import { MoodSelector } from '../../components/modules/MoodSelector';

export const MoodScreen = () => {
  const [selectedMood, setSelectedMood] = useState(null);

  const submitMood = async (mood, notes) => {
    try {
      // Submit to API
      await fetch('/api/mood-entries', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ mood, notes })
      });

      // Haptic feedback
      Vibration.vibrate(100);

      // Schedule encouragement notification
      await Notifications.scheduleNotificationAsync({
        content: {
          title: "Great job!",
          body: "Thank you for tracking your mood today.",
        },
        trigger: { seconds: 3600 }, // 1 hour later
      });

      Alert.alert('Success', 'Mood recorded successfully!');
    } catch (error) {
      Alert.alert('Error', 'Failed to save mood entry');
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>How are you feeling today?</Text>
      <MoodSelector 
        selectedMood={selectedMood}
        onMoodSelect={setSelectedMood}
        onSubmit={submitMood}
      />
    </View>
  );
};
```

### 3. Voice Commands Integration
```javascript
// hooks/useVoiceCommands.js
import { useState, useEffect } from 'react';
import Voice from '@react-native-voice/voice';

export const useVoiceCommands = () => {
  const [isListening, setIsListening] = useState(false);
  const [recognizedText, setRecognizedText] = useState('');

  useEffect(() => {
    Voice.onSpeechStart = () => setIsListening(true);
    Voice.onSpeechEnd = () => setIsListening(false);
    Voice.onSpeechResults = (e) => {
      if (e.value && e.value[0]) {
        setRecognizedText(e.value[0]);
        processVoiceCommand(e.value[0]);
      }
    };

    return () => {
      Voice.destroy().then(Voice.removeAllListeners);
    };
  }, []);

  const startListening = async () => {
    try {
      await Voice.start('en-US');
    } catch (error) {
      console.error('Voice recognition error:', error);
    }
  };

  const processVoiceCommand = (command) => {
    const lowerCommand = command.toLowerCase();
    
    if (lowerCommand.includes('add task')) {
      // Extract task from command and add it
      const task = lowerCommand.replace('add task', '').trim();
      // Navigate to add task or call mutation
    } else if (lowerCommand.includes('check mood')) {
      // Navigate to mood tracker
    } else if (lowerCommand.includes('open calendar')) {
      // Navigate to calendar
    }
  };

  return {
    isListening,
    recognizedText,
    startListening
  };
};
```

## Accessibility Implementation

### 1. Screen Reader Support
```javascript
// Accessibility helpers
export const AccessibilityWrapper = ({ children, label, hint, role = "none" }) => {
  return (
    <View 
      accessible={true}
      accessibilityLabel={label}
      accessibilityHint={hint}
      accessibilityRole={role}
    >
      {children}
    </View>
  );
};

// High contrast mode
export const useHighContrast = () => {
  const [isHighContrast, setIsHighContrast] = useState(false);

  useEffect(() => {
    // Load from AsyncStorage
    AsyncStorage.getItem('highContrast').then(value => {
      setIsHighContrast(value === 'true');
    });
  }, []);

  const toggleHighContrast = () => {
    const newValue = !isHighContrast;
    setIsHighContrast(newValue);
    AsyncStorage.setItem('highContrast', newValue.toString());
  };

  return { isHighContrast, toggleHighContrast };
};
```

### 2. Text-to-Speech
```javascript
// services/speechService.js
import * as Speech from 'expo-speech';

export class SpeechService {
  static speak(text, options = {}) {
    const defaultOptions = {
      language: 'en-US',
      pitch: 1.0,
      rate: 0.8,
      ...options
    };

    Speech.speak(text, defaultOptions);
  }

  static stop() {
    Speech.stop();
  }

  static async getAvailableVoices() {
    return await Speech.getAvailableVoicesAsync();
  }
}

// Usage in components
export const TaskCard = ({ task, onToggle }) => {
  const speakTask = () => {
    SpeechService.speak(`Task: ${task.title}. ${task.isCompleted ? 'Completed' : 'Not completed'}`);
  };

  return (
    <TouchableOpacity onPress={speakTask} onLongPress={onToggle}>
      <Text>{task.title}</Text>
    </TouchableOpacity>
  );
};
```

## Push Notifications

### 1. Notification Setup
```javascript
// services/notificationService.js
import * as Notifications from 'expo-notifications';
import * as Device from 'expo-device';

export class NotificationService {
  static async initialize() {
    if (Device.isDevice) {
      const { status: existingStatus } = await Notifications.getPermissionsAsync();
      let finalStatus = existingStatus;
      
      if (existingStatus !== 'granted') {
        const { status } = await Notifications.requestPermissionsAsync();
        finalStatus = status;
      }
      
      if (finalStatus !== 'granted') {
        alert('Failed to get push token for push notification!');
        return;
      }
    }

    // Configure notification behavior
    Notifications.setNotificationHandler({
      handleNotification: async () => ({
        shouldShowAlert: true,
        shouldPlaySound: true,
        shouldSetBadge: false,
      }),
    });
  }

  static async scheduleTaskReminder(task, time) {
    await Notifications.scheduleNotificationAsync({
      content: {
        title: "Task Reminder",
        body: `Don't forget: ${task.title}`,
        data: { taskId: task.id },
      },
      trigger: { date: new Date(time) },
    });
  }

  static async scheduleMoodReminder() {
    await Notifications.scheduleNotificationAsync({
      content: {
        title: "Daily Check-in",
        body: "How are you feeling today?",
      },
      trigger: { 
        hour: 19, // 7 PM
        minute: 0,
        repeats: true 
      },
    });
  }
}
```

## Offline Support

### 1. Data Persistence
```javascript
// services/offlineService.js
import AsyncStorage from '@react-native-async-storage/async-storage';
import NetInfo from '@react-native-netinfo/netinfo';

export class OfflineService {
  static async saveOfflineData(key, data) {
    try {
      await AsyncStorage.setItem(`offline_${key}`, JSON.stringify(data));
    } catch (error) {
      console.error('Failed to save offline data:', error);
    }
  }

  static async getOfflineData(key) {
    try {
      const data = await AsyncStorage.getItem(`offline_${key}`);
      return data ? JSON.parse(data) : null;
    } catch (error) {
      console.error('Failed to get offline data:', error);
      return null;
    }
  }

  static async syncWhenOnline() {
    const netInfo = await NetInfo.fetch();
    
    if (netInfo.isConnected) {
      // Sync offline tasks, mood entries, etc.
      const offlineTasks = await this.getOfflineData('tasks');
      if (offlineTasks) {
        // Upload to server
        // Clear offline data after successful sync
      }
    }
  }
}
```

## Testing Strategy

### 1. Accessibility Testing
```javascript
// __tests__/accessibility.test.js
import { render } from '@testing-library/react-native';
import { TaskCard } from '../src/components/modules/TaskCard';

describe('TaskCard Accessibility', () => {
  test('has proper accessibility labels', () => {
    const task = { id: 1, title: 'Take medication', isCompleted: false };
    const { getByRole } = render(<TaskCard task={task} onToggle={() => {}} />);
    
    const button = getByRole('button');
    expect(button).toHaveAccessibilityValue({ text: 'Take medication, not completed' });
  });

  test('announces state changes', () => {
    // Test screen reader announcements
  });
});
```

### 2. Device Testing
- **iOS**: Test on iPhone SE, iPhone 14, iPad
- **Android**: Test on various screen sizes and Android versions
- **Accessibility**: Test with VoiceOver, TalkBack, Switch Control
- **Performance**: Test on older devices (iPhone 8, Android API 23)

## Deployment Checklist

### 1. Pre-submission
- [ ] All features working on both platforms
- [ ] Accessibility testing completed
- [ ] Performance optimization done
- [ ] Security review passed
- [ ] Privacy policy updated
- [ ] App store assets created

### 2. Build Configuration
```javascript
// app.json
{
  "expo": {
    "name": "SkillBridge",
    "slug": "skillbridge",
    "version": "1.0.0",
    "orientation": "portrait",
    "icon": "./assets/icon.png",
    "splash": {
      "image": "./assets/splash.png",
      "resizeMode": "contain",
      "backgroundColor": "#ffffff"
    },
    "updates": {
      "fallbackToCacheTimeout": 0
    },
    "assetBundlePatterns": ["**/*"],
    "ios": {
      "supportsTablet": true,
      "bundleIdentifier": "com.skillbridge.app"
    },
    "android": {
      "adaptiveIcon": {
        "foregroundImage": "./assets/adaptive-icon.png",
        "backgroundColor": "#FFFFFF"
      },
      "package": "com.skillbridge.app"
    }
  }
}
```

This guide provides a complete roadmap for converting SkillBridge to React Native while maintaining all accessibility features and HIPAA compliance.