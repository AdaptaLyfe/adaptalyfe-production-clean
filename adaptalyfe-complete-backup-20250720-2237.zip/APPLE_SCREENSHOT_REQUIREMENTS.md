# Apple App Store Screenshot Requirements

## Exact Screenshot Specifications

### iPhone Screenshots (Required)
**iPhone 6.7" Display (iPhone 15 Pro Max, 14 Pro Max, 13 Pro Max, 12 Pro Max)**
- **Size**: 1290 × 2796 pixels
- **Orientation**: Portrait only
- **Format**: PNG or JPEG
- **Color**: RGB color space
- **Required**: 3-10 screenshots

**iPhone 6.5" Display (iPhone 11 Pro Max, 11, XS Max, XR)**
- **Size**: 1242 × 2688 pixels
- **Orientation**: Portrait only
- **Format**: PNG or JPEG

### iPad Screenshots (Optional but Recommended)
**iPad Pro 12.9" Display (6th, 5th, 4th, 3rd generation)**
- **Size**: 2048 × 2732 pixels
- **Orientation**: Portrait or landscape
- **Format**: PNG or JPEG

## Common Screenshot Issues & Solutions

### Issue 1: Wrong Pixel Dimensions
**Problem**: Your screenshots aren't exactly the required pixel size
**Solution**: 
- Use browser developer tools to set exact viewport size
- Set to 1290 × 2796 for iPhone 6.7"
- Take screenshot with browser's screenshot tool, not system screenshot

### Issue 2: Wrong Aspect Ratio
**Problem**: Screenshots are cropped or stretched
**Solution**:
- Ensure device simulation shows exactly 1290 × 2796
- Don't crop existing screenshots - recreate them at correct size

### Issue 3: File Format Issues
**Problem**: Apple rejects due to file format
**Solution**:
- Save as PNG (preferred) or JPEG
- Ensure RGB color space (not CMYK)
- No transparency in JPEG files

### Issue 4: DPI/Resolution Problems
**Problem**: Screenshots appear blurry or wrong resolution
**Solution**:
- Use 72 DPI for web screenshots
- Ensure pixel-perfect dimensions
- Don't upscale smaller images

## How to Create Perfect Screenshots

### Method 1: Browser Developer Tools
1. **Open Chrome/Safari Developer Tools** (F12)
2. **Click device simulation** (phone icon)
3. **Set custom dimensions**: 1290 × 2796
4. **Navigate to your app**: www.adaptalyfeapp.com
5. **Take screenshot**: Right-click > "Capture screenshot" or Cmd/Ctrl+Shift+P > "Screenshot"

### Method 2: Online Screenshot Tools
**Use**: https://www.browserstack.com/screenshots
- Set device: iPhone 15 Pro Max
- Enter URL: www.adaptalyfeapp.com
- Download exact-size screenshots

### Method 3: Figma/Design Tools
1. **Create frame**: 1290 × 2796 pixels
2. **Import web app screenshots**
3. **Position and crop** to show key features
4. **Export as PNG** at 1x resolution

## Screenshot Content Best Practices

### What to Show (3-10 screenshots)
1. **Dashboard Overview** - Main app interface
2. **Daily Tasks** - Core task management feature
3. **Medical Information** - Health tracking capabilities
4. **Mood Tracking** - Emotional wellness features
5. **Academic Planner** - Student support tools
6. **Caregiver Dashboard** - Family/caregiver features
7. **Emergency Features** - Safety and crisis support

### Screenshot Design Tips
- **Add text overlays** explaining key features
- **Use arrows** to highlight important buttons
- **Show realistic data** (not empty states)
- **Consistent branding** with Adaptalyfe colors
- **High contrast** for accessibility

## File Naming Convention
- `01_dashboard_overview.png`
- `02_daily_tasks.png`
- `03_medical_info.png`
- `04_mood_tracking.png`
- `05_academic_planner.png`

## Verification Checklist

Before uploading to App Store Connect:

- [ ] **Exact dimensions**: 1290 × 2796 pixels
- [ ] **File format**: PNG or JPEG
- [ ] **File size**: Under 8MB each
- [ ] **Color space**: RGB (not CMYK)
- [ ] **Content**: Shows actual app features
- [ ] **Text**: Readable at mobile size
- [ ] **Quality**: High resolution, not pixelated
- [ ] **Orientation**: Portrait only for iPhone
- [ ] **Count**: 3-10 screenshots minimum

## Quick Fix for Your Current Screenshots

If your current screenshots are wrong size:

1. **Don't resize them** - Apple will reject stretched images
2. **Recreate at exact dimensions** using browser dev tools
3. **Use 1290 × 2796 pixels exactly**
4. **Save as PNG format**
5. **Verify dimensions** before uploading

## Apple's Upload Process

1. **App Store Connect** > Your App > App Store tab
2. **iOS App** section > Screenshots
3. **Drag and drop** your PNG files
4. **Verify preview** shows correctly
5. **Save changes**

The key is using exact pixel dimensions that Apple expects - no approximations or scaling allowed.