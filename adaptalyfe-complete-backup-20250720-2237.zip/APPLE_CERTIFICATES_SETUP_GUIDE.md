# Create Apple Distribution Certificate & Provisioning Profile

## Prerequisites
- Apple Developer Account ($99/year)
- Certificate Signing Request (CSR) file

## Step 1: Create Certificate Signing Request (CSR)

### Option A: Use the CSR I generated for you
You already have: `Adaptalyfe.certSigningRequest` in your project files

### Option B: Generate new CSR on Mac
1. Open **Keychain Access**
2. **Keychain Access** → **Certificate Assistant** → **Request Certificate from CA**
3. Fill in:
   - Email: your Apple ID email
   - Common Name: "Adaptalyfe Distribution"
   - CA Email: leave blank
   - Request: **Saved to disk**
4. Save as `Adaptalyfe.certSigningRequest`

## Step 2: Create iOS Distribution Certificate

1. **Go to** https://developer.apple.com/account
2. **Sign in** with your Apple Developer account
3. **Navigate to** Certificates, Identifiers & Profiles
4. **Click** "Certificates" → "+"
5. **Select** "iOS Distribution (App Store and Ad Hoc)"
6. **Click** "Continue"
7. **Upload** your `Adaptalyfe.certSigningRequest` file
8. **Click** "Continue"
9. **Download** the certificate (`.cer` file)

## Step 3: Convert Certificate to .p12 Format

### On Mac:
1. **Double-click** the downloaded `.cer` file (installs in Keychain)
2. **Open Keychain Access**
3. **Find** your certificate in "My Certificates"
4. **Right-click** → **Export**
5. **Save as** `Adaptalyfe_Distribution.p12`
6. **Set password** (remember this for CodeMagic)

### On Windows/Linux:
Use the CSR private key I generated:
```bash
# Convert certificate using your private key
openssl pkcs12 -export -out Adaptalyfe_Distribution.p12 \
  -in YourCertificate.cer \
  -inkey adaptalyfe_private.key \
  -name "Adaptalyfe Distribution"
```

## Step 4: Create App Store Provisioning Profile

1. **Go to** Certificates, Identifiers & Profiles
2. **Click** "Profiles" → "+"
3. **Select** "App Store" under Distribution
4. **Click** "Continue"
5. **App ID:** Select or create `com.adaptalyfe.app`
6. **Certificate:** Select the distribution certificate you just created
7. **Profile Name:** "Adaptalyfe App Store"
8. **Click** "Generate"
9. **Download** the `.mobileprovision` file

## Step 5: Create App ID (if needed)

If `com.adaptalyfe.app` doesn't exist:
1. **Click** "Identifiers" → "+"
2. **Select** "App IDs" → "Continue"
3. **Type:** App
4. **Bundle ID:** `com.adaptalyfe.app`
5. **Description:** "Adaptalyfe Independence App"
6. **Capabilities:** 
   - Push Notifications
   - Background Modes
   - App Groups (if needed)
7. **Click** "Continue" → "Register"

## Step 6: Upload to CodeMagic

In CodeMagic dashboard:
1. **Team settings** → **Code signing identities**
2. **iOS certificates** → **Add certificate**
3. **Upload** `Adaptalyfe_Distribution.p12`
4. **Enter** the password you set
5. **Upload** `Adaptalyfe_App_Store.mobileprovision`

## Files You'll Have:
- `Adaptalyfe_Distribution.p12` (for CodeMagic)
- `Adaptalyfe_App_Store.mobileprovision` (for CodeMagic)

## Common Issues:
- **CSR rejected:** Use the one I generated (`Adaptalyfe.certSigningRequest`)
- **Certificate invalid:** Make sure you're using iOS Distribution, not Development
- **Profile invalid:** Ensure the App ID matches `com.adaptalyfe.app` exactly

The process takes about 15 minutes once you have the Apple Developer account.