# Apple App ID Capabilities for Adaptalyfe

## Required Capabilities for Adaptalyfe

When creating your App ID in Apple Developer portal, select these capabilities:

### Core Capabilities (Required)
- **App Groups** - For sharing data between app and extensions
- **Associated Domains** - For website association (adaptalyfeapp.com)
- **Background App Refresh** - For medication reminders and sync
- **Push Notifications** - For appointment/medication alerts
- **Sign in with Apple** - For user authentication (optional but recommended)

### Health & Medical Features
- **HealthKit** - For health data integration (mood tracking, medical info)
- **Data Protection** - For HIPAA compliance and secure data storage

### Communication Features
- **App-to-App Audio** - For voice commands and TTS features
- **Siri** - For voice-activated task management
- **Background Processing** - For offline sync and data backup

### Location & Safety Features
- **Location Services** - For geofencing and safety features
- **Background Location** - For caregiver location sharing
- **Emergency SOS** - For emergency contact features

### Financial Integration
- **Apple Pay** - For subscription payments (optional)
- **In-App Purchase** - For premium subscriptions
- **Keychain Sharing** - For secure credential storage

### Additional Features
- **Camera** - For profile pictures and visual task guides
- **Contacts** - For emergency contact integration
- **Calendar** - For appointment scheduling
- **Reminders** - For task integration with iOS reminders

## App ID Creation Steps

1. **Go to**: https://developer.apple.com/account/
2. **Navigate**: Certificates, Identifiers & Profiles > Identifiers
3. **Click**: + button
4. **Select**: App IDs
5. **Choose**: App (not App Clip)

## App ID Details

**Description**: Adaptalyfe - Independence Building App
**Bundle ID**: com.adaptalyfe.app (or your preferred bundle ID)
**Platform**: iOS, tvOS (select iOS)

## Capability Selection Guide

### Essential (Select These):
- ✅ Push Notifications
- ✅ Background App Refresh  
- ✅ App Groups
- ✅ Associated Domains
- ✅ Data Protection
- ✅ In-App Purchase

### Medical/Health Features:
- ✅ HealthKit
- ✅ Background Processing

### Communication:
- ✅ Siri
- ✅ App-to-App Audio

### Location/Safety:
- ✅ Location Services
- ✅ Background Location

### Optional but Recommended:
- ✅ Sign in with Apple
- ✅ Apple Pay
- ✅ Camera
- ✅ Contacts
- ✅ Calendar

## Important Notes

**Bundle ID Format**: Use reverse domain notation
- Example: `com.adaptalyfe.app`
- Must be unique across all apps

**Capability Changes**: Can modify capabilities later, but may require new provisioning profiles

**Testing**: Some capabilities require physical device testing (notifications, location, etc.)

**App Store Review**: Ensure your app actually uses selected capabilities or Apple may reject

## After App ID Creation

1. **Create Provisioning Profile** using your new App ID
2. **Download and install** provisioning profile
3. **Configure Xcode project** with Bundle ID and capabilities
4. **Test on device** to verify capabilities work

Your App ID enables all the advanced features that make Adaptalyfe a comprehensive neurodevelopmental support application.