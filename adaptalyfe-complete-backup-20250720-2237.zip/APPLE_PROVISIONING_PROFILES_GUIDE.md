# Apple Provisioning Profiles for Adaptalyfe

## Two Types of Provisioning Profiles Needed

### 1. Development Provisioning Profile
**Purpose**: Testing your app on physical devices during development
**When to use**: While building and testing your app
**Devices**: Limited to registered test devices (up to 100)

### 2. Distribution Provisioning Profile  
**Purpose**: Submitting your app to the App Store
**When to use**: Final app submission to App Store Connect
**Devices**: All iOS devices (public release)

## What You Need Right Now

For **App Store submission**, you need:
- ✅ **Distribution Certificate** (you already have this from your CSR)
- ✅ **Distribution Provisioning Profile** (create this next)

## Creating Distribution Provisioning Profile

### Step 1: Go to Provisioning Profiles
1. Apple Developer portal > Certificates, Identifiers & Profiles
2. Click **Profiles** in sidebar
3. Click **+** button

### Step 2: Select Distribution Type
- Choose **App Store** (not Ad Hoc or Enterprise)
- This allows unlimited distribution through App Store

### Step 3: Select Your App ID
- Choose the Adaptalyfe App ID you just created
- Should show: `com.adaptalyfe.app` (or your chosen Bundle ID)

### Step 4: Select Distribution Certificate
- Choose the certificate you generated with your CSR
- Should be labeled "iOS Distribution"

### Step 5: Name and Generate
- **Profile Name**: `Adaptalyfe App Store Distribution`
- Click **Generate**
- Download the `.mobileprovision` file

## Profile Types Explained

| Profile Type | Purpose | Certificate Needed | Device Limit |
|--------------|---------|-------------------|---------------|
| **Development** | Testing on devices | iOS Development | 100 registered devices |
| **App Store Distribution** | App Store submission | iOS Distribution | Unlimited (public) |
| **Ad Hoc** | Beta testing | iOS Distribution | 100 registered devices |
| **Enterprise** | Internal company apps | Enterprise Certificate | Unlimited internal |

## For Your App Store Submission

**You need**:
1. ✅ iOS Distribution Certificate (you have this)
2. ⏳ App Store Distribution Provisioning Profile (create this now)
3. ⏳ App Store Connect app record
4. ⏳ Signed iOS app bundle (.ipa file)

## Installation and Usage

### Download Profile
- Save the `.mobileprovision` file to your Mac
- Double-click to install in Xcode

### In Xcode
- Select your project
- Go to **Signing & Capabilities**
- Choose **Manual** signing
- Select your distribution provisioning profile

### For Build Services
If using cloud build services (EAS, Fastlane):
- Upload both certificate and provisioning profile
- Configure build settings with profile UUID

## Common Issues

**"No matching provisioning profile"**:
- Ensure Bundle ID matches exactly
- Check certificate is included in profile
- Verify capabilities match between App ID and profile

**"Profile expired"**:
- Provisioning profiles expire after 1 year
- Regenerate with same settings

## Next Steps After Profile Creation

1. **Create App Store Connect record** for Adaptalyfe
2. **Build signed iOS app** using distribution profile
3. **Upload to App Store Connect** for review
4. **Submit for App Store approval**

Your distribution provisioning profile is the key that allows your signed app to be submitted to the App Store.