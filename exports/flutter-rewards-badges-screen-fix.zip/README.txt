Adaptalyfe Flutter Rewards badges screen fix

Drop-in source file:
mobile_flutter/lib/features/rewards/presentation/rewards_screen.dart

Changes:
- The badge list now owns an explicit ScrollController and always-visible scrollbar.
- Badge sections appear before the instructions, making earned/progress/locked data easier to find.
- Added a scroll hint and extra bottom padding for short screens and navigation chrome.

This ZIP contains the changed Dart screen only; it is not a standalone Flutter project.
