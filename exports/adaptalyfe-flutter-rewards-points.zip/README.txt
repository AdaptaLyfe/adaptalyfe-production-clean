Adaptalyfe Flutter Rewards and Points source bundle

Scope
- Rewards and Daily Tasks feature Dart sources (presentation, BLoCs, repositories, APIs, models, and task schedule utility).
- App route registration and shared route/layout/network helpers used by these features.

Point earning behavior
- A Daily Task with a positive point value awards that value when completed.
- The Rewards screen explains this and links to Daily Tasks.

This is a focused source bundle, not a standalone Flutter project. Paths inside the archive are relative to the project root.
