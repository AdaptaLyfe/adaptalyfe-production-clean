import { Switch, Route } from "wouter";
import React from "react";
import SimpleNavigation from "@/components/simple-navigation";
import NotFound from "@/pages/not-found";
import Dashboard from "@/pages/dashboard";
import DailyTasks from "@/pages/daily-tasks";
import Financial from "@/pages/financial";
import MoodTracking from "@/pages/mood-tracking";
import Resources from "@/pages/resources";
import Caregiver from "@/pages/caregiver";
import Medical from "@/pages/medical";
import MealShopping from "@/pages/meal-shopping";
import Pharmacy from "@/pages/pharmacy";
import AcademicPlanner from "@/pages/academic-planner";
import AdminDashboard from "@/pages/admin-dashboard";
import SettingsPage from "@/pages/settings";
import Calendar from "@/pages/calendar";
import LifeSkillsModule from "@/components/life-skills-module";

import { useAutoDemo } from "@/hooks/useAutoDemo";

// Lazy load components that are less frequently used
const PersonalDocuments = React.lazy(() => import("@/pages/personal-documents"));
const RewardsPage = React.lazy(() => import("@/pages/rewards"));



// Simple Route Component - no authentication required
function SimpleRoute({ component: Component }: { component: React.ComponentType }) {
  return <Component />;
}

function App() {
  const { isLoggingIn } = useAutoDemo();

  if (isLoggingIn) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-cyan-100 via-teal-50 to-blue-100 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin w-12 h-12 border-4 border-teal-600 border-t-transparent rounded-full mx-auto mb-4"></div>
          <p className="text-gray-600">Loading AdaptaLyfe Demo...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-cyan-100 via-teal-50 to-blue-100">
      <SimpleNavigation />
      
      <Switch>
        <Route path="/" component={Dashboard} />
        <Route path="/dashboard" component={Dashboard} />
        <Route path="/daily-tasks" component={DailyTasks} />
        <Route path="/financial" component={Financial} />
        <Route path="/mood-tracking" component={MoodTracking} />
        <Route path="/calendar" component={Calendar} />
        <Route path="/medical" component={Medical} />
        <Route path="/meal-shopping" component={MealShopping} />
        <Route path="/pharmacy" component={Pharmacy} />
        <Route path="/academic-planner" component={AcademicPlanner} />
        <Route path="/resources" component={Resources} />
        <Route path="/caregiver" component={Caregiver} />
        <Route path="/task-builder" component={LifeSkillsModule} />
        <Route path="/admin" component={AdminDashboard} />
        <Route path="/admin-dashboard" component={AdminDashboard} />
        <Route path="/settings" component={SettingsPage} />
        <Route path="/personal-documents" component={() => (
          <React.Suspense fallback={
            <div className="container mx-auto p-6">
              <div className="max-w-6xl mx-auto">
                <div className="animate-pulse">
                  <div className="h-8 bg-gray-300 rounded w-64 mb-6"></div>
                  <div className="bg-white rounded-lg border p-6">
                    <div className="h-4 bg-gray-300 rounded w-32 mb-4"></div>
                    <div className="h-4 bg-gray-300 rounded w-48 mb-2"></div>
                    <div className="h-4 bg-gray-300 rounded w-40"></div>
                  </div>
                </div>
              </div>
            </div>
          }>
            <PersonalDocuments />
          </React.Suspense>
        )} />
        
        <Route path="/rewards" component={() => (
          <React.Suspense fallback={
            <div className="container mx-auto p-6">
              <div className="max-w-6xl mx-auto">
                <div className="animate-pulse">
                  <div className="h-8 bg-gray-300 rounded w-64 mb-6"></div>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {[1, 2, 3].map((i) => (
                      <div key={i} className="bg-white rounded-lg border p-6">
                        <div className="h-4 bg-gray-300 rounded w-32 mb-4"></div>
                        <div className="h-4 bg-gray-300 rounded w-48 mb-2"></div>
                        <div className="h-4 bg-gray-300 rounded w-40"></div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          }>
            <RewardsPage />
          </React.Suspense>
        )} />

        <Route component={NotFound} />
      </Switch>
    </div>
  );
}

export default App;
