import{W as n}from"./index-B6iVYbnq.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};
