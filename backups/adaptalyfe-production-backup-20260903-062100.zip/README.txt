AdaptaLyfe production database backup
=====================================
Created (UTC): 20260903-062100
Format: PostgreSQL custom archive (schema and data)
Archive entries validated: 514
Dump size (bytes): 5435733
Dump SHA-256: 29a07634d3eb21359b72affc0b25b9a6620f46dc2c70870528de253aaebb6c83

Restore with PostgreSQL client tools:
  pg_restore --dbname=TARGET_DATABASE --no-owner --no-privileges adaptalyfe-production-20260903-062100.dump

This archive contains database contents. Keep it in protected storage.
No database credentials are included in this ZIP.
