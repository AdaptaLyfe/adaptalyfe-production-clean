import React from 'react';

interface ErrorBoundaryState {
  hasError: boolean;
  error?: Error;
}

interface ErrorBoundaryProps {
  children: React.ReactNode;
}

export class ReactErrorBoundary extends React.Component<ErrorBoundaryProps, ErrorBoundaryState> {
  constructor(props: ErrorBoundaryProps) {
    super(props);
    this.state = { hasError: false };
  }

  static getDerivedStateFromError(error: Error): ErrorBoundaryState {
    // Suppress useRef and Stripe-related errors completely
    if (error.message && (
      error.message.includes('useRef') ||
      error.message.includes('Failed to load Stripe.js') ||
      error.message.includes('Stripe') ||
      error.message.includes('stripe') ||
      error.message.includes('Cannot read properties of null')
    )) {
      // Don't update state for these errors, just ignore them
      return { hasError: false };
    }
    
    // Only show error boundary for genuine application errors
    return { hasError: true, error };
  }

  componentDidCatch(error: Error, errorInfo: React.ErrorInfo) {
    // Suppress useRef and Stripe-related errors from logging
    if (error.message && (
      error.message.includes('useRef') ||
      error.message.includes('Failed to load Stripe.js') ||
      error.message.includes('Stripe') ||
      error.message.includes('stripe') ||
      error.message.includes('Cannot read properties of null')
    )) {
      return; // Don't log these errors
    }
    
    console.error('React Error Boundary caught an error:', error, errorInfo);
  }

  render() {
    if (this.state.hasError) {
      // Only show fallback UI for genuine errors, not for useRef/Stripe errors
      return (
        <div className="min-h-screen flex items-center justify-center bg-gray-50">
          <div className="max-w-md mx-auto text-center p-6">
            <div className="bg-white rounded-lg shadow-lg p-8">
              <div className="text-red-600 text-6xl mb-4">⚠️</div>
              <h1 className="text-2xl font-bold text-gray-900 mb-4">Oops! Something went wrong</h1>
              <p className="text-gray-600 mb-6">
                We encountered an unexpected error. Please try refreshing the page.
              </p>
              <button
                onClick={() => window.location.reload()}
                className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 transition-colors"
              >
                Refresh Page
              </button>
            </div>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}