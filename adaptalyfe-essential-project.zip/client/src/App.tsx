import { Switch, Route, useLocation } from "wouter";
import React, { Suspense } from "react";
import SimpleNavigation from "@/components/simple-navigation";
import MobileBottomNavigation from "@/components/mobile-bottom-navigation";
import AuthCheck from "@/components/AuthCheck";
import AdminCheck from "@/components/AdminCheck";

// Import critical pages directly (no lazy loading for auth flow)
import Landing from "@/pages/landing";
import Login from "@/pages/login";
import Register from "@/pages/register";
import Dashboard from "@/pages/dashboard";

// Lazy load all other pages to reduce initial bundle size
const NotFound = React.lazy(() => import("@/pages/not-found"));
const DailyTasks = React.lazy(() => import("@/pages/daily-tasks"));
const Financial = React.lazy(() => import("@/pages/financial"));
const MoodTracking = React.lazy(() => import("@/pages/mood-tracking"));
const Resources = React.lazy(() => import("@/pages/resources"));
const Caregiver = React.lazy(() => import("@/pages/caregiver"));
const CaregiverSetup = React.lazy(() => import("@/pages/caregiver-setup"));
const AcceptInvitation = React.lazy(() => import("@/pages/accept-invitation"));
const MobileAcceptInvitation = React.lazy(() => import("@/pages/mobile-accept-invitation"));
const MobileLogin = React.lazy(() => import("@/pages/mobile-login"));
const InviteLanding = React.lazy(() => import("@/pages/invite-landing"));
const Medical = React.lazy(() => import("@/pages/medical"));
const MealShopping = React.lazy(() => import("@/pages/meal-shopping"));
const Pharmacy = React.lazy(() => import("@/pages/pharmacy"));
const AcademicPlanner = React.lazy(() => import("@/pages/academic-planner"));
const SkillsMilestones = React.lazy(() => import("@/pages/skills-milestones"));
const AdminDashboard = React.lazy(() => import("@/pages/admin-dashboard"));
const CaregiverDashboard = React.lazy(() => import("@/pages/caregiver-dashboard"));
const SettingsPage = React.lazy(() => import("@/pages/settings"));
const Calendar = React.lazy(() => import("@/pages/calendar"));
const Features = React.lazy(() => import("@/pages/features"));
const Subscription = React.lazy(() => import("@/pages/subscription"));
const DirectPayment = React.lazy(() => import("@/pages/direct-payment"));
const LifeSkillsModule = React.lazy(() => import("@/components/life-skills-module"));
const PersonalDocuments = React.lazy(() => import("@/pages/personal-documents"));
const RewardsPage = React.lazy(() => import("@/pages/rewards"));
const SleepTracking = React.lazy(() => import("@/pages/sleep-tracking"));

import { RuntimeErrorHandler } from "@/components/runtime-error-handler";
import { ReactErrorBoundary } from "@/lib/react-error-boundary";
import { useSubscriptionEnforcement } from "@/middleware/subscription-middleware";

// Global error handler for Stripe loading issues
const originalError = console.error;
console.error = (...args) => {
  const message = args.join(' ');
  if (message.includes('Failed to load Stripe') || message.includes('stripe')) {
    console.warn('Stripe error suppressed:', message);
    return;
  }
  originalError.apply(console, args);
};

// Suppress Stripe-related errors from showing in the UI
window.addEventListener('error', (event) => {
  if (event.message?.includes('Failed to load Stripe') || 
      event.message?.includes('stripe') ||
      event.filename?.includes('stripe')) {
    event.stopImmediatePropagation();
    event.preventDefault();
    return false;
  }
});

window.addEventListener('unhandledrejection', (event) => {
  if (String(event.reason).includes('Stripe') || 
      String(event.reason).includes('stripe')) {
    event.stopImmediatePropagation();
    event.preventDefault();
    return false;
  }
});

// Loading component for lazy-loaded pages
const PageLoader = () => (
  <div className="min-h-[50vh] flex items-center justify-center">
    <div className="text-center">
      <div className="animate-spin w-8 h-8 border-4 border-teal-600 border-t-transparent rounded-full mx-auto mb-4"></div>
      <p className="text-gray-600">Loading...</p>
    </div>
  </div>
);

// Lazy Route Component wrapper
function LazyRoute({ component: Component }: { component: React.ComponentType }) {
  return (
    <Suspense fallback={<PageLoader />}>
      <Component />
    </Suspense>
  );
}

function App() {
  const [location] = useLocation();
  
  // Initialize subscription enforcement for global use
  useSubscriptionEnforcement();
  
  // Completely disable auto demo for production testing
  const isLoggingIn = false;

  if (isLoggingIn) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-cyan-100 via-teal-50 to-blue-100 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin w-12 h-12 border-4 border-teal-600 border-t-transparent rounded-full mx-auto mb-4"></div>
          <p className="text-gray-600">Loading AdaptaLyfe Demo...</p>
        </div>
      </div>
    );
  }

  return (
    <ReactErrorBoundary>
      <div className="min-h-screen bg-gradient-to-br from-cyan-100 via-teal-50 to-blue-100">
      {/* Only show navigation for authenticated app routes, not for landing/auth pages */}
      {!["", "/", "/login", "/register", "/landing", "/debug-landing.html"].includes(location) && <SimpleNavigation />}
      
      <Switch>
        <Route path="/" component={Landing} />
        <Route path="/landing" component={Landing} />
        <Route path="/debug-landing.html" component={Landing} />
        <Route path="/login" component={() => {
          const isMobile = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
          return isMobile ? <Suspense fallback={<PageLoader />}><MobileLogin /></Suspense> : <Login />;
        }} />
        <Route path="/register" component={Register} />
        <Route path="/demo" component={Dashboard} />
        
        <Route path="/dashboard">
          <AuthCheck><Dashboard /></AuthCheck>
        </Route>
        <Route path="/subscription">
          <AuthCheck>
            <Suspense fallback={<PageLoader />}>
              <Subscription />
            </Suspense>
          </AuthCheck>
        </Route>
        <Route path="/direct-payment">
          <AuthCheck>
            <Suspense fallback={<PageLoader />}>
              <DirectPayment />
            </Suspense>
          </AuthCheck>
        </Route>
        <Route path="/daily-tasks">
          <AuthCheck>
            <Suspense fallback={<PageLoader />}>
              <DailyTasks />
            </Suspense>
          </AuthCheck>
        </Route>
        <Route path="/task-reminders" component={() => (
          <AuthCheck>
            <Suspense fallback={<PageLoader />}>
              {React.createElement(React.lazy(() => import("@/pages/task-reminders")))}
            </Suspense>
          </AuthCheck>
        )} />
        <Route path="/financial">
          <AuthCheck>
            <Suspense fallback={<PageLoader />}>
              <Financial />
            </Suspense>
          </AuthCheck>
        </Route>
        <Route path="/mood-tracking">
          <AuthCheck>
            <Suspense fallback={<PageLoader />}>
              <MoodTracking />
            </Suspense>
          </AuthCheck>
        </Route>
        <Route path="/sleep-tracking">
          <AuthCheck>
            <Suspense fallback={<PageLoader />}>
              <SleepTracking />
            </Suspense>
          </AuthCheck>
        </Route>
        <Route path="/calendar">
          <AuthCheck>
            <Suspense fallback={<PageLoader />}>
              <Calendar />
            </Suspense>
          </AuthCheck>
        </Route>
        <Route path="/medical">
          <AuthCheck>
            <Suspense fallback={<PageLoader />}>
              <Medical />
            </Suspense>
          </AuthCheck>
        </Route>
        <Route path="/meal-shopping">
          <AuthCheck>
            <Suspense fallback={<PageLoader />}>
              <MealShopping />
            </Suspense>
          </AuthCheck>
        </Route>
        <Route path="/pharmacy">
          <AuthCheck>
            <Suspense fallback={<PageLoader />}>
              <Pharmacy />
            </Suspense>
          </AuthCheck>
        </Route>
        <Route path="/academic-planner">
          <AuthCheck>
            <Suspense fallback={<PageLoader />}>
              <AcademicPlanner />
            </Suspense>
          </AuthCheck>
        </Route>
        <Route path="/skills-milestones">
          <AuthCheck>
            <Suspense fallback={<PageLoader />}>
              <SkillsMilestones />
            </Suspense>
          </AuthCheck>
        </Route>
        <Route path="/task-builder" component={() => (
          <AuthCheck>
            <React.Suspense fallback={
              <div className="container mx-auto p-6">
                <div className="max-w-6xl mx-auto">
                  <div className="animate-pulse">
                    <div className="h-8 bg-gray-300 rounded w-64 mb-6"></div>
                    <div className="bg-white rounded-lg border p-6">
                      <div className="h-4 bg-gray-300 rounded w-32 mb-4"></div>
                      <div className="h-4 bg-gray-300 rounded w-48 mb-2"></div>
                      <div className="h-4 bg-gray-300 rounded w-40"></div>
                    </div>
                  </div>
                </div>
              </div>
            }>
              {React.createElement(React.lazy(() => import("@/pages/task-builder")))}
            </React.Suspense>
          </AuthCheck>
        )} />
        <Route path="/rewards" component={() => (
          <AuthCheck>
            <React.Suspense fallback={
              <div className="container mx-auto p-6">
                <div className="max-w-6xl mx-auto">
                  <div className="animate-pulse">
                    <div className="h-8 bg-gray-300 rounded w-64 mb-6"></div>
                    <div className="bg-white rounded-lg border p-6">
                      <div className="h-4 bg-gray-300 rounded w-32 mb-4"></div>
                      <div className="h-4 bg-gray-300 rounded w-48 mb-2"></div>
                      <div className="h-4 bg-gray-300 rounded w-40"></div>
                    </div>
                  </div>
                </div>
              </div>
            }>
              <RewardsPage />
            </React.Suspense>
          </AuthCheck>
        )} />
        <Route path="/resources">
          <AuthCheck><Resources /></AuthCheck>
        </Route>
        <Route path="/caregiver">
          <AuthCheck><Caregiver /></AuthCheck>
        </Route>
        <Route path="/caregiver-setup">
          <AuthCheck><CaregiverSetup /></AuthCheck>
        </Route>
        <Route path="/invite" component={InviteLanding} />
        <Route path="/accept-invitation" component={() => {
          // Mobile device detection for invitation page
          const isMobile = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
          return isMobile ? <MobileAcceptInvitation /> : <AcceptInvitation />;
        }} />
        <Route path="/caregiver-dashboard">
          <AuthCheck><CaregiverDashboard /></AuthCheck>
        </Route>

        <Route path="/admin">
          <AdminCheck><AdminDashboard /></AdminCheck>
        </Route>
        <Route path="/admin-dashboard">
          <AdminCheck><AdminDashboard /></AdminCheck>
        </Route>
        <Route path="/settings">
          <AuthCheck><SettingsPage /></AuthCheck>
        </Route>
        <Route path="/features">
          <Features />
        </Route>
        <Route path="/subscription">
          <AuthCheck><Subscription /></AuthCheck>
        </Route>
        <Route path="/personal-documents" component={() => (
          <AuthCheck>
            <React.Suspense fallback={
              <div className="container mx-auto p-6">
                <div className="max-w-6xl mx-auto">
                  <div className="animate-pulse">
                    <div className="h-8 bg-gray-300 rounded w-64 mb-6"></div>
                    <div className="bg-white rounded-lg border p-6">
                      <div className="h-4 bg-gray-300 rounded w-32 mb-4"></div>
                      <div className="h-4 bg-gray-300 rounded w-48 mb-2"></div>
                      <div className="h-4 bg-gray-300 rounded w-40"></div>
                    </div>
                  </div>
                </div>
              </div>
            }>
              <PersonalDocuments />
            </React.Suspense>
          </AuthCheck>
        )} />
        
        <Route path="*" component={NotFound} />
      </Switch>
      
      {/* Mobile bottom navigation - only show on authenticated pages */}
      {!["", "/", "/login", "/register", "/landing", "/debug-landing.html"].includes(location) && <MobileBottomNavigation />}
      
      {/* Runtime error handler to prevent Replit modal */}
      <RuntimeErrorHandler />
      </div>
    </ReactErrorBoundary>
  );
}

export default App;
