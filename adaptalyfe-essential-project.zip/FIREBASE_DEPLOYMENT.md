# Firebase Deployment Guide - Simplified

This guide will help you deploy your Adaptalyfe app to Firebase without breaking anything.

## Prerequisites
1. Make sure you have a Google account
2. Go to [Firebase Console](https://console.firebase.google.com)
3. Create a new project (or use existing one)

## Step 1: Initialize Firebase (One-time setup)

**Option A - If you have a local terminal:**
```bash
# Login to Firebase (this opens a browser)
firebase login

# Initialize your project 
firebase init hosting
```

**Option B - If in Replit or browser environment:**
1. Go to [Firebase Console](https://console.firebase.google.com)
2. Create a new project (or select existing)
3. Copy your project ID
4. Update `.firebaserc` file with your project ID
5. Run: `firebase use --add` and select your project

When prompted:
- Choose "Use an existing project" and select your Firebase project
- Set public directory to: **dist/public**
- Configure as single-page app: **Yes**
- Set up automatic builds: **No**

## Step 2: Update Configuration
1. Edit `.firebaserc` and replace `"your-project-id"` with your actual Firebase project ID
2. Edit `firebase.json` and replace `"your-backend-url.com"` with your backend hosting URL (if you have one)

## Step 3: Build and Deploy
```bash
# Build the client-side app
vite build

# Deploy to Firebase
npx firebase deploy --only hosting
```

## Step 4: Access Your App
After deployment, Firebase will give you a URL like:
`https://your-project-id.web.app`

## Important Notes:
- **This only deploys the frontend** - your React app
- **Backend/API won't work** unless you deploy it separately (to Railway, Heroku, etc.)
- The app will show login/subscription pages but backend features need a separate deployment
- All your current functionality will remain intact in your local development

## Quick Deploy Script
Save this as `deploy.sh`:
```bash
#!/bin/bash
echo "Building client..."
vite build
echo "Deploying to Firebase..."
npx firebase deploy --only hosting
echo "Done! Check your Firebase console for the URL."
```

Make it executable: `chmod +x deploy.sh`
Then run: `./deploy.sh`

## Troubleshooting:
- If build fails: Make sure `npm run dev` works first
- If Firebase CLI issues: Run `npm install -g firebase-tools`
- If permission issues: Check Firebase project permissions in console