#!/bin/bash

echo "🔥 Starting Firebase deployment for Adaptalyfe..."
echo ""

# Check if firebase tools is available
if ! command -v firebase &> /dev/null; then
    echo "Firebase CLI not found. Installing..."
    npm install -g firebase-tools
fi

# Build the client application
echo "🏗️  Building client application..."
vite build

if [ $? -ne 0 ]; then
    echo "❌ Build failed! Please fix build errors first."
    exit 1
fi

echo "✅ Build successful!"
echo ""

# Show bundle size summary
echo "📦 Bundle Size Summary:"
echo "======================"
cd dist/public/assets
ls -lah *.js | awk '{
  size = $5;
  file = $9;
  if (size ~ /M$/) print "🔴 LARGE: " file " (" size ")";
  else if (size ~ /[0-9][0-9][0-9]K$/) print "🟡 MEDIUM: " file " (" size ")";
  else print "🟢 SMALL: " file " (" size ")";
}' | head -10
cd ../../..
echo ""

# Check if user is logged in
if ! firebase projects:list &> /dev/null; then
    echo "❌ Not authenticated with Firebase."
    echo ""
    echo "Please run one of these commands first:"
    echo "  firebase login"
    echo "  firebase login:ci"
    echo ""
    echo "Then run this script again."
    exit 1
fi

# Deploy to Firebase
echo "🚀 Deploying to Firebase Hosting..."
npx firebase deploy --only hosting

if [ $? -eq 0 ]; then
    echo ""
    echo "🎉 Deployment successful!"
    echo "Your app is now live on Firebase!"
    echo "Check the Firebase Console for your app URL."
else
    echo "❌ Deployment failed. Check the errors above."
    exit 1
fi