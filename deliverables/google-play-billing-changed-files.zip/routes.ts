import type { Express } from "express";
import { createServer, type Server } from "http";
import path from "path";
import { storage, RewardRedemptionError } from "./storage";
import { buildAdaptAIContext, buildDailyGuideContext } from "./ai-context";
import {
  generateAdaptAIChatTurn,
  generateDailyGuide,
} from "./ai-service";
import {
  AdaptAIActionError,
  buildActionContext,
  executeAdaptAIAction,
  isPotentialTaskActionRequest,
} from "./ai-actions";
import { buildTodayBriefing, isTodayBriefingRequest } from "./today-briefing";
import {
  buildMoodSleepResponse,
  isMoodSleepRequest,
  shouldIncludeMoodSleepContext,
} from "./mood-sleep";
import {
  calculateSleepMetrics,
  DEFAULT_SLEEP_GOAL_MINUTES,
} from "@shared/sleep-calculations";
import { getSleepDateValidationError } from "@shared/sleep-date-validation";
import { getSleepRoutineTimeValidationError } from "@shared/sleep-time-validation";
import { FREE_TRIAL_DAYS } from "@shared/subscription";
import { buildNextAction, isNextActionRequest } from "./next-action";
import {
  buildTasksRoutinesResponse,
  isTasksRoutinesRequest,
} from "./tasks-routines";
import {
  buildAppointmentTransitionResponse,
  isAppointmentTransitionRequest,
} from "./appointment-transitions";
import {
  buildMedicationHealthResponse,
  isExplicitMedicalInformationRequest,
  isMedicationHealthRequest,
} from "./medication-health";
import {
  buildGoalsProgressRewardsResponse,
  isGoalsProgressRewardsRequest,
} from "./goals-progress-rewards";
import {
  buildMealsGroceryResponse,
  isMealsGroceryRequest,
  shouldIncludeMealsGroceryContext,
} from "./meals-grocery";
import {
  buildFinanceResponse,
  isFinanceRequest,
  shouldIncludeFinanceContext,
} from "./finance";
import { buildCaregiverContextResponse } from "./caregiver-context";
import OpenAI from "openai";
import Stripe from "stripe";
import bankingRoutes from "./banking-routes";
import { registerAnalyticsRoutes } from "./analytics-routes";
import { registerBillPaymentRoutes } from "./bill-payment-routes";
import session from "express-session";
import connectPgSimple from "connect-pg-simple";
import pg from "pg";
import crypto from "crypto";
import bcrypt from "bcryptjs";
import { sendPasswordResetEmail } from "./email-service";

function isValidCalendarDate(value: unknown): value is string {
  if (typeof value !== "string" || !/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
  const parsed = new Date(`${value}T00:00:00.000Z`);
  return !Number.isNaN(parsed.getTime()) && parsed.toISOString().startsWith(`${value}T`);
}

function getRequestCalendarDate(req: any): string {
  const requestedDate = req.query?.date;
  if (isValidCalendarDate(requestedDate)) return requestedDate;

  const timeZone = req.get?.("X-User-Timezone");
  if (typeof timeZone === "string") {
    try {
      const parts = new Intl.DateTimeFormat("en-US", {
        timeZone,
        year: "numeric",
        month: "2-digit",
        day: "2-digit",
      }).formatToParts(new Date());
      const values = Object.fromEntries(
        parts.filter((part) => part.type !== "literal").map((part) => [part.type, part.value]),
      );
      const localDate = `${values.year}-${values.month}-${values.day}`;
      if (isValidCalendarDate(localDate)) return localDate;
    } catch {
      // Fall through to the server calendar date for malformed timezone headers.
    }
  }

  return new Date().toISOString().slice(0, 10);
}

// Extend the session data interface
declare module "express-session" {
  interface SessionData {
    userId?: number;
    user?: any;
  }
}

// Initialize Stripe with dynamic key support
function getStripeInstance() {
  const stripeSecretKey = process.env.STRIPE_SECRET_KEY;
  if (!stripeSecretKey) {
    console.warn('STRIPE_SECRET_KEY not found, using demo mode');
    return null;
  }

  console.log(`Stripe configured in ${stripeSecretKey.startsWith('sk_test_') ? 'test' : 'live'} mode`);

  return new Stripe(stripeSecretKey, {
    apiVersion: "2025-07-30.basil",
  });
}

function getStripePeriodEndSeconds(subscription: any): number {
  // Newer Stripe API versions may expose the billing period on the
  // subscription item instead of the top-level subscription.
  const candidates = [
    subscription?.current_period_end,
    subscription?.items?.data?.[0]?.current_period_end,
  ];
  const periodEnd = candidates
    .map((value) => typeof value === "number" ? value : Number(value))
    .find((value) => Number.isFinite(value) && value > 0);

  if (periodEnd === undefined) {
    throw new Error(
      `Stripe subscription ${subscription?.id || "unknown"} has no valid current_period_end`
    );
  }

  return periodEnd;
}

function publicUser(user: any): any {
  if (!user) return user;
  const { password: _password, ...safeUser } = user;
  return safeUser;
}

async function verifyAndUpgradePassword(user: any, password: string): Promise<boolean> {
  const isHash = /^\$2[aby]?\$\d{2}\$/.test(user.password);
  const valid = isHash
    ? await bcrypt.compare(password, user.password)
    : user.password === password;

  if (valid && !isHash) {
    await storage.updateUser(user.id, { password: await bcrypt.hash(password, 12) });
  }

  return valid;
}

// Stripe instance is created dynamically when needed
import { 
  insertDailyTaskSchema, insertBillSchema, insertBankAccountSchema, insertMoodEntrySchema, 
  insertAchievementSchema, insertCaregiverSchema, insertEmergencyContactSchema, updateEmergencyContactSchema, insertMessageSchema,
  insertBudgetEntrySchema, insertSavingsGoalSchema, insertSavingsTransactionSchema, 
  insertBudgetCategorySchema, insertAppointmentSchema, insertMealPlanSchema,
  insertShoppingListSchema, updateShoppingItemPurchasedSchema, insertGroceryStoreSchema, loginSchema, registerSchema, insertPharmacySchema, insertUserPharmacySchema,
  insertMedicationSchema, insertRefillOrderSchema, insertPersonalResourceSchema,
  insertBusScheduleSchema, insertEmergencyTreatmentPlanSchema,
  insertNotificationSchema, insertUserPreferencesSchema, insertUserAchievementSchema,
  insertStreakTrackingSchema, insertVoiceInteractionSchema, insertQuickResponseSchema,
  insertMessageReactionSchema, insertActivityPatternSchema, insertEmergencyResourceSchema,
  insertTransitionSkillSchema
} from "@shared/schema";
import { z } from "zod";
import { initializeComprehensiveDemo } from "./demo-data";
import { shouldAllowAutoLogin, shouldInitializeDemoData, PRODUCTION_CONFIG } from "./production-config";
import { configureForProduction } from "./production-environment";

const transitionSkillUpdateSchema = z
  .object({
    skillCategory: z.string().min(1).optional(),
    skillName: z.string().min(1).optional(),
    description: z.string().nullable().optional(),
    currentLevel: z.number().int().min(1).max(10).optional(),
    targetLevel: z.number().int().min(1).max(10).optional(),
    priority: z.enum(["low", "medium", "high", "critical"]).optional(),
    practiceActivities: z.array(z.string()).optional(),
  })
  .refine(
    (value) =>
      value.currentLevel === undefined ||
      value.targetLevel === undefined ||
      value.currentLevel <= value.targetLevel,
    {
      message: "Current level cannot be greater than target level.",
      path: ["targetLevel"],
    },
  );

// Initialize OpenAI
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

// Enhanced fallback responses when OpenAI is unavailable
function getFallbackResponse(message: string): string {
  const lowerMessage = message.toLowerCase();
  
  // Help and How-to questions
  if (lowerMessage.includes('help') || lowerMessage.includes('how') || lowerMessage.includes('what')) {
    if (lowerMessage.includes('app') || lowerMessage.includes('feature') || lowerMessage.includes('use')) {
      return "I'd love to help you navigate AdaptaLyfe! Here's what you can do:\n\n• **Daily Tasks**: Plan and track your daily activities\n• **Financial**: Manage bills, budgets, and savings goals\n• **Mood Tracking**: Log how you're feeling each day\n• **Medical**: Track medications and appointments\n• **Caregiver Connection**: Stay in touch with your support team\n• **Meal Planning**: Plan healthy meals and shopping lists\n• **Calendar**: Keep track of important dates\n\nWhich area would you like to explore first?";
    }
    return "I'm here to help you build independence and achieve your goals! I can assist with:\n\n• Creating daily routines and task lists\n• Managing money and budgets\n• Understanding medications and health\n• Connecting with your support network\n• Learning new life skills\n• Handling difficult emotions\n• Planning meals and shopping\n• Organizing your schedule\n\nWhat would you like help with today?";
  }
  
  // Emotional support responses
  if (lowerMessage.includes('sad') || lowerMessage.includes('down') || lowerMessage.includes('upset') || lowerMessage.includes('anxious') || lowerMessage.includes('worried')) {
    return "I understand you're going through a tough time, and it's completely normal to have these feelings. You're not alone. Here are some things that can help:\n\n• **Breathe slowly**: Take 5 deep breaths in and out\n• **Talk to someone**: Reach out to a caregiver or friend\n• **Do something small**: Complete one easy task to feel accomplished\n• **Practice self-care**: Listen to music, take a walk, or do something you enjoy\n• **Remember your strengths**: Think about recent successes you've had\n\nIf these feelings continue, please talk to a trusted caregiver or healthcare provider. You matter and your feelings are valid.";
  }
  
  // Task and routine management
  if (lowerMessage.includes('task') || lowerMessage.includes('todo') || lowerMessage.includes('routine') || lowerMessage.includes('schedule') || lowerMessage.includes('organize')) {
    return "Building good routines is a key independence skill! Here's my step-by-step approach:\n\n**Getting Started:**\n• Begin with just 2-3 simple tasks daily\n• Choose the same time each day for consistency\n• Write tasks down or use the Daily Tasks feature\n\n**Making Tasks Easier:**\n• Break big tasks into small steps\n• Set realistic goals you can achieve\n• Celebrate each completion, no matter how small\n\n**Building Habits:**\n• Start with things you already do (like brushing teeth)\n• Add new tasks one at a time\n• Use reminders and alarms\n\nWould you like help creating a specific routine or organizing a particular task?";
  }
  
  // Financial management
  if (lowerMessage.includes('money') || lowerMessage.includes('budget') || lowerMessage.includes('bill') || lowerMessage.includes('save') || lowerMessage.includes('spend')) {
    return "Managing money wisely is an important life skill! Here's how to get started:\n\n**Budgeting Basics:**\n• List your monthly income (job, benefits, family support)\n• Track your essential expenses (rent, food, bills)\n• Set aside money for savings, even if it's small\n• Use the Financial section to monitor spending\n\n**Bill Management:**\n• Set up payment reminders for due dates\n• Keep important account information in a safe place\n• Ask for help understanding bills you don't recognize\n• Pay essential bills first (housing, utilities, food)\n\n**Smart Spending:**\n• Compare prices before big purchases\n• Wait 24 hours before buying non-essential items\n• Look for discounts and sales\n\nWould you like help setting up a specific budget or understanding a particular bill?";
  }
  
  // Health and medication
  if (lowerMessage.includes('medication') || lowerMessage.includes('medicine') || lowerMessage.includes('pill') || lowerMessage.includes('doctor') || lowerMessage.includes('health')) {
    return "Taking care of your health is very important! Here's how to stay organized:\n\n**Medication Safety:**\n• Take medications exactly as prescribed\n• Use the Pharmacy section to track all your medicines\n• Set daily reminders for pill times\n• Never skip doses without talking to your doctor first\n• Keep a list of all medications with you\n\n**Doctor Appointments:**\n• Write down questions before visits\n• Bring a list of your medications\n• Ask for clarification if you don't understand something\n• Use the Calendar feature to track appointments\n\n**Emergency Information:**\n• Keep emergency contacts easily accessible\n• Know your allergies and medical conditions\n• Have a plan for medical emergencies\n\nRemember: Always consult with healthcare professionals for medical advice. I can help you stay organized, but your doctors are the experts!";
  }
  
  // Cooking and meal planning
  if (lowerMessage.includes('cook') || lowerMessage.includes('food') || lowerMessage.includes('meal') || lowerMessage.includes('eat') || lowerMessage.includes('recipe')) {
    return "Cooking and eating well are important for your health and independence! Here are some tips:\n\n**Easy Cooking Tips:**\n• Start with simple recipes (sandwiches, pasta, eggs)\n• Read recipes completely before starting\n• Gather all ingredients first\n• Keep your cooking area clean and safe\n• Ask for help when trying new techniques\n\n**Meal Planning:**\n• Plan 3-4 simple meals for the week\n• Make a shopping list before going to the store\n• Use the Meal Planning feature to stay organized\n• Include fruits and vegetables in your meals\n• Keep healthy snacks available\n\n**Food Safety:**\n• Wash hands before cooking\n• Check expiration dates\n• Store food properly\n• Cook meat thoroughly\n\nWould you like help planning meals for this week or learning a specific cooking skill?";
  }
  
  // Social and communication
  if (lowerMessage.includes('friend') || lowerMessage.includes('social') || lowerMessage.includes('talk') || lowerMessage.includes('communicate') || lowerMessage.includes('caregiver')) {
    return "Building and maintaining relationships is a wonderful part of life! Here's how to strengthen your connections:\n\n**Staying Connected:**\n• Use the Caregiver features to message your support team\n• Schedule regular check-ins with friends and family\n• Share your successes and challenges with trusted people\n• Ask for help when you need it - that's what support networks are for!\n\n**Making New Friends:**\n• Join activities or groups that interest you\n• Be yourself and show genuine interest in others\n• Start with small conversations\n• Remember that friendships take time to develop\n\n**Communication Tips:**\n• Listen actively when others speak\n• Ask questions to show you're interested\n• Share your own experiences and feelings\n• Be patient and kind with yourself and others\n\nYour support team is here because they care about you. Don't hesitate to reach out when you need encouragement or assistance!";
  }
  
  // Learning and skills
  if (lowerMessage.includes('learn') || lowerMessage.includes('skill') || lowerMessage.includes('independence') || lowerMessage.includes('grow')) {
    return "Learning new skills is exciting and helps you become more independent! Here's how to approach it:\n\n**Learning Strategies:**\n• Break skills into small, manageable steps\n• Practice regularly, even for just a few minutes\n• Don't be afraid to make mistakes - they're part of learning\n• Ask questions when you don't understand\n• Celebrate small improvements\n\n**Independence Skills to Focus On:**\n• Personal care (hygiene, dressing, grooming)\n• Household tasks (cleaning, laundry, organization)\n• Money management (budgeting, shopping, bill paying)\n• Communication (phone calls, emails, asking for help)\n• Transportation (public transit, walking safety)\n• Health management (medication, appointments, self-care)\n\n**Getting Support:**\n• Use the Task Builder feature for step-by-step guides\n• Practice with a trusted caregiver or friend\n• Take your time - everyone learns at their own pace\n• Ask for help when you need it\n\nWhat new skill would you like to work on? I can help you break it down into manageable steps!";
  }
  
  // Technology and app usage
  if (lowerMessage.includes('app') || lowerMessage.includes('phone') || lowerMessage.includes('computer') || lowerMessage.includes('technology')) {
    return "Technology can be a great tool for independence! Here's how to make the most of it:\n\n**Using AdaptaLyfe Effectively:**\n• Explore each section (Daily Tasks, Financial, Mood, etc.)\n• Set up reminders and notifications\n• Update your information regularly\n• Use the search features to find what you need\n• Ask caregivers for help if you get stuck\n\n**General Technology Tips:**\n• Keep your devices charged and updated\n• Use simple passwords you can remember\n• Learn one new feature at a time\n• Don't be afraid to explore and experiment\n• Ask for help from tech-savvy friends or family\n\n**Safety Online:**\n• Don't share personal information with strangers\n• Be careful about clicking unknown links\n• Keep your private information secure\n• Ask for help if something seems suspicious\n\nRemember: Technology should make your life easier, not more stressful. Take your time learning, and don't hesitate to ask for support!";
  }
  
  // Default encouraging response with more comprehensive support
  return "Thank you for reaching out! I'm AdaptAI, and I'm here to support you on your independence journey. While I'm having some technical difficulties with my advanced features right now, I want you to know:\n\n**You're Doing Great!**\n• Using AdaptaLyfe shows you're taking charge of your independence\n• Every question you ask helps you learn and grow\n• It's completely normal to need support - we all do!\n• Your caregivers and support team believe in you\n\n**What I Can Help With:**\n• Daily task planning and organization\n• Money management and budgeting\n• Health and medication tracking\n• Meal planning and cooking tips\n• Building life skills and confidence\n• Connecting with your support network\n\n**Next Steps:**\n• Explore the different sections of the app\n• Try setting up a simple daily routine\n• Reach out to your caregivers if you need extra support\n• Remember that every small step forward is progress!\n\nIs there a specific area where you'd like to start? I'm here to help guide you through it!";
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Add health check endpoint for Railway
  app.get("/api/health", (req, res) => {
    res.json({ 
      status: "OK", 
      environment: process.env.NODE_ENV,
      timestamp: new Date().toISOString(),
      version: "1.0.0"
    });
  });

  app.get("/api/firebase-config", (req, res) => {
    const projectId = process.env.VITE_FIREBASE_PROJECT_ID;
    const apiKey = process.env.VITE_FIREBASE_API_KEY;
    const appId = process.env.VITE_FIREBASE_APP_ID;
    if (!projectId || !apiKey || !appId) {
      return res.json({ configured: false });
    }
    res.json({
      configured: true,
      apiKey,
      authDomain: `${projectId}.firebaseapp.com`,
      projectId,
      storageBucket: `${projectId}.firebasestorage.app`,
      appId,
    });
  });

  // Add debug endpoint for Railway troubleshooting
  app.get("/api/debug", (req, res) => {
    res.json({
      environment: process.env.NODE_ENV,
      hasDatabase: !!process.env.DATABASE_URL,
      hasStripe: !!process.env.STRIPE_SECRET_KEY,
      railwayDomain: req.get('host'),
      userAgent: req.get('user-agent'),
      origin: req.get('origin'),
      timestamp: new Date().toISOString()
    });
  });

  // Configure environment for production readiness
  configureForProduction();
  
  // Initialize comprehensive demo only in development or demo mode
  if (shouldInitializeDemoData()) {
    console.log("🚀 Demo mode enabled - initializing demo data");
    initializeComprehensiveDemo();
  } else {
    console.log("🏭 Production mode - skipping demo data initialization");
  }
  
  // Setup PostgreSQL session store for persistent sessions across Railway deployments
  const PgSession = connectPgSimple(session);
  const pgPool = new pg.Pool({
    connectionString: process.env.DATABASE_URL,
    ssl: process.env.DATABASE_URL?.includes('neon.tech') ? { rejectUnauthorized: false } : false,
    max: 5,
  });
  
  // Create session table if not exists
  pgPool.query(`
    CREATE TABLE IF NOT EXISTS "session" (
      "sid" varchar NOT NULL COLLATE "default",
      "sess" json NOT NULL,
      "expire" timestamp(6) NOT NULL,
      CONSTRAINT "session_pkey" PRIMARY KEY ("sid")
    );
    CREATE INDEX IF NOT EXISTS "IDX_session_expire" ON "session" ("expire");
  `).then(() => {
    console.log("✅ PostgreSQL session table ready");
  }).catch((err) => {
    console.error("⚠️ Session table setup error:", err.message);
  });
  
  const sessionStore = new PgSession({
    pool: pgPool,
    tableName: 'session',
    createTableIfMissing: true,
    pruneSessionInterval: 60 * 15, // Prune expired sessions every 15 minutes
  });

  // Native clients use their own session-store key rather than the browser's
  // cookie session ID. This keeps a mobile login independent from a web login
  // for the same account.
  const createMobileSessionToken = (user: any, cookie: any): Promise<string> => {
    const token = crypto.randomBytes(32).toString("hex");

    return new Promise((resolve, reject) => {
      sessionStore.set(
        token,
        {
          cookie: { ...cookie },
          userId: user.id,
          user: publicUser(user),
        } as any,
        (error: any) => {
          if (error) {
            reject(error);
            return;
          }
          resolve(token);
        },
      );
    });
  };

  const isNativeClientRequest = (req: any): boolean =>
    req.get("X-Adaptalyfe-Client") === "native";
  
  app.use(session({
    store: sessionStore,
    secret: process.env.SESSION_SECRET || 'demo-secret-key-change-in-production',
    resave: false,
    saveUninitialized: false,
    rolling: true,
    cookie: {
      secure: process.env.NODE_ENV === 'production',
      httpOnly: true,
      sameSite: 'lax',
      maxAge: 7 * 24 * 60 * 60 * 1000, // 7 days
    }
  }));
  
  // CRITICAL: Global middleware to check Authorization header for mobile auth
  // This runs BEFORE all endpoints and loads session from token if present
  app.use(async (req: any, res, next) => {
    const authHeader = req.get('Authorization');
    
    if (authHeader && authHeader.startsWith('Bearer ')) {
      const sessionToken = authHeader.substring(7);
      console.log("🔑 Authorization header found, attempting token auth with:", sessionToken.substring(0, 10) + "...");
      
      // Try to load session from store using the token
      await new Promise<void>((resolve) => {
        sessionStore.get(sessionToken, (err, sessionData) => {
          if (err) {
            console.log("❌ Session store error:", err);
            return resolve();
          }
          
          if (!sessionData || !sessionData.userId) {
            console.log("❌ Invalid or expired session token");
            return resolve();
          }
          
          // Keep bearer auth separate from the cookie session. Non-enumerable
          // compatibility properties let existing protected routes read the
          // authenticated user without persisting it into a browser session.
          req.auth = {
            sessionToken,
            userId: sessionData.userId,
            user: sessionData.user,
          };
          Object.defineProperties(req.session, {
            userId: {
              configurable: true,
              enumerable: false,
              value: sessionData.userId,
              writable: true,
            },
            user: {
              configurable: true,
              enumerable: false,
              value: sessionData.user,
              writable: true,
            },
          });
          console.log("✅ Session restored from Authorization token for user:", sessionData.user?.username);
          resolve();
        });
      });
    }
    
    next();
  });
  
  // Middleware to ensure user is logged in for protected routes
  // Supports both cookie-based (desktop) and header-based (mobile) auth
  const requireAuth = async (req: any, res: any, next: any) => {
    if (req.auth?.userId && req.auth?.user) {
      req.user = req.auth.user;
      return next();
    }

    // Check if already authenticated via cookie
    if (req.session.userId && req.session.user) {
      req.user = req.session.user;
      return next();
    }
    
    // Check for Authorization header (mobile fallback)
    const authHeader = req.get('Authorization');
    if (authHeader && authHeader.startsWith('Bearer ')) {
      const sessionToken = authHeader.substring(7);
      
      // Try to load session from store using the token
      return new Promise<void>((resolve) => {
        sessionStore.get(sessionToken, (err, sessionData) => {
          if (err || !sessionData || !sessionData.userId) {
            console.log("❌ Invalid session token - access denied");
            res.status(401).json({ message: "Authentication required" });
            return resolve();
          }
          
          // Restore session data
          req.session.userId = sessionData.userId;
          req.session.user = sessionData.user;
          req.user = sessionData.user;
          console.log("✅ Authenticated via header token:", sessionData.user.username);
          next();
          resolve();
        });
      });
    }
    
    console.log("❌ No authenticated user - access denied to protected route");
    return res.status(401).json({ message: "Authentication required" });
  };

  const genericResetResponse = {
    message: "If an account with that email exists, we sent password reset instructions.",
  };

  app.post("/api/forgot-password", async (req, res) => {
    const email = typeof req.body?.email === "string" ? req.body.email.trim().toLowerCase() : "";

    try {
      if (email) {
        const user = await storage.getUserByEmail(email);
        if (user?.email) {
          const rawToken = crypto.randomBytes(32).toString("base64url");
          const tokenHash = crypto.createHash("sha256").update(rawToken).digest("hex");
          await storage.invalidatePasswordResetTokens(user.id);
          await storage.createPasswordResetToken({
            userId: user.id,
            tokenHash,
            expiresAt: new Date(Date.now() + 60 * 60 * 1000),
          });

          try {
            const origin = `${req.protocol}://${req.get("host")}`;
            await sendPasswordResetEmail({
              to: user.email,
              name: user.name,
              token: rawToken,
              origin,
            });
          } catch {
            console.error("Password reset email delivery failed.");
          }
        }
      }
    } catch {
      // Always return the same response, including when lookup or delivery fails.
      console.error("Password reset request failed.");
    }

    return res.status(200).json(genericResetResponse);
  });

  app.get("/api/password-reset/validate", async (req, res) => {
    const token = typeof req.query.token === "string" ? req.query.token : "";
    if (!token) return res.status(400).json({ valid: false });

    try {
      const tokenHash = crypto.createHash("sha256").update(token).digest("hex");
      const valid = await storage.hasValidPasswordResetToken(tokenHash);
      return res.json({ valid });
    } catch {
      console.error("Password reset token validation failed.");
      return res.json({ valid: false });
    }
  });

  app.post("/api/reset-password", async (req, res) => {
    const token = typeof req.body?.token === "string" ? req.body.token : "";
    const password = typeof req.body?.password === "string" ? req.body.password : "";

    if (!token || password.length < 8 || password.length > 128) {
      return res.status(400).json({ message: "The reset link is invalid or the password does not meet the requirements." });
    }

    try {
      const tokenHash = crypto.createHash("sha256").update(token).digest("hex");
      const validToken = await storage.hasValidPasswordResetToken(tokenHash);
      if (!validToken) {
        return res.status(400).json({ message: "This reset link is invalid, expired, or has already been used." });
      }
      const passwordHash = await bcrypt.hash(password, 12);
      const didReset = await storage.resetPasswordWithToken(tokenHash, passwordHash);
      if (!didReset) {
        return res.status(400).json({ message: "This reset link is invalid, expired, or has already been used." });
      }

      return res.json({ message: "Password reset successfully. You can now sign in." });
    } catch (error) {
      console.error("Password reset failed:", error);
      return res.status(500).json({ message: "Unable to reset your password right now. Please request a new link." });
    }
  });

  // User registration endpoint
  app.post("/api/register", async (req, res) => {
    try {
      const { name, email, username, password, plan, subscribeNewsletter } = req.body;
      const nativeClient = isNativeClientRequest(req);
      
      // Validate required fields
      if (!username || !password || !name) {
        return res.status(400).json({ message: "Username, password, and name are required" });
      }
      
      // Check if username already exists
      const existingUser = await storage.getUserByUsername(username);
      if (existingUser) {
        return res.status(400).json({ message: "Username already exists" });
      }

      // Create new user
      const user = await storage.createUser({
        username,
        password: await bcrypt.hash(password, 12),
        name,
        email: email || null
      });

      if (!nativeClient) {
        // Browser sessions remain cookie-based.
        req.session.userId = user.id;
        req.session.user = publicUser(user);
        await new Promise<void>((resolve, reject) => {
          req.session.save((err: any) => {
            if (err) reject(err);
            else resolve();
          });
        });
      }

      const sessionToken = nativeClient
        ? await createMobileSessionToken(user, req.session.cookie)
        : undefined;

      res.json({ 
        message: "Registration successful",
        user: {
          id: user.id,
          username: user.username,
          name: user.name,
          email: user.email
        },
        ...(sessionToken ? { sessionToken } : {}),
      });
    } catch (error) {
      console.error("Registration error:", error);
      res.status(500).json({ message: "Registration failed" });
    }
  });

  // User login endpoint - Railway compatible
  app.post("/api/login", async (req, res) => {
    try {
      const { username, password } = req.body;
      const nativeClient = isNativeClientRequest(req);
      
      if (!username || !password) {
        console.log("❌ Missing credentials");
        return res.status(400).json({ message: "Username and password are required" });
      }
      
      const user = await storage.getUserByUsername(username);
      console.log("👤 User lookup result:", user ? `Found: ${user.username}` : "Not found");
      
      if (!user || !(await verifyAndUpgradePassword(user, password))) {
        console.log("❌ Invalid credentials for:", username);
        return res.status(401).json({ message: "Invalid credentials" });
      }

      if (!nativeClient) {
        // Browser sessions remain cookie-based.
        req.session.userId = user.id;
        req.session.user = publicUser(user);
        await new Promise<void>((resolve, reject) => {
          req.session.save((err: any) => {
            if (err) {
              console.log("❌ Session save error:", err);
              reject(err);
            } else {
              console.log("✅ Session saved successfully");
              resolve();
            }
          });
        });
      }

      const sessionToken = nativeClient
        ? await createMobileSessionToken(user, req.session.cookie)
        : undefined;

      console.log(`✅ User ${user.username} logged in successfully`);
      const response = { 
        message: "Login successful",
        user: { 
          id: user.id,
          username: user.username,
          name: user.name,
          email: user.email,
          isAdmin: user.isAdmin || false
        },
        ...(sessionToken ? { sessionToken } : {})
      };
      res.json(response);
    } catch (error) {
      console.error("❌ Login error:", error);
      res.status(500).json({ message: "Login failed", error: error.message });
    }
  });

  // Demo login endpoint
  app.post("/api/demo-login", async (req: any, res) => {
    try {
      const { username, password } = req.body;
      const nativeClient = isNativeClientRequest(req);
      console.log("Demo login attempt:", { username });
      
      const user = await storage.getUserByUsername(username);
      console.log("User found:", user ? { id: user.id, username: user.username } : "No user found");
      
      if (!user) {
        console.log("No user found for username:", username);
        return res.status(401).json({ message: "Invalid credentials" });
      }
      
      // Simple password check for demo (in production, use proper hashing)
      if (!(await verifyAndUpgradePassword(user, password))) {
        console.log("Password mismatch for user:", username);
        return res.status(401).json({ message: "Invalid credentials" });
      }
      
      if (!nativeClient) {
        req.session.userId = user.id;
        req.session.user = publicUser(user);
        await new Promise<void>((resolve, reject) => {
          req.session.save((error: any) => {
            if (error) {
              reject(error);
              return;
            }
            resolve();
          });
        });
      }

      const sessionToken = nativeClient
        ? await createMobileSessionToken(user, req.session.cookie)
        : undefined;

      res.json({
        message: "Login successful",
        user: {
          id: user.id,
          username: user.username,
          name: user.name,
          email: user.email
        },
        ...(sessionToken ? { sessionToken } : {})
      });
    } catch (error) {
      console.error("Demo login error:", error);
      res.status(500).json({ message: "Login failed" });
    }
  });

  // Logout endpoint
  app.post("/api/logout", async (req: any, res) => {
    try {
      const authHeader = req.get("Authorization");
      const mobileSessionToken = authHeader?.startsWith("Bearer ")
        ? authHeader.substring(7)
        : undefined;

      // A native logout only invalidates the independent bearer session. The
      // browser cookie session is intentionally left untouched so web and
      // mobile can remain signed in independently.
      if (mobileSessionToken) {
        return sessionStore.destroy(mobileSessionToken, (error: any) => {
          if (error) {
            console.error("Mobile session destruction error:", error);
            return res.status(500).json({ message: "Logout failed" });
          }

          res.json({ message: "Logout successful" });
        });
      }

      req.session.destroy((err: any) => {
        if (err) {
          console.error("Session destruction error:", err);
          return res.status(500).json({ message: "Logout failed" });
        }
        res.json({ message: "Logout successful" });
      });
    } catch (error) {
      console.error("Logout error:", error);
      res.status(500).json({ message: "Logout failed" });
    }
  });

  // Delete user account permanently
  app.delete("/api/user/delete-account", async (req: any, res) => {
    try {
      if (!req.session.userId) {
        return res.status(401).json({ message: "Not authenticated" });
      }

      const userId = req.session.userId;
      console.log(`🗑️ Deleting account for user ID: ${userId}`);

      // Delete all user data from various tables
      // Order matters due to foreign key constraints
      await storage.deleteUserAccount(userId);

      // Destroy the session
      req.session.destroy((err: any) => {
        if (err) {
          console.error("Session destruction error after account deletion:", err);
        }
      });

      console.log(`✅ Account deleted successfully for user ID: ${userId}`);
      res.json({ message: "Account deleted successfully" });
    } catch (error) {
      console.error("Account deletion error:", error);
      res.status(500).json({ message: "Failed to delete account" });
    }
  });

  // Get current user - mobile-optimized session handling
  app.get("/api/user", async (req: any, res) => {
    console.log("🔍 Checking session for user authentication");
    console.log("Session ID:", req.sessionID);
    console.log("User-Agent:", req.headers['user-agent']?.substring(0, 100));
    console.log("Cookies:", req.headers.cookie);
    console.log("Session user ID:", req.session.userId);
    
    // Check session validity and attempt recovery
    if (!req.session.userId || !req.session.user) {
      console.log("❌ No authenticated user found in session");
      
      // For mobile devices, try extra recovery attempts
      const isMobile = /Mobile|Android|iPhone|iPad/.test(req.headers['user-agent'] || '');
      console.log("📱 Mobile device detected:", isMobile);
      
      // Check if session exists but is corrupted - try to rebuild from userId
      if (req.session.userId && !req.session.user) {
        console.log("🔧 Attempting to rebuild user session from userId:", req.session.userId);
        try {
          const user = await storage.getUserById(req.session.userId);
          if (user) {
            req.session.user = user;
            await new Promise<void>((resolve, reject) => {
              req.session.save((err: any) => {
                if (err) {
                  console.error("Session save error:", err);
                  reject(err);
                } else {
                  console.log("✅ Session rebuilt successfully");
                  resolve();
                }
              });
            });
            const { password, ...userResponse } = user;
            await storage.refreshUserActivityStreak(user.id);
            const refreshedUser = await storage.getUserById(user.id);
            if (refreshedUser) {
              req.session.user = refreshedUser;
              const { password: _, ...refreshedResponse } = refreshedUser;
              return res.json(refreshedResponse);
            }
            return res.json(userResponse);
          }
        } catch (error) {
          console.error("Error rebuilding session:", error);
        }
      }
      
      return res.status(401).json({ message: "Authentication required", mobile: isMobile });
    }
    
    const sessionUser = req.session.user;
    console.log("✅ Authenticated user found:", sessionUser.username);
    
    // Fetch fresh user data from database to ensure account_type and other fields are current
    try {
      const freshUser = await storage.getUserById(sessionUser.id);
      if (freshUser) {
        await storage.refreshUserActivityStreak(freshUser.id);
        const refreshedUser = await storage.getUserById(freshUser.id);
        if (refreshedUser) {
          req.session.user = refreshedUser;
          const { password, ...userResponse } = refreshedUser;
          return res.json(userResponse);
        }
        req.session.user = freshUser;
        const { password, ...userResponse } = freshUser;
        return res.json(userResponse);
      }
    } catch (error) {
      console.error("Error fetching fresh user data:", error);
    }
    
    // Fallback to session data
    const { password, ...userResponse } = sessionUser;
    res.json(userResponse);
  });

  // Authentication routes
  app.post("/api/auth/register", async (req, res) => {
    try {
      const validatedData = registerSchema.parse(req.body);
      
      // Check if username already exists
      const existingUser = await storage.getUserByUsername(validatedData.username);
      if (existingUser) {
        return res.status(400).json({ message: "Username already exists" });
      }

      // Create new user (excluding confirmPassword)
      const { confirmPassword, ...userData } = validatedData;
      const newUser = await storage.createUser(userData);
      
      // Don't return password in response
      const { password, ...userResponse } = newUser;
      res.status(201).json(userResponse);
    } catch (error: any) {
      res.status(400).json({ message: error.message || "Registration failed" });
    }
  });

  app.post("/api/auth/login", async (req, res) => {
    try {
      const { username, password } = loginSchema.parse(req.body);
      
      const user = await storage.authenticateUser(username, password);
      if (!user) {
        return res.status(401).json({ message: "Invalid username or password" });
      }

      // Don't return password in response
      const { password: _, ...userResponse } = user;
      res.json(userResponse);
    } catch (error: any) {
      res.status(400).json({ message: error.message || "Login failed" });
    }
  });





  // Daily Tasks routes
  app.get("/api/daily-tasks", async (req: any, res) => {
    try {
      if (!req.session.userId || !req.session.user) {
        return res.status(401).json({ message: "Authentication required" });
      }
      
      const user = req.session.user;
      const tasks = await storage.getDailyTasksByUser(user.id, getRequestCalendarDate(req));
      res.json(tasks);
    } catch (error) {
      console.error("Failed to fetch daily tasks:", error);
      res.status(500).json({ message: "Failed to fetch tasks" });
    }
  });

  // Notification endpoints
  app.get("/api/notifications", async (req: any, res) => {
    try {
      if (!req.session.userId || !req.session.user) {
        return res.status(401).json({ message: "Authentication required" });
      }
      
      const user = req.session.user;
      const notifications = await storage.getNotificationsByUser(user.id);
      res.json(notifications);
    } catch (error) {
      console.error("Error fetching notifications:", error);
      res.status(500).json({ message: "Failed to fetch notifications" });
    }
  });

  app.post("/api/notifications/:id/read", async (req: any, res) => {
    try {
      if (!req.session.userId || !req.session.user) {
        return res.status(401).json({ message: "Authentication required" });
      }
      
      const notificationId = parseInt(req.params.id);
      const user = req.session.user;
      
      await storage.markNotificationAsRead(notificationId, user.id);
      res.json({ message: "Notification marked as read" });
    } catch (error) {
      console.error("Error marking notification as read:", error);
      res.status(500).json({ message: "Failed to update notification" });
    }
  });

  // Test reminder endpoint
  app.post("/api/test-reminder", async (req: any, res) => {
    try {
      if (!req.session.userId || !req.session.user) {
        return res.status(401).json({ message: "Authentication required" });
      }
      
      const user = req.session.user;
      const testNotification = {
        userId: user.id,
        type: 'test_reminder',
        title: '🔔 Test Reminder',
        message: 'This is a test reminder to verify the notification system is working properly.',
        priority: 'normal',
        isRead: false,
        metadata: {
          source: 'test',
          timestamp: new Date().toISOString()
        }
      };

      const notification = await storage.createNotification(testNotification);
      res.json({ message: "Test reminder sent", notification });
    } catch (error) {
      console.error("Error sending test reminder:", error);
      res.status(500).json({ message: "Failed to send test reminder" });
    }
  });

  // User preferences endpoints
  app.get("/api/user-preferences", async (req: any, res) => {
    try {
      if (!req.session.userId || !req.session.user) {
        return res.status(401).json({ message: "Authentication required" });
      }
      
      const user = req.session.user;
      const preferences = await storage.getUserPreferences(user.id);
      res.json(preferences || {
        reminderTiming: { taskReminders: 5, overdueReminders: true },
        notificationSettings: { pushEnabled: true }
      });
    } catch (error) {
      console.error("Error fetching user preferences:", error);
      res.status(500).json({ message: "Failed to fetch preferences" });
    }
  });

  app.put("/api/user-preferences", async (req: any, res) => {
    try {
      if (!req.session.userId || !req.session.user) {
        return res.status(401).json({ message: "Authentication required" });
      }
      
      const user = req.session.user;
      const preferences = await storage.updateUserPreferences(user.id, req.body);
      res.json(preferences);
    } catch (error) {
      console.error("Error updating user preferences:", error);
      res.status(500).json({ message: "Failed to update preferences" });
    }
  });

  app.post("/api/daily-tasks", async (req: any, res) => {
    try {
      if (!req.session.userId || !req.session.user) {
        return res.status(401).json({ message: "Authentication required" });
      }
      
      const user = req.session.user;
      const taskData = { ...req.body, userId: user.id };
      
      // Convert empty strings to null for time fields
      if (taskData.scheduledTime === '') taskData.scheduledTime = null;
      
      const data = insertDailyTaskSchema.parse(taskData);
      const task = await storage.createDailyTask(data);
      res.json(task);
    } catch (error) {
      console.error("Failed to create task:", error);
      res.status(400).json({ message: "Invalid task data" });
    }
  });

  // Update daily task details
  app.patch("/api/daily-tasks/:id", async (req: any, res) => {
    try {
      if (!req.session.userId || !req.session.user) {
        return res.status(401).json({ message: "Authentication required" });
      }

      const user = req.session.user;
      const taskId = parseInt(req.params.id);
      const updates = { ...req.body };

      // Convert empty strings to null for time fields
      if (updates.scheduledTime === '') updates.scheduledTime = null;

      // Get the task first to verify ownership
      const existingTask = await storage.getTaskById(taskId);
      if (!existingTask || existingTask.userId !== user.id) {
        return res.status(404).json({ message: "Task not found" });
      }

      const task = await storage.updateDailyTask(taskId, updates);
      if (!task) {
        return res.status(404).json({ message: "Task not found" });
      }

      res.json(task);
    } catch (error: any) {
      console.error("Error updating task:", error);
      res.status(500).json({ 
        message: "Failed to update task", 
        error: error.message 
      });
    }
  });

  app.delete("/api/daily-tasks/:id", async (req: any, res) => {
    try {
      if (!req.session.userId || !req.session.user) {
        return res.status(401).json({ message: "Authentication required" });
      }

      const user = req.session.user;
      const taskId = parseInt(req.params.id);
      const existingTask = await storage.getTaskById(taskId);

      if (!existingTask || existingTask.userId !== user.id) {
        return res.status(404).json({ message: "Task not found" });
      }

      const deleted = await storage.deleteDailyTask(taskId, user.id);
      if (!deleted) {
        return res.status(404).json({ message: "Task not found" });
      }

      res.json({ message: "Task deleted successfully" });
    } catch (error: any) {
      console.error("Error deleting task:", error);
      res.status(500).json({ message: "Failed to delete task" });
    }
  });

  app.patch("/api/daily-tasks/:id/complete", async (req: any, res) => {
    try {
      if (!req.session.userId || !req.session.user) {
        return res.status(401).json({ message: "Authentication required" });
      }

      const user = req.session.user;
      const taskId = parseInt(req.params.id);
      const { isCompleted } = req.body;
      const completionDate = req.body?.date || getRequestCalendarDate(req);
      if (typeof isCompleted !== "boolean" || !isValidCalendarDate(completionDate)) {
        return res.status(400).json({ message: "A valid completion date and boolean status are required" });
      }
      
      // Get the task to check ownership and point value
      const existingTask = await storage.getTaskById(taskId);
      if (!existingTask || existingTask.userId !== user.id) {
        return res.status(404).json({ message: "Task not found" });
      }
      const taskForDate = (await storage.getDailyTasksByUser(user.id, completionDate))
        .find(candidate => candidate.id === taskId);
      const wasCompleted = Boolean(taskForDate?.isCompleted);

      const task = await storage.updateTaskCompletion(taskId, isCompleted, completionDate);
      if (!task) {
        return res.status(404).json({ message: "Task not found" });
      }

      try {
        if (isCompleted && !wasCompleted) {
          await storage.recordUserActivity(user.id);
        } else if (!isCompleted && wasCompleted) {
          await storage.refreshUserActivityStreak(user.id);
        }
      } catch (streakError) {
        console.error("Error updating activity streak after task completion:", streakError);
      }

      // Award points when task is completed (not when uncompleted)
      if (isCompleted && !wasCompleted && existingTask.pointValue && existingTask.pointValue > 0) {
        try {
          await storage.updateUserPoints(
            user.id, 
            existingTask.pointValue, 
            "task_completion", 
            `Completed: ${existingTask.title}`, 
            user.id
          );
          console.log(`Awarded ${existingTask.pointValue} points for completing task: ${existingTask.title}`);
        } catch (pointsError) {
          console.error("Error awarding points for task completion:", pointsError);
          // Don't fail the task completion if points award fails
        }
      }

      res.json(task);
    } catch (error) {
      console.error("Error updating task completion:", {
        taskId: req.params.id,
        userId: req.session.userId,
        completionDate: req.body?.date,
        error,
      });
      res.status(500).json({ message: "Failed to update task" });
    }
  });

  // Bills routes
  app.get("/api/bills", async (req: any, res) => {
    try {
      if (!req.session.userId || !req.session.user) {
        return res.status(401).json({ message: "Authentication required" });
      }
      
      const user = req.session.user;
      const bills = await storage.getBillsByUser(user.id);
      res.json(bills);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch bills" });
    }
  });

  app.post("/api/bills", async (req: any, res) => {
    try {
      if (!req.session.userId || !req.session.user) {
        return res.status(401).json({ message: "Authentication required" });
      }
      
      const user = req.session.user;
      const data = insertBillSchema.parse({ ...req.body, userId: user.id });
      const bill = await storage.createBill(data);
      res.json(bill);
    } catch (error) {
      console.error("Failed to create bill:", error);
      res.status(400).json({ message: "Invalid bill data" });
    }
  });

  app.patch("/api/bills/:id", async (req: any, res) => {
    try {
      if (!req.session.userId || !req.session.user) {
        return res.status(401).json({ message: "Authentication required" });
      }
      
      const user = req.session.user;
      const billId = parseInt(req.params.id);
      const data = insertBillSchema.omit({ userId: true }).parse(req.body);
      const bill = await storage.updateBill(billId, data);
      res.json(bill);
    } catch (error) {
      console.error("Failed to update bill:", error);
      res.status(400).json({ message: "Invalid bill data" });
    }
  });

  app.patch("/api/bills/:id/pay", async (req, res) => {
    const billId = parseInt(req.params.id);
    const { isPaid } = req.body;
    const bill = await storage.updateBillPayment(billId, isPaid);
    if (!bill) {
      return res.status(404).json({ message: "Bill not found" });
    }
    res.json(bill);
  });

  app.patch("/api/bills/:id/payment-link", async (req, res) => {
    try {
      const billId = parseInt(req.params.id);
      const { payeeWebsite, payeeAccountNumber } = req.body;
      
      const bill = await storage.updateBill(billId, {
        payeeWebsite,
        payeeAccountNumber,
      });
      
      if (!bill) {
        return res.status(404).json({ message: "Bill not found" });
      }
      
      res.json(bill);
    } catch (error) {
      console.error("Failed to update payment link:", error);
      res.status(500).json({ message: "Failed to update payment link" });
    }
  });

  // Bank account routes
  app.get("/api/bank-accounts", async (req: any, res) => {
    try {
      if (!req.session.userId || !req.session.user) {
        return res.status(401).json({ message: "Authentication required" });
      }
      
      const user = req.session.user;
      const accounts = await storage.getBankAccountsByUser(user.id);
      res.json(accounts);
    } catch (error) {
      console.error("Failed to fetch bank accounts:", error);
      res.status(500).json({ message: "Failed to fetch bank accounts" });
    }
  });

  app.post("/api/bank-accounts", async (req: any, res) => {
    try {
      if (!req.session.userId || !req.session.user) {
        return res.status(401).json({ message: "Authentication required" });
      }
      
      const user = req.session.user;
      // Don't validate with schema since we need to handle accountName differently
      const requestData = req.body;
      const data = {
        userId: user.id,
        bankName: requestData.bankName,
        accountType: requestData.accountType,
        accountNickname: requestData.accountNickname,
        bankWebsite: requestData.bankWebsite,
        lastFour: requestData.lastFour,
      };
      const account = await storage.createBankAccount(data);
      res.json(account);
    } catch (error) {
      console.error("Failed to create bank account:", error);
      res.status(400).json({ message: "Invalid bank account data" });
    }
  });

  app.patch("/api/bank-accounts/:id", async (req: any, res) => {
    try {
      if (!req.session.userId || !req.session.user) {
        return res.status(401).json({ message: "Authentication required" });
      }
      
      const accountId = parseInt(req.params.id);
      const requestData = req.body;
      const data = {
        bankName: requestData.bankName,
        accountType: requestData.accountType,
        accountNickname: requestData.accountNickname,
        bankWebsite: requestData.bankWebsite,
        lastFour: requestData.lastFour,
      };
      const account = await storage.updateBankAccount(accountId, data);
      if (!account) {
        return res.status(404).json({ message: "Bank account not found" });
      }
      res.json(account);
    } catch (error) {
      console.error("Failed to update bank account:", error);
      res.status(500).json({ message: "Failed to update bank account" });
    }
  });

  app.delete("/api/bank-accounts/:id", async (req, res) => {
    try {
      const accountId = parseInt(req.params.id);
      const success = await storage.deleteBankAccount(accountId);
      if (!success) {
        return res.status(404).json({ message: "Bank account not found" });
      }
      res.json({ message: "Bank account deleted successfully" });
    } catch (error) {
      console.error("Failed to delete bank account:", error);
      res.status(500).json({ message: "Failed to delete bank account" });
    }
  });

  // Mood entries routes
  app.get("/api/mood-entries", async (req: any, res) => {
    try {
      if (!req.session.userId || !req.session.user) {
        return res.status(401).json({ message: "Authentication required" });
      }
      
      const user = req.session.user;
      const entries = await storage.getMoodEntriesByUser(user.id);
      res.json(entries);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch mood entries" });
    }
  });

  app.get("/api/mood-entries/today", async (req: any, res) => {
    try {
      if (!req.session.userId || !req.session.user) {
        return res.status(401).json({ message: "Authentication required" });
      }
      
      const user = req.session.user;
      const entry = await storage.getTodayMoodEntry(user.id);
      res.json(entry || null);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch today's mood entry" });
    }
  });

  app.post("/api/mood-entries", async (req: any, res) => {
    try {
      if (!req.session.userId || !req.session.user) {
        return res.status(401).json({ message: "Authentication required" });
      }
      
      const user = req.session.user;
      
      // Check if user already has a mood entry for today
      const existingTodayEntry = await storage.getTodayMoodEntry(user.id);
      if (existingTodayEntry) {
        return res.status(400).json({ 
          message: "You have already logged your mood for today. Please check back tomorrow!",
          existing: true
        });
      }
      
      const data = insertMoodEntrySchema.parse({ ...req.body, userId: user.id });
      const entry = await storage.createMoodEntry(data);
      res.json(entry);
    } catch (error) {
      console.error("Failed to create mood entry:", error);
      res.status(400).json({ message: "Invalid mood entry data" });
    }
  });

  // Achievements routes
  app.get("/api/achievements", requireAuth, async (req: any, res) => {
    try {
      const achievements = await storage.getAchievementsByUser(req.session.user.id);
      res.json(achievements);
    } catch (error) {
      console.error("Error fetching achievements:", error);
      res.status(500).json({ message: "Failed to fetch achievements" });
    }
  });

  app.post("/api/achievements", requireAuth, async (req: any, res) => {
    try {
      const data = insertAchievementSchema.parse({
        ...req.body,
        userId: req.session.user.id,
      });
      const achievement = await storage.createAchievement(data);
      res.json(achievement);
    } catch (error) {
      res.status(400).json({ message: "Invalid achievement data" });
    }
  });

  // Caregivers routes
  app.get("/api/caregivers", requireAuth, async (req: any, res) => {
    try {
      const userId = req.user.id;
      const relationships = await storage.getCareRelationshipsByUser(userId);
      const linkedCaregivers = await Promise.all(
        relationships.map(async (relationship) => {
          const caregiver = await storage.getUser(relationship.caregiverId);
          if (!caregiver) return null;

          return {
            id: caregiver.id,
            userId,
            name: caregiver.name || caregiver.username,
            relationship: relationship.relationship,
            email: caregiver.email,
            isActive: relationship.isActive,
          };
        }),
      );

      if (linkedCaregivers.some(Boolean)) {
        return res.json(linkedCaregivers.filter(Boolean));
      }

      // Keep legacy contacts visible for accounts that have not migrated to
      // invitation-based caregiver relationships yet.
      const legacyCaregivers = await storage.getCaregiversByUser(userId);
      res.json(legacyCaregivers);
    } catch (error) {
      console.error("Error fetching caregivers:", error);
      res.status(500).json({ message: "Failed to fetch caregivers" });
    }
  });

  app.post("/api/caregivers", requireAuth, async (req: any, res) => {
    try {
      const email = typeof req.body.email === "string"
        ? req.body.email.trim()
        : "";

      if (!email) {
        return res.status(400).json({
          error: "A caregiver email is required to verify their app account.",
        });
      }

      const caregiverAccount = await storage.getUserByEmail(email);
      if (!caregiverAccount) {
        return res.status(404).json({
          error: "This caregiver does not have an account in the app.",
        });
      }

      if (caregiverAccount.id === req.user.id) {
        return res.status(400).json({
          error: "You cannot add your own account as a caregiver.",
        });
      }

      const existingRelationships = await storage.getCareRelationshipsByUser(req.user.id);
      if (existingRelationships.some(
        (relationship) =>
          relationship.caregiverId === caregiverAccount.id && relationship.isActive,
      )) {
        return res.status(409).json({
          error: "This caregiver is already in your support team.",
        });
      }

      const data = insertCaregiverSchema.parse({
        ...req.body,
        userId: req.user.id,
        name: caregiverAccount.name || caregiverAccount.username,
        email: caregiverAccount.email || email,
      });

      await storage.createCareRelationship({
        caregiverId: caregiverAccount.id,
        userId: req.user.id,
        relationship: data.relationship,
        isPrimary: false,
        isActive: true,
        establishedVia: "manual",
      });

      res.json({
        id: caregiverAccount.id,
        userId: req.user.id,
        name: caregiverAccount.name || caregiverAccount.username,
        relationship: data.relationship,
        email: caregiverAccount.email || email,
        isActive: true,
      });
    } catch (error) {
      console.error("Error adding caregiver:", error);
      res.status(400).json({ message: "Invalid caregiver data" });
    }
  });

  // Messages routes
  app.get("/api/messages", requireAuth, async (req: any, res) => {
    try {
      const messages = await storage.getMessagesByUser(req.user.id);
      res.json(messages);
    } catch (error) {
      console.error("Error fetching messages:", error);
      res.status(500).json({ message: "Failed to fetch messages" });
    }
  });

  app.post("/api/messages", requireAuth, async (req: any, res) => {
    try {
      const userId = req.user.id;
      const caregiverId = Number(req.body.caregiverId);
      if (!Number.isInteger(caregiverId) || caregiverId < 1) {
        return res.status(400).json({ message: "A valid caregiver is required" });
      }

      const relationships = await storage.getCareRelationshipsByUser(userId);
      const connectedCaregiver = relationships.find(
        (relationship) =>
          relationship.caregiverId === caregiverId && relationship.isActive,
      );

      if (!connectedCaregiver) {
        return res.status(403).json({
          message: "This caregiver is not connected to your account. Ask them to accept a caregiver invitation first.",
        });
      }

      const data = insertMessageSchema.parse({
        ...req.body,
        userId,
        caregiverId,
        fromUser: true,
      });
      const message = await storage.createMessage(data);
      res.json(message);
    } catch (error) {
      console.error("Error creating message:", error);
      res.status(400).json({ message: "Invalid message data" });
    }
  });

  // Messages received by the authenticated caregiver. The optional userId
  // keeps the existing caregiver dashboard's selected-recipient view scoped.
  app.get("/api/caregiver/messages", requireAuth, async (req: any, res) => {
    try {
      const caregiverId = req.user.id;
      const requestedUserId = req.query.userId
        ? Number(req.query.userId)
        : undefined;

      if (
        requestedUserId !== undefined &&
        (!Number.isInteger(requestedUserId) || requestedUserId < 1)
      ) {
        return res.status(400).json({ message: "Invalid care recipient" });
      }

      const relationships = await storage.getCareRelationshipsByCaregiver(caregiverId);
      if (
        requestedUserId !== undefined &&
        !relationships.some(
          (relationship) =>
            relationship.userId === requestedUserId && relationship.isActive,
        )
      ) {
        return res.status(403).json({ message: "You are not connected to this care recipient" });
      }

      const messages = await storage.getMessagesByCaregiver(
        caregiverId,
        requestedUserId,
      );
      res.json(messages);
    } catch (error) {
      console.error("Error fetching caregiver messages:", error);
      res.status(500).json({ message: "Failed to fetch caregiver messages" });
    }
  });

  // Budget entries routes
  app.get("/api/budget-entries", async (req: any, res) => {
    try {
      if (!req.session?.userId) {
        return res.status(401).json({ message: "Authentication required" });
      }
      
      const entries = await storage.getBudgetEntriesByUser(req.session.userId);
      res.json(entries);
    } catch (error) {
      console.error("Error in /api/budget-entries:", error);
      res.status(500).json({ message: "Failed to fetch budget entries" });
    }
  });

  app.post("/api/budget-entries", async (req: any, res) => {
    try {
      if (!req.session.userId || !req.session.user) {
        return res.status(401).json({ message: "Authentication required" });
      }
      
      const user = req.session.user;
      const data = insertBudgetEntrySchema.parse({ ...req.body, userId: user.id });
      const entry = await storage.createBudgetEntry(data);
      res.json(entry);
    } catch (error) {
      console.error("Failed to create budget entry:", error);
      res.status(400).json({ message: "Invalid budget entry data" });
    }
  });

  app.delete("/api/budget-entries/:id", async (req: any, res) => {
    try {
      if (!req.session?.userId) {
        return res.status(401).json({ message: "Authentication required" });
      }

      const entryId = parseInt(req.params.id, 10);
      if (Number.isNaN(entryId)) {
        return res.status(400).json({ message: "Invalid budget entry ID" });
      }

      const deleted = await storage.deleteBudgetEntry(entryId, req.session.userId);
      if (!deleted) {
        return res.status(404).json({ message: "Budget entry not found" });
      }

      res.json({ message: "Budget entry deleted successfully" });
    } catch (error) {
      console.error("Failed to delete budget entry:", error);
      res.status(500).json({ message: "Failed to delete budget entry" });
    }
  });

  // Budget Categories routes
  app.get("/api/budget-categories", async (req: any, res) => {
    try {
      if (!req.session.userId || !req.session.user) {
        return res.status(401).json({ message: "Authentication required" });
      }
      
      const user = req.session.user;
      const categories = await storage.getBudgetCategoriesByUser(user.id);
      res.json(categories);
    } catch (error) {
      console.error("Failed to fetch budget categories:", error);
      res.status(500).json({ message: "Failed to fetch budget categories" });
    }
  });

  app.post("/api/budget-categories", async (req: any, res) => {
    try {
      if (!req.session.userId || !req.session.user) {
        return res.status(401).json({ message: "Authentication required" });
      }
      
      const user = req.session.user;
      const data = insertBudgetCategorySchema.parse({ ...req.body, userId: user.id });
      const category = await storage.createBudgetCategory(data);
      res.json(category);
    } catch (error) {
      console.error("Failed to create budget category:", error);
      res.status(400).json({ message: "Invalid budget category data" });
    }
  });

  app.patch("/api/budget-categories/:id", async (req: any, res) => {
    try {
      if (!req.session.userId || !req.session.user) {
        return res.status(401).json({ message: "Authentication required" });
      }
      
      const user = req.session.user;
      const categoryId = parseInt(req.params.id);
      const data = insertBudgetCategorySchema.omit({ userId: true }).parse(req.body);
      const category = await storage.updateBudgetCategory(categoryId, data);
      res.json(category);
    } catch (error) {
      console.error("Failed to update budget category:", error);
      res.status(400).json({ message: "Invalid budget category data" });
    }
  });

  // Savings Goals routes
  app.get("/api/savings-goals", async (req: any, res) => {
    try {
      if (!req.session.userId || !req.session.user) {
        return res.status(401).json({ message: "Authentication required" });
      }
      
      const user = req.session.user;
      const goals = await storage.getSavingsGoalsByUser(user.id);
      res.json(goals);
    } catch (error) {
      console.error("Failed to fetch savings goals:", error);
      res.status(500).json({ message: "Failed to fetch savings goals" });
    }
  });

  app.post("/api/savings-goals", async (req: any, res) => {
    try {
      if (!req.session.userId || !req.session.user) {
        return res.status(401).json({ message: "Authentication required" });
      }
      
      const user = req.session.user;
      
      // Create schema that handles string dates for creation
      const createSchema = z.object({
        title: z.string().min(1, "Goal title is required"),
        description: z.string().optional(),
        targetAmount: z.number().min(0.01, "Target amount must be greater than 0"),
        currentAmount: z.number().min(0, "Current amount cannot be negative").default(0),
        targetDate: z.string().transform(str => str ? new Date(str) : null),
        category: z.string().optional().default("general"),
        priority: z.enum(["low", "medium", "high"]).default("medium"),
        userId: z.number(),
      });
      
      const data = createSchema.parse({ ...req.body, userId: user.id });
      const goal = await storage.createSavingsGoal(data);
      res.json(goal);
    } catch (error) {
      console.error("Failed to create savings goal:", error);
      res.status(400).json({ message: "Invalid savings goal data" });
    }
  });

  app.patch("/api/savings-goals/:id", async (req: any, res) => {
    try {
      const goalId = parseInt(req.params.id);
      
      // Create update schema that handles string dates
      const updateSchema = z.object({
        title: z.string().optional(),
        description: z.string().optional(),
        targetAmount: z.number().optional(),
        currentAmount: z.number().optional(),
        targetDate: z.string().transform(str => str ? new Date(str) : null).optional(),
        category: z.string().optional(),
        priority: z.enum(["low", "medium", "high"]).optional(),
      });
      
      const updates = updateSchema.parse(req.body);
      
      const goal = await storage.updateSavingsGoal(goalId, updates);
      if (!goal) {
        return res.status(404).json({ message: "Savings goal not found" });
      }
      
      res.json(goal);
    } catch (error) {
      console.error("Failed to update savings goal:", error);
      res.status(500).json({ message: "Failed to update savings goal" });
    }
  });

  app.delete("/api/savings-goals/:id", async (req: any, res) => {
    try {
      const goalId = parseInt(req.params.id);
      const success = await storage.deleteSavingsGoal(goalId);
      
      if (!success) {
        return res.status(404).json({ message: "Savings goal not found" });
      }
      
      res.json({ message: "Savings goal deleted successfully" });
    } catch (error) {
      console.error("Failed to delete savings goal:", error);
      res.status(500).json({ message: "Failed to delete savings goal" });
    }
  });

  // Savings Transactions routes
  app.get("/api/savings-transactions", async (req: any, res) => {
    try {
      if (!req.session.userId || !req.session.user) {
        return res.status(401).json({ message: "Authentication required" });
      }
      
      const user = req.session.user;
      const { goalId } = req.query;
      
      let transactions;
      if (goalId) {
        transactions = await storage.getSavingsTransactionsByGoal(parseInt(goalId as string));
      } else {
        transactions = await storage.getSavingsTransactionsByUser(user.id);
      }
      
      res.json(transactions);
    } catch (error) {
      console.error("Failed to fetch savings transactions:", error);
      res.status(500).json({ message: "Failed to fetch savings transactions" });
    }
  });

  app.post("/api/savings-transactions", async (req: any, res) => {
    try {
      if (!req.session.userId || !req.session.user) {
        return res.status(401).json({ message: "Authentication required" });
      }
      
      const user = req.session.user;
      const data = insertSavingsTransactionSchema.parse({ ...req.body, userId: user.id });
      const transaction = await storage.createSavingsTransaction(data);
      res.json(transaction);
    } catch (error) {
      console.error("Failed to create savings transaction:", error);
      res.status(400).json({ message: "Invalid savings transaction data" });
    }
  });

  // Appointments routes
  app.get("/api/appointments", async (req: any, res) => {
    try {
      if (!req.session.userId || !req.session.user) {
        return res.status(401).json({ message: "Authentication required" });
      }
      const appointments = await storage.getAppointmentsByUser(req.session.userId);
      res.json(appointments);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch appointments" });
    }
  });

  app.get("/api/appointments/upcoming", async (req, res) => {
    try {
      const user = storage.getCurrentUser();
      if (!user) {
        return res.status(401).json({ message: "Authentication required" });
      }
      const appointments = await storage.getUpcomingAppointments(user.id);
      res.json(appointments);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch upcoming appointments" });
    }
  });

  app.post("/api/appointments", async (req: any, res) => {
    try {
      if (!req.session.userId || !req.session.user) {
        return res.status(401).json({ message: "Authentication required" });
      }
      
      const data = insertAppointmentSchema.parse({ ...req.body, userId: req.session.userId });
      const appointment = await storage.createAppointment(data);
      res.json(appointment);
    } catch (error) {
      console.error("Failed to create appointment:", error);
      res.status(400).json({ message: "Invalid appointment data" });
    }
  });

  app.patch("/api/appointments/:id/complete", async (req, res) => {
    try {
      const appointmentId = parseInt(req.params.id);
      const { isCompleted } = req.body;
      const appointment = await storage.updateAppointmentCompletion(appointmentId, isCompleted);
      if (!appointment) {
        return res.status(404).json({ message: "Appointment not found" });
      }
      res.json(appointment);
    } catch (error) {
      res.status(400).json({ message: "Invalid request" });
    }
  });

  // Academic routes
  app.get("/api/assignments", async (req: any, res) => {
    try {
      if (!req.session.userId || !req.session.user) {
        return res.status(401).json({ message: "Authentication required" });
      }
      
      const user = req.session.user;
      const assignments = await storage.getAssignmentsByUser(user.id);
      res.json(assignments);
    } catch (error) {
      console.error("Error fetching assignments:", error);
      res.status(500).json({ message: "Failed to fetch assignments" });
    }
  });

  app.post("/api/assignments", async (req: any, res) => {
    try {
      if (!req.session.userId || !req.session.user) {
        return res.status(401).json({ message: "Authentication required" });
      }
      
      const user = req.session.user;
      
      // Convert dueDate string to proper timestamp
      const dueDate = new Date(req.body.dueDate);
      if (isNaN(dueDate.getTime())) {
        throw new Error("Invalid due date provided");
      }

      const rawEstimatedHours = req.body.estimatedHours;
      const estimatedHours =
        rawEstimatedHours === undefined || rawEstimatedHours === null
          ? null
          : Number(rawEstimatedHours);
      if (
        estimatedHours !== null &&
        (!Number.isFinite(estimatedHours) ||
          estimatedHours <= 0 ||
          estimatedHours > 100)
      ) {
        throw new Error("Estimated hours must be greater than 0 and at most 100");
      }
      
      const assignmentData = { 
        ...req.body, 
        userId: user.id,
        dueDate,
        estimatedHours,
      };
      
      const assignment = await storage.createAssignment(assignmentData);
      
      res.json(assignment);
    } catch (error) {
      console.error("Failed to create assignment:", error);
      res.status(400).json({ message: "Invalid assignment data", error: error instanceof Error ? error.message : "Unknown error" });
    }
  });

  app.delete("/api/assignments/:id", async (req: any, res) => {
    try {
      if (!req.session.userId || !req.session.user) {
        return res.status(401).json({ message: "Authentication required" });
      }
      const assignmentId = Number.parseInt(req.params.id, 10);
      if (!Number.isInteger(assignmentId)) {
        return res.status(400).json({ message: "Invalid assignment id" });
      }
      const deleted = await storage.deleteAssignment(
        assignmentId,
        req.session.user.id,
      );
      if (!deleted) {
        return res.status(404).json({ message: "Assignment not found" });
      }
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting assignment:", error);
      res.status(500).json({ message: "Failed to delete assignment" });
    }
  });

  app.get("/api/academic-classes", async (req: any, res) => {
    try {
      if (!req.session.userId || !req.session.user) {
        return res.status(401).json({ message: "Authentication required" });
      }
      
      const user = req.session.user;
      const classes = await storage.getAcademicClassesByUser(user.id);
      res.json(classes);
    } catch (error) {
      console.error("Error fetching academic classes:", error);
      res.status(500).json({ message: "Failed to fetch classes" });
    }
  });

  app.post("/api/academic-classes", async (req: any, res) => {
    try {
      if (!req.session.userId || !req.session.user) {
        return res.status(401).json({ message: "Authentication required" });
      }
      
      const user = req.session.user;
      const classData = { ...req.body, userId: user.id };
      const academicClass = await storage.createAcademicClass(classData);
      res.json(academicClass);
    } catch (error) {
      console.error("Failed to create class:", error);
      res.status(400).json({ message: "Invalid class data" });
    }
  });

  app.get("/api/study-sessions", async (req: any, res) => {
    try {
      if (!req.session.userId || !req.session.user) {
        return res.status(401).json({ message: "Authentication required" });
      }
      
      const user = req.session.user;
      const studySessions = await storage.getStudySessionsByUser(user.id);
      res.json(studySessions);
    } catch (error) {
      console.error("Error fetching study sessions:", error);
      res.status(500).json({ message: "Failed to fetch study sessions" });
    }
  });

  app.post("/api/study-sessions", async (req: any, res) => {
    try {
      const user = req.session?.user || req.user;
      if (!user) {
        return res.status(401).json({ message: "Authentication required" });
      }
      const sessionData = { ...req.body, userId: user.id };
      const studySession = await storage.createStudySession(sessionData);
      res.json(studySession);
    } catch (error) {
      console.error("Error creating study session:", error);
      res.status(500).json({ message: "Failed to create study session" });
    }
  });

  app.patch("/api/study-sessions/:id", async (req: any, res) => {
    try {
      const user = req.session?.user || req.user;
      if (!user) {
        return res.status(401).json({ message: "Authentication required" });
      }
      const sessionId = parseInt(req.params.id);
      const updateData = req.body;
      const studySession = await storage.updateStudySession(sessionId, updateData);
      res.json(studySession);
    } catch (error) {
      console.error("Error updating study session:", error);
      res.status(500).json({ message: "Failed to update study session" });
    }
  });

  app.delete("/api/study-sessions/:id", async (req: any, res) => {
    try {
      const user = req.session?.user || req.user;
      if (!user) {
        return res.status(401).json({ message: "Authentication required" });
      }
      const sessionId = Number.parseInt(req.params.id, 10);
      if (!Number.isInteger(sessionId)) {
        return res.status(400).json({ message: "Invalid study session id" });
      }
      const deleted = await storage.deleteStudySession(sessionId, user.id);
      if (!deleted) {
        return res.status(404).json({ message: "Study session not found" });
      }
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting study session:", error);
      res.status(500).json({ message: "Failed to delete study session" });
    }
  });

  app.get("/api/campus-transport", async (req: any, res) => {
    try {
      if (!req.session.userId || !req.session.user) {
        return res.status(401).json({ message: "Authentication required" });
      }
      
      const user = req.session.user;
      const transport = await storage.getCampusTransportByUser(user.id);
      res.json(transport);
    } catch (error) {
      console.error("Failed to fetch campus transport:", error);
      res.status(500).json({ message: "Failed to fetch campus transport" });
    }
  });

  app.post("/api/campus-transport", async (req: any, res) => {
    try {
      const user = req.session?.user || req.user;
      if (!user) {
        return res.status(401).json({ message: "Authentication required" });
      }
      
      const transportData = {
        ...req.body,
        userId: user.id
      };
      
      const transport = await storage.createCampusTransport(transportData);
      res.json(transport);
    } catch (error) {
      console.error("Failed to create campus transport:", error);
      res.status(500).json({ message: "Failed to create campus transport" });
    }
  });

  app.get("/api/campus-locations", async (req: any, res) => {
    try {
      if (!req.session.userId || !req.session.user) {
        return res.status(401).json({ message: "Authentication required" });
      }
      
      const user = req.session.user;
      const locations = await storage.getCampusLocationsByUser(user.id);
      res.json(locations);
    } catch (error) {
      console.error("Failed to fetch campus locations:", error);
      res.status(500).json({ message: "Failed to fetch campus locations" });
    }
  });

  app.post("/api/campus-locations", async (req: any, res) => {
    try {
      const user = req.session?.user || req.user;
      if (!user) {
        return res.status(401).json({ message: "Authentication required" });
      }
      
      const locationData = {
        ...req.body,
        userId: user.id
      };
      
      const location = await storage.createCampusLocation(locationData);
      res.json(location);
    } catch (error) {
      console.error("Failed to create campus location:", error);
      res.status(500).json({ message: "Failed to create campus location" });
    }
  });

  app.get("/api/study-groups", async (req: any, res) => {
    try {
      if (!req.session.userId || !req.session.user) {
        return res.status(401).json({ message: "Authentication required" });
      }
      
      const user = req.session.user;
      const studyGroups = await storage.getStudyGroupsByUser(user.id);
      res.json(studyGroups);
    } catch (error) {
      console.error("Error fetching study groups:", error);
      res.status(500).json({ message: "Failed to fetch study groups" });
    }
  });

  app.post("/api/study-groups", async (req: any, res) => {
    try {
      if (!req.session.userId || !req.session.user) {
        return res.status(401).json({ message: "Authentication required" });
      }
      
      const user = req.session.user;
      
      // Handle date conversion for study group data  
      const studyGroupData = { 
        ...req.body, 
        userId: user.id,
        meetingTime: req.body.meetingTime ? new Date(req.body.meetingTime) : null
      };
      
      console.log("Study group data:", studyGroupData);
      
      const studyGroup = await storage.createStudyGroup(studyGroupData);
      res.json(studyGroup);
    } catch (error) {
      console.error("Error creating study group:", error);
      res.status(500).json({ message: "Failed to create study group" });
    }
  });

  app.get("/api/transition-skills", async (req: any, res) => {
    try {
      const user = req.session?.user || req.user;
      if (!user) {
        return res.status(401).json({ message: "Authentication required" });
      }
      
      const skills = await storage.getTransitionSkillsByUser(user.id);
      res.json(skills);
    } catch (error) {
      console.error("Failed to fetch transition skills:", error);
      res.status(500).json({ message: "Failed to fetch transition skills" });
    }
  });

  app.post("/api/transition-skills", async (req: any, res) => {
    try {
      const user = req.session?.user || req.user;
      if (!user) {
        return res.status(401).json({ message: "Authentication required" });
      }
      
      const skillData = {
        ...req.body,
        userId: user.id
      };

      const validatedSkillData = insertTransitionSkillSchema.parse(skillData);
      const skill = await storage.createTransitionSkill(validatedSkillData);
      res.json(skill);
    } catch (error) {
      console.error("Failed to create transition skill:", error);
      const isValidationError = error instanceof z.ZodError;
      res.status(isValidationError ? 400 : 500).json({
        message: isValidationError
          ? error.issues[0]?.message || "Invalid transition skill data"
          : "Unable to save this skill right now. Please try again.",
      });
    }
  });

  app.patch("/api/transition-skills/:id", async (req: any, res) => {
    try {
      const user = req.session?.user || req.user;
      if (!user) {
        return res.status(401).json({ message: "Authentication required" });
      }
      
      const skillId = parseInt(req.params.id);
      if (!Number.isInteger(skillId) || skillId <= 0) {
        return res.status(400).json({ message: "Invalid transition skill id" });
      }

      const updateData = transitionSkillUpdateSchema.parse(req.body);
      
      const skill = await storage.updateTransitionSkill(
        skillId,
        user.id,
        updateData,
      );
      if (!skill) {
        return res.status(404).json({ message: "Transition skill not found" });
      }
      res.json(skill);
    } catch (error) {
      console.error("Failed to update transition skill:", error);
      res.status(error instanceof z.ZodError ? 400 : 500).json({
        message: error instanceof z.ZodError
          ? error.issues[0]?.message || "Invalid transition skill data"
          : "Failed to update transition skill",
      });
    }
  });

  app.delete("/api/transition-skills/:id", async (req: any, res) => {
    try {
      const user = req.session?.user || req.user;
      if (!user) {
        return res.status(401).json({ message: "Authentication required" });
      }
      
      const skillId = parseInt(req.params.id);
      if (!Number.isInteger(skillId) || skillId <= 0) {
        return res.status(400).json({ message: "Invalid transition skill id" });
      }
      
      const deleted = await storage.deleteTransitionSkill(skillId, user.id);
      if (!deleted) {
        return res.status(404).json({ message: "Transition skill not found" });
      }
      res.json({ message: "Transition skill deleted successfully" });
    } catch (error) {
      console.error("Failed to delete transition skill:", error);
      res.status(500).json({ message: "Failed to delete transition skill" });
    }
  });

  // Calendar Events routes
  app.get("/api/calendar-events", async (req: any, res) => {
    try {
      if (!req.session.userId || !req.session.user) {
        return res.status(401).json({ message: "Authentication required" });
      }
      const events = await storage.getCalendarEventsByUser(req.session.userId);
      res.json(events);
    } catch (error) {
      console.error("Failed to fetch calendar events:", error);
      res.status(500).json({ message: "Failed to fetch calendar events" });
    }
  });

  app.post("/api/calendar-events", async (req: any, res) => {
    try {
      if (!req.session.userId || !req.session.user) {
        return res.status(401).json({ message: "Authentication required" });
      }
      
      // Convert date strings to Date objects
      const eventData = {
        ...req.body,
        userId: req.session.userId,
        startDate: new Date(req.body.startDate),
        endDate: req.body.endDate ? new Date(req.body.endDate) : null
      };
      
      const event = await storage.createCalendarEvent(eventData);
      res.json(event);
    } catch (error) {
      console.error("Failed to create calendar event:", error);
      res.status(500).json({ message: "Failed to create calendar event" });
    }
  });

  app.put("/api/calendar-events/:id", async (req, res) => {
    try {
      const user = req.session?.user || req.user;
      if (!user) {
        return res.status(401).json({ message: "Authentication required" });
      }
      const eventId = parseInt(req.params.id);
      
      // Convert date strings to Date objects if they exist
      const updateData = {
        ...req.body
      };
      if (req.body.startDate) {
        updateData.startDate = new Date(req.body.startDate);
      }
      if (req.body.endDate) {
        updateData.endDate = new Date(req.body.endDate);
      }
      
      const event = await storage.updateCalendarEvent(eventId, updateData);
      res.json(event);
    } catch (error) {
      console.error("Failed to update calendar event:", error);
      res.status(500).json({ message: "Failed to update calendar event" });
    }
  });

  app.delete("/api/calendar-events/:id", async (req, res) => {
    try {
      const user = req.session?.user || req.user;
      if (!user) {
        return res.status(401).json({ message: "Authentication required" });
      }
      const eventId = parseInt(req.params.id);
      const deleted = await storage.deleteCalendarEvent(eventId);
      if (deleted) {
        res.json({ success: true });
      } else {
        res.status(404).json({ message: "Event not found" });
      }
    } catch (error) {
      console.error("Failed to delete calendar event:", error);
      res.status(500).json({ message: "Failed to delete calendar event" });
    }
  });

  // Meal Plans routes
  app.get("/api/meal-plans", async (req: any, res) => {
    try {
      const user = req.session?.user || req.user;
      if (!user) {
        return res.status(401).json({ message: "Authentication required" });
      }
      const mealPlans = await storage.getMealPlansByUser(user.id);
      res.json(mealPlans);
    } catch (error) {
      console.error("Error fetching meal plans:", error);
      res.status(500).json({ message: "Failed to fetch meal plans" });
    }
  });

  app.post("/api/meal-plans", async (req: any, res) => {
    try {
      const user = req.session?.user || req.user;
      if (!user) {
        return res.status(401).json({ message: "Authentication required" });
      }
      const data = insertMealPlanSchema.parse({ ...req.body, userId: user.id });
      const mealPlan = await storage.createMealPlan(data);
      res.json(mealPlan);
    } catch (error) {
      console.error("Error creating meal plan:", error);
      res.status(400).json({ message: "Invalid meal plan data" });
    }
  });

  app.patch("/api/meal-plans/:id/completion", async (req, res) => {
    try {
      const user = req.session?.user || req.user;
      if (!user) {
        return res.status(401).json({ message: "Authentication required" });
      }
      const mealPlanId = parseInt(req.params.id);
      const { isCompleted } = req.body;
      const mealPlans = await storage.getMealPlansByUser(user.id);
      const existingMealPlan = mealPlans.find((mealPlan) => mealPlan.id === mealPlanId);
      if (!existingMealPlan) {
        return res.status(404).json({ message: "Meal plan not found" });
      }
      const mealPlan = await storage.updateMealPlanCompletion(mealPlanId, isCompleted);
      if (!mealPlan) {
        return res.status(404).json({ message: "Meal plan not found" });
      }
      try {
        if (isCompleted) {
          await storage.recordUserActivity(user.id);
        } else {
          await storage.refreshUserActivityStreak(user.id);
        }
      } catch (streakError) {
        console.error("Error updating activity streak after meal completion:", streakError);
      }
      res.json(mealPlan);
    } catch (error) {
      res.status(400).json({ message: "Invalid request" });
    }
  });

  app.delete("/api/meal-plans/:id", async (req: any, res) => {
    try {
      const user = req.session?.user || req.user;
      if (!user) {
        return res.status(401).json({ message: "Authentication required" });
      }

      const mealPlanId = Number.parseInt(req.params.id, 10);
      if (Number.isNaN(mealPlanId)) {
        return res.status(400).json({ message: "Invalid meal plan ID" });
      }

      const deleted = await storage.deleteMealPlan(mealPlanId, user.id);
      if (!deleted) {
        return res.status(404).json({ message: "Meal plan not found" });
      }

      res.json({ message: "Meal plan deleted successfully" });
    } catch (error) {
      console.error("Error deleting meal plan:", error);
      res.status(400).json({ message: "Invalid meal plan request" });
    }
  });

  app.get("/api/meal-plans/date/:date", async (req, res) => {
    try {
      const user = storage.getCurrentUser();
      if (!user) {
        return res.status(401).json({ message: "Authentication required" });
      }
      const date = req.params.date;
      const mealPlans = await storage.getMealPlansByDate(user.id, date);
      res.json(mealPlans);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch meal plans" });
    }
  });

  // Shopping Lists routes
  app.get("/api/shopping-lists", async (req: any, res) => {
    try {
      const user = req.session?.user || req.user;
      if (!user) {
        return res.status(401).json({ message: "Authentication required" });
      }
      const items = await storage.getShoppingListsByUser(user.id);
      res.json(items);
    } catch (error) {
      console.error("Error fetching shopping lists:", error);
      res.status(500).json({ message: "Failed to fetch shopping lists" });
    }
  });

  app.get("/api/shopping-lists/active", async (req: any, res) => {
    try {
      const user = req.session?.user || req.user;
      if (!user) {
        return res.status(401).json({ message: "Authentication required" });
      }
      const items = await storage.getActiveShoppingItems(user.id);
      res.json(items);
    } catch (error) {
      console.error("Error fetching active shopping items:", error);
      res.status(500).json({ message: "Failed to fetch active shopping items" });
    }
  });

  app.post("/api/shopping-lists", async (req: any, res) => {
    try {
      const user = req.session?.user || req.user;
      if (!user) {
        return res.status(401).json({ message: "Authentication required" });
      }
      const data = insertShoppingListSchema.parse({ ...req.body, userId: user.id });
      const item = await storage.createShoppingListItem(data);
      res.json(item);
    } catch (error) {
      console.error("Failed to create shopping list item:", error);
      res.status(400).json({ message: "Invalid shopping list item data" });
    }
  });

  app.patch("/api/shopping-lists/:id/purchased", async (req, res) => {
    try {
      const user = req.session?.user || req.user;
      if (!user) {
        return res.status(401).json({ message: "Authentication required" });
      }
      const itemId = parseInt(req.params.id);
      const { isPurchased, actualCost } = updateShoppingItemPurchasedSchema.parse(req.body);
      const shoppingItems = await storage.getShoppingListsByUser(user.id);
      const existingItem = shoppingItems.find((item) => item.id === itemId);
      if (!existingItem) {
        return res.status(404).json({ message: "Shopping item not found" });
      }
      const item = await storage.updateShoppingItemPurchased(itemId, isPurchased, actualCost);
      if (!item) {
        return res.status(404).json({ message: "Shopping item not found" });
      }
      try {
        if (isPurchased) {
          await storage.recordUserActivity(user.id);
        } else {
          await storage.refreshUserActivityStreak(user.id);
        }
      } catch (streakError) {
        console.error("Error updating activity streak after shopping completion:", streakError);
      }
      res.json(item);
    } catch (error) {
      res.status(400).json({ message: "Invalid request" });
    }
  });

  app.delete("/api/shopping-lists/:id", async (req: any, res) => {
    try {
      const user = req.session?.user || req.user;
      if (!user) {
        return res.status(401).json({ message: "Authentication required" });
      }
      const itemId = Number.parseInt(req.params.id, 10);
      if (Number.isNaN(itemId)) {
        return res.status(400).json({ message: "Invalid shopping item ID" });
      }
      const deleted = await storage.deleteShoppingListItem(itemId, user.id);
      if (!deleted) {
        return res.status(404).json({ message: "Shopping item not found" });
      }
      res.json({ message: "Shopping item deleted successfully" });
    } catch (error) {
      console.error("Error deleting shopping item:", error);
      res.status(400).json({ message: "Invalid shopping item request" });
    }
  });

  // Grocery Stores routes
  app.get("/api/grocery-stores", async (req: any, res) => {
    try {
      const userId = req.session?.user?.id || 1;
      const stores = await storage.getGroceryStoresByUser(userId);
      res.json(stores);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch grocery stores" });
    }
  });

  app.post("/api/grocery-stores", async (req: any, res) => {
    try {
      const userId = req.session?.user?.id || 1;
      const data = insertGroceryStoreSchema.parse({ ...req.body, userId });
      const store = await storage.createGroceryStore(data);
      res.json(store);
    } catch (error) {
      res.status(400).json({ message: "Invalid grocery store data" });
    }
  });

  app.put("/api/grocery-stores/:id", async (req: any, res) => {
    try {
      const userId = req.session?.user?.id || 1;
      const storeId = parseInt(req.params.id);
      const data = insertGroceryStoreSchema.omit({ userId: true }).partial().parse(req.body);
      const store = await storage.updateGroceryStore(storeId, data);
      if (!store) {
        return res.status(404).json({ message: "Grocery store not found" });
      }
      res.json(store);
    } catch (error) {
      res.status(400).json({ message: "Invalid request" });
    }
  });

  app.delete("/api/grocery-stores/:id", async (req: any, res) => {
    try {
      const userId = req.session?.user?.id || 1;
      const storeId = parseInt(req.params.id);
      const success = await storage.deleteGroceryStore(storeId);
      if (!success) {
        return res.status(404).json({ message: "Grocery store not found" });
      }
      res.json({ message: "Grocery store deleted successfully" });
    } catch (error) {
      res.status(400).json({ message: "Invalid request" });
    }
  });

  // Emergency resources routes
  app.get("/api/emergency-resources", requireAuth, async (req: any, res) => {
    try {
      const userId = req.session.user.id;
      const resources = await storage.getEmergencyResourcesByUser(userId);
      res.json(resources);
    } catch (error) {
      console.error("Error fetching emergency resources:", error);
      res.status(500).json({ message: "Failed to fetch emergency resources" });
    }
  });

  app.post("/api/emergency-resources", requireAuth, async (req: any, res) => {
    try {
      const userId = req.session.user.id;
      const resourceData = insertEmergencyResourceSchema.parse({ ...req.body, userId });
      const resource = await storage.createEmergencyResource(resourceData);
      res.status(201).json(resource);
    } catch (error) {
      console.error("Error creating emergency resource:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({
          message: "Please provide a resource name and type.",
          errors: error.flatten().fieldErrors,
        });
      }
      res.status(500).json({ message: "Failed to create emergency resource" });
    }
  });

  app.put("/api/emergency-resources/:id", requireAuth, async (req: any, res) => {
    try {
      const resourceId = parseInt(req.params.id);
      const resources = await storage.getEmergencyResourcesByUser(
        req.session.user.id,
      );
      if (!resources.some((resource) => resource.id === resourceId)) {
        return res.status(404).json({ message: "Emergency resource not found" });
      }

      const updates = { ...req.body };
      delete updates.userId;
      const resource = await storage.updateEmergencyResource(resourceId, updates);
      
      if (!resource) {
        return res.status(404).json({ message: "Emergency resource not found" });
      }
      
      res.json(resource);
    } catch (error) {
      console.error("Error updating emergency resource:", error);
      res.status(500).json({ message: "Failed to update emergency resource" });
    }
  });

  app.delete("/api/emergency-resources/:id", requireAuth, async (req: any, res) => {
    try {
      const resourceId = parseInt(req.params.id);
      const resources = await storage.getEmergencyResourcesByUser(
        req.session.user.id,
      );
      if (!resources.some((resource) => resource.id === resourceId)) {
        return res.status(404).json({ message: "Emergency resource not found" });
      }

      const success = await storage.deleteEmergencyResource(resourceId);
      
      if (!success) {
        return res.status(404).json({ message: "Emergency resource not found" });
      }
      
      res.json({ message: "Emergency resource deleted successfully" });
    } catch (error) {
      console.error("Error deleting emergency resource:", error);
      res.status(500).json({ message: "Failed to delete emergency resource" });
    }
  });

  // Caregiver access control endpoint
  app.get("/api/caregiver-access", async (req: any, res) => {
    try {
      console.log('🔍 Checking caregiver access for session:', req.session?.userId);
      console.log('🔍 Session user:', req.session?.user?.username);
      
      // Check if user has valid session
      if (!req.session?.userId || !req.session?.user) {
        console.log('❌ No valid session found');
        return res.status(401).json({ message: "User not authenticated" });
      }

      const currentUser = req.session.user;
      console.log('✅ Caregiver access check for user:', currentUser.username);

      // SOFT LAUNCH MODE: Allow all authenticated users to access caregiver dashboard for testing
      // This enables testers to experience both user and caregiver functionality
      // In full production, this would check proper caregiver credentials
      const isCaregiver = true; // Demo mode - all users can test caregiver features
      
      res.json({ 
        isCaregiver,
        userId: currentUser.id,
        username: currentUser.username,
        demoMode: true, // Indicate this is soft launch demo access
        message: "Soft launch testing mode - caregiver dashboard access granted for demo purposes"
      });
    } catch (error) {
      console.error("Error checking caregiver access:", error);
      res.status(500).json({ message: "Failed to verify caregiver access" });
    }
  });

  // Backup sync endpoint for mobile app
  app.post('/api/backup/sync', requireAuth, async (req: any, res) => {
    try {
      const backupData = req.body;
      const userId = req.user.id;
      
      // Store backup data (simplified implementation)
      // In production, this would sync to cloud storage
      res.json({ 
        success: true, 
        message: 'Backup synced successfully',
        timestamp: new Date().toISOString()
      });
    } catch (error) {
      console.error('Backup sync error:', error);
      res.status(500).json({ error: 'Failed to sync backup' });
    }
  });

  // Sync offline data endpoint
  app.post('/api/sync-offline-data', requireAuth, async (req: any, res) => {
    try {
      const offlineData = req.body;
      const userId = req.user.id;
      
      // Process offline task completions, notes, etc.
      // This would update the database with offline changes
      
      res.json({ 
        success: true, 
        message: 'Offline data synced successfully' 
      });
    } catch (error) {
      console.error('Offline sync error:', error);
      res.status(500).json({ error: 'Failed to sync offline data' });
    }
  });

  // AI Chatbot API endpoints
  app.post("/api/chat", requireAuth, async (req: any, res) => {
    try {
      const { message } = req.body ?? {};
      
      if (typeof message !== "string" || !message.trim()) {
        return res.status(400).json({ error: "Message is required" });
      }
      if (message.trim().length > 4000) {
        return res.status(400).json({ error: "Message is too long" });
      }

      // The authenticated session is always the viewer identity. A caregiver
      // may request a care recipient only through the permission-checked
      // careRecipientId path; arbitrary userId values remain ignored.
      const viewerUserId: number = req.session.userId;
      const requestedCareRecipientId = req.body?.careRecipientId;
      const userId =
        requestedCareRecipientId === undefined
          ? viewerUserId
          : Number(requestedCareRecipientId);
      if (!Number.isInteger(userId) || userId < 1) {
        return res.status(400).json({ error: "careRecipientId must be a valid user ID" });
      }
      const todayBriefingRequested = isTodayBriefingRequest(message);
      const appointmentRequested = isAppointmentTransitionRequest(message);
      const medicationRequested = isMedicationHealthRequest(message);
      const nextActionRequested = isNextActionRequest(message);
      const clientTime = {
        localDate: typeof req.body?.localDate === "string" ? req.body.localDate : undefined,
        localTime: typeof req.body?.localTime === "string" ? req.body.localTime : undefined,
        timezone: typeof req.body?.timezone === "string" ? req.body.timezone : undefined,
      };
      const context = await buildAdaptAIContext(
        userId,
        { name: typeof req.session.user?.name === "string" ? req.session.user.name : "" },
        clientTime,
        storage,
        {
          includeMedicalInfo: isExplicitMedicalInformationRequest(message),
          includeAppointments:
            todayBriefingRequested || appointmentRequested || nextActionRequested,
          includeMedicationInfo: medicationRequested,
          includeMedicationReminders: todayBriefingRequested || nextActionRequested,
          includeMoodSleep:
            shouldIncludeMoodSleepContext(message) || todayBriefingRequested,
          includeMealsGrocery:
            shouldIncludeMealsGroceryContext(message) || todayBriefingRequested,
          includeFinance: shouldIncludeFinanceContext(message) || todayBriefingRequested,
          viewerUserId,
        }
      );
      const actionContext =
        userId === viewerUserId
          ? buildActionContext(await storage.getDailyTasksByUser(viewerUserId))
          : undefined;
      const caregiverResponse = buildCaregiverContextResponse(message, context);
      let response: string;
      let action;
      let responseType = "text";
      let notice: string | undefined;

      if (todayBriefingRequested) {
        response = buildTodayBriefing(context);
      } else if (caregiverResponse) {
        response = caregiverResponse;
      } else if (isMealsGroceryRequest(message)) {
        response = buildMealsGroceryResponse(message, context);
      } else if (isFinanceRequest(message)) {
        response = buildFinanceResponse(message, context);
      } else if (
        isAppointmentTransitionRequest(message) &&
        (message.trim().toLowerCase() !== "what's next?" ||
          Boolean(context.appointments?.today?.length || context.appointments?.upcoming))
      ) {
        response = buildAppointmentTransitionResponse(message, context);
      } else if (medicationRequested) {
        response = buildMedicationHealthResponse(message, context);
      } else if (isMoodSleepRequest(message)) {
        response = buildMoodSleepResponse(message, context);
      } else if (
        isGoalsProgressRewardsRequest(message) &&
        !message.trim().toLowerCase().includes("how am i doing today")
      ) {
        response = buildGoalsProgressRewardsResponse(message, context);
      } else if (isNextActionRequest(message)) {
        response = buildNextAction(context);
      } else if (
        isTasksRoutinesRequest(message) &&
        !isPotentialTaskActionRequest(message)
      ) {
        response = buildTasksRoutinesResponse(message, context);
      } else {
        const chatTurn = await generateAdaptAIChatTurn(
          message,
          context,
          actionContext,
        );
        response = chatTurn.message;
        action = chatTurn.action;
        if (chatTurn.fallback) {
          responseType = "fallback";
          notice = "AdaptAI is temporarily unavailable. Showing safe guidance instead.";
        }
      }
      
      res.json({ 
        message: response,
        type: responseType,
        ...(notice ? { notice } : {}),
        ...(action
          ? {
              action,
              actionRequiresConfirmation: true,
            }
          : {}),
      });
    } catch (error: any) {
      console.error("Error in chat endpoint:", error);
      
      // Handle OpenAI quota exceeded or rate limiting
      if (error?.message === "AdaptAI caregiver access denied") {
        return res.status(403).json({
          error: "AdaptAI is not authorized to access that care recipient.",
          type: "permission_denied",
        });
      }
      if (error.status === 429 || error.code === 'insufficient_quota') {
        // Provide helpful fallback responses based on common queries
        const fallbackResponse = getFallbackResponse(req.body.message).replace(/\*\*/g, "");
        res.json({ 
          message: fallbackResponse,
          type: "fallback",
          notice: "AI assistant is temporarily unavailable. Here's some helpful guidance:"
        });
      } else {
        res.status(500).json({ 
          error: "I'm having trouble connecting right now. Please try again in a moment.",
          type: "general_error"
        });
      }
    }
  });

  // Controlled AdaptAI action execution. This endpoint never accepts a table,
  // SQL statement, storage method, or target user from the client.
  app.post("/api/ai/actions/execute", requireAuth, async (req: any, res) => {
    try {
      const authenticatedUserId: number = req.session.userId;
      const result = await executeAdaptAIAction(
        {
          action: req.body?.action,
          parameters: req.body?.parameters,
        },
        authenticatedUserId,
        storage,
        { confirmed: req.body?.confirmed === true },
      );
      return res.json(result);
    } catch (error: any) {
      if (error instanceof AdaptAIActionError) {
        return res.status(error.statusCode).json({
          error: error.message,
          code: error.code,
        });
      }
      console.error("Error executing AdaptAI action:", error);
      return res.status(500).json({
        error: "I couldn't complete that task action right now.",
        code: "action_execution_failed",
      });
    }
  });

  // Get quick suggestions for chatbot
  app.get("/api/chat/suggestions", async (req, res) => {
    try {
      const suggestions = [
        {
          id: "help-1",
          text: "How do I create a daily routine?",
          category: "help",
        },
        {
          id: "encouragement-1", 
          text: "I'm feeling overwhelmed today",
          category: "encouragement",
        },
        {
          id: "planning-1",
          text: "Help me plan my week",
          category: "planning",
        },
        {
          id: "skills-1",
          text: "I want to learn something new",
          category: "skills",
        },
        {
          id: "help-2",
          text: "How do I organize my medications?",
          category: "help",
        },
        {
          id: "encouragement-2",
          text: "I accomplished something today!",
          category: "encouragement",
        },
        {
          id: "planning-2",
          text: "Help me build a daily routine",
          category: "planning",
        },
        {
          id: "skills-2",
          text: "Show me simple cooking tips",
          category: "skills",
        },
        {
          id: "help-3",
          text: "Help me understand my budget",
          category: "help",
        },
        {
          id: "help-4",
          text: "How do I use this app?",
          category: "help",
        },
        {
          id: "social-1",
          text: "I want to connect with my caregivers",
          category: "help",
        },
        {
          id: "encouragement-3",
          text: "I need some motivation today",
          category: "encouragement",
        }
      ];
      
      res.json(suggestions);
    } catch (error) {
      console.error("Error getting chat suggestions:", error);
      res.status(500).json({ error: "Failed to get suggestions" });
    }
  });

  // Rewards API Routes - REMOVED DUPLICATES (better versions exist below around line 4391)

  // Caregiver Permission Management Routes
  app.get("/api/caregiver-permissions/:userId/:caregiverId", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      const caregiverId = parseInt(req.params.caregiverId);
      const permissions = await storage.getCaregiverPermissions(userId, caregiverId);
      res.json(permissions);
    } catch (error) {
      console.error("Error fetching caregiver permissions:", error);
      res.status(500).json({ message: "Failed to fetch caregiver permissions" });
    }
  });

  app.post("/api/caregiver-permissions", async (req, res) => {
    try {
      const permission = await storage.setCaregiverPermission(req.body);
      res.json(permission);
    } catch (error) {
      console.error("Error setting caregiver permission:", error);
      res.status(400).json({ message: "Failed to set caregiver permission" });
    }
  });

  app.delete("/api/caregiver-permissions/:userId/:caregiverId/:permissionType", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      const caregiverId = parseInt(req.params.caregiverId);
      const { permissionType } = req.params;
      const success = await storage.removeCaregiverPermission(userId, caregiverId, permissionType);
      
      if (!success) {
        return res.status(404).json({ message: "Permission not found" });
      }
      
      res.json({ message: "Permission removed successfully" });
    } catch (error) {
      console.error("Error removing caregiver permission:", error);
      res.status(500).json({ message: "Failed to remove caregiver permission" });
    }
  });

  // Locked User Settings Routes
  app.get("/api/locked-settings/:userId", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      const settings = await storage.getLockedUserSettings(userId);
      res.json(settings);
    } catch (error) {
      console.error("Error fetching locked settings:", error);
      res.status(500).json({ message: "Failed to fetch locked settings" });
    }
  });

  // Caregiver Invitation Routes
  app.post("/api/caregiver-invitations", async (req: any, res) => {
    try {
      // Check authentication
      const user = req.session?.user || req.user;
      if (!user) {
        return res.status(401).json({ message: "Authentication required" });
      }

      // Ensure the invitation is linked to the authenticated user
      const invitationData = {
        ...req.body,
        caregiverId: user.id, // Use authenticated user's ID
      };

      console.log("Creating caregiver invitation:", invitationData);
      const invitation = await storage.createCaregiverInvitation(invitationData);
      
      console.log("Invitation created successfully:", invitation);
      res.json(invitation);
    } catch (error) {
      console.error("Error creating caregiver invitation:", error);
      res.status(400).json({ message: "Failed to create caregiver invitation", error: error instanceof Error ? error.message : "Unknown error" });
    }
  });

  app.get("/api/caregiver-invitations/:caregiverId", async (req: any, res) => {
    try {
      // Check authentication
      const user = req.session?.user || req.user;
      if (!user) {
        return res.status(401).json({ message: "Authentication required" });
      }

      const caregiverId = parseInt(req.params.caregiverId);
      
      // Users can only view their own invitations
      if (user.id !== caregiverId) {
        return res.status(403).json({ message: "Access denied" });
      }

      const invitations = await storage.getCaregiverInvitationsByCaregiver(caregiverId);
      res.json(invitations);
    } catch (error) {
      console.error("Error fetching caregiver invitations:", error);
      res.status(500).json({ message: "Failed to fetch caregiver invitations" });
    }
  });

  app.get("/api/invitation/:code", async (req, res) => {
    try {
      const { code } = req.params;
      const invitation = await storage.getCaregiverInvitation(code);
      
      if (!invitation) {
        return res.status(404).json({ message: "Invitation not found" });
      }

      // Check if invitation is expired
      if (new Date() > new Date(invitation.expiresAt)) {
        await storage.expireCaregiverInvitation(code);
        return res.status(410).json({ message: "Invitation has expired" });
      }

      if (invitation.status !== 'pending') {
        return res.status(400).json({ message: "Invitation is no longer valid" });
      }

      res.json(invitation);
    } catch (error) {
      console.error("Error fetching invitation:", error);
      res.status(500).json({ message: "Failed to fetch invitation" });
    }
  });

  app.delete("/api/caregiver-invitations/:id", async (req: any, res) => {
    try {
      // Check authentication
      const user = req.session?.user || req.user;
      if (!user) {
        return res.status(401).json({ message: "Authentication required" });
      }

      const invitationId = parseInt(req.params.id);
      
      // Get the invitation to verify ownership
      const invitation = await storage.getCaregiverInvitationById(invitationId);
      
      if (!invitation) {
        return res.status(404).json({ message: "Invitation not found" });
      }

      // Only the caregiver who created the invitation can delete it
      if (invitation.caregiverId !== user.id) {
        return res.status(403).json({ message: "Access denied" });
      }

      await storage.deleteCaregiverInvitation(invitationId);
      res.json({ message: "Invitation deleted successfully" });
    } catch (error) {
      console.error("Error deleting caregiver invitation:", error);
      res.status(500).json({ message: "Failed to delete caregiver invitation" });
    }
  });

  app.post("/api/accept-invitation", async (req, res) => {
    try {
      const user = req.session?.user || req.user;
      if (!user) {
        return res.status(401).json({ message: "Authentication required" });
      }

      const { invitationCode, userId } = req.body;
      
      if (!invitationCode || !userId) {
        return res.status(400).json({ message: "Invitation code and user ID are required" });
      }
      if (user.id !== userId) {
        return res.status(403).json({ message: "The invitation must be accepted by the signed-in user" });
      }

      const acceptedInvitation = await storage.acceptCaregiverInvitation(invitationCode, userId);
      
      if (!acceptedInvitation) {
        return res.status(400).json({ message: "Invalid or expired invitation" });
      }

      res.json({ 
        message: "Invitation accepted successfully",
        invitation: acceptedInvitation
      });
    } catch (error) {
      console.error("Error accepting invitation:", error);
      res.status(500).json({ message: "Failed to accept invitation" });
    }
  });

  // Care Relationship Routes
  app.get("/api/care-relationships/user/:userId", async (req: any, res) => {
    try {
      const user = req.session?.user || req.user;
      if (!user) {
        return res.status(401).json({ message: "Authentication required" });
      }

      const userId = parseInt(req.params.userId);
      if (user.id !== userId) {
        return res.status(403).json({ message: "Access denied" });
      }

      const relationships = await storage.getCareRelationshipsByUser(userId);
      const relationshipsWithNames = await Promise.all(
        relationships.map(async (relationship) => {
          const caregiver = await storage.getUser(relationship.caregiverId);
          return {
            ...relationship,
            caregiverName: caregiver?.name || caregiver?.username || "Caregiver",
          };
        }),
      );
      res.json(relationshipsWithNames);
    } catch (error) {
      console.error("Error fetching care relationships:", error);
      res.status(500).json({ message: "Failed to fetch care relationships" });
    }
  });

  app.get("/api/care-relationships/caregiver/:caregiverId", async (req: any, res) => {
    try {
      const user = req.session?.user || req.user;
      if (!user) {
        return res.status(401).json({ message: "Authentication required" });
      }

      const caregiverId = parseInt(req.params.caregiverId);
      if (user.id !== caregiverId) {
        return res.status(403).json({ message: "Access denied" });
      }

      const relationships = await storage.getCareRelationshipsByCaregiver(caregiverId);
      res.json(relationships);
    } catch (error) {
      console.error("Error fetching care relationships:", error);
      res.status(500).json({ message: "Failed to fetch care relationships" });
    }
  });

  // Remove (deactivate) a care relationship — only the care recipient can do this
  app.delete("/api/care-relationships/:id", async (req: any, res) => {
    try {
      const user = req.session?.user || req.user;
      if (!user) return res.status(401).json({ message: "Authentication required" });

      const id = parseInt(req.params.id);
      const relationship = await storage.getCareRelationshipById(id);
      if (!relationship || relationship.userId !== user.id) {
        return res.status(403).json({ message: "You can only remove caregivers linked to your own account" });
      }

      const success = await storage.removeCareRelationship(id, user.id);
      if (!success) return res.status(404).json({ message: "Relationship not found" });

      res.json({ message: "Caregiver access removed successfully" });
    } catch (error) {
      console.error("Error removing care relationship:", error);
      res.status(500).json({ message: "Failed to remove care relationship" });
    }
  });

  // Returns the care recipients (users) that the currently logged-in caregiver looks after
  app.get("/api/my-care-recipients", async (req: any, res) => {
    try {
      const user = req.session?.user;
      if (!user) return res.status(401).json({ message: "Authentication required" });

      const relationships = await storage.getCareRelationshipsByCaregiver(user.id);
      if (relationships.length === 0) return res.json([]);

      // Fetch each care recipient's user record
      const recipients = await Promise.all(
        relationships.map(async (rel) => {
          const recipient = await storage.getUser(rel.userId);
          if (!recipient) return null;
          return {
            userId: recipient.id,
            userName: recipient.name || recipient.username,
            relationship: rel.relationship,
            isPrimary: rel.isPrimary,
            relationshipId: rel.id,
          };
        })
      );

      res.json(recipients.filter(Boolean));
    } catch (error) {
      console.error("Error fetching care recipients:", error);
      res.status(500).json({ message: "Failed to fetch care recipients" });
    }
  });

  app.get("/api/locked-settings/:userId/:settingKey", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      const { settingKey } = req.params;
      const setting = await storage.getLockedUserSetting(userId, settingKey);
      if (!setting) {
        return res.status(404).json({ message: "Setting not found" });
      }
      res.json(setting);
    } catch (error) {
      console.error("Error fetching locked setting:", error);
      res.status(500).json({ message: "Failed to fetch locked setting" });
    }
  });

  app.post("/api/locked-settings", async (req, res) => {
    try {
      const setting = await storage.lockUserSetting(req.body);
      res.json(setting);
    } catch (error) {
      console.error("Error locking user setting:", error);
      res.status(400).json({ message: "Failed to lock user setting" });
    }
  });

  app.delete("/api/locked-settings/:userId/:settingKey", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      const { settingKey } = req.params;
      const caregiverId = parseInt(req.body.caregiverId || req.query.caregiverId as string);
      
      if (!caregiverId) {
        return res.status(400).json({ message: "Caregiver ID is required" });
      }
      
      const success = await storage.unlockUserSetting(userId, settingKey, caregiverId);
      
      if (!success) {
        return res.status(403).json({ message: "Permission denied or setting not found" });
      }
      
      res.json({ message: "Setting unlocked successfully" });
    } catch (error) {
      console.error("Error unlocking user setting:", error);
      res.status(500).json({ message: "Failed to unlock user setting" });
    }
  });

  app.get("/api/settings-check/:userId/:settingKey/locked", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      const { settingKey } = req.params;
      const isLocked = await storage.isSettingLocked(userId, settingKey);
      res.json({ isLocked });
    } catch (error) {
      console.error("Error checking if setting is locked:", error);
      res.status(500).json({ message: "Failed to check setting lock status" });
    }
  });

  app.get("/api/settings-check/:userId/:settingKey/modifiable", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      const { settingKey } = req.params;
      const canModify = await storage.canUserModifySetting(userId, settingKey);
      res.json({ canModify });
    } catch (error) {
      console.error("Error checking if user can modify setting:", error);
      res.status(500).json({ message: "Failed to check setting modification permissions" });
    }
  });

  // Pharmacy Integration Routes
  app.get("/api/pharmacies", async (req, res) => {
    try {
      const pharmacies = await storage.getPharmacies();
      res.json(pharmacies);
    } catch (error) {
      console.error("Error fetching pharmacies:", error);
      res.status(500).json({ message: "Failed to fetch pharmacies" });
    }
  });

  // Add custom pharmacy
  app.post("/api/pharmacies", async (req: any, res) => {
    try {
      const user = req.session?.user || req.user;
      if (!user) {
        return res.status(401).json({ message: "Authentication required" });
      }

      const pharmacyData = {
        ...req.body,
        type: "custom",
        isCustom: true,
        createdBy: user.id
      };

      const validatedData = insertPharmacySchema.parse(pharmacyData);
      const pharmacy = await storage.createPharmacy(validatedData);
      res.status(201).json(pharmacy);
    } catch (error) {
      console.error("Error creating custom pharmacy:", error);
      res.status(500).json({ message: "Failed to create pharmacy" });
    }
  });

  app.post("/api/user-pharmacies", async (req: any, res) => {
    try {
      const user = req.session?.user || req.user;
      if (!user) {
        return res.status(401).json({ message: "Authentication required" });
      }

      const userPharmacyData = {
        ...req.body,
        userId: user.id,
        pharmacyId: parseInt(req.body.pharmacyId) // Convert string to number
      };

      const validatedData = insertUserPharmacySchema.parse(userPharmacyData);
      const userPharmacy = await storage.addUserPharmacy(validatedData);
      res.status(201).json(userPharmacy);
    } catch (error) {
      console.error("Error adding user pharmacy:", error);
      res.status(500).json({ message: "Failed to add pharmacy" });
    }
  });

  app.get("/api/user-pharmacies", async (req: any, res) => {
    try {
      const user = req.session?.user || req.user;
      if (!user) {
        return res.status(401).json({ message: "Authentication required" });
      }
      
      const userPharmacies = await storage.getUserPharmacies(user.id);
      res.json(userPharmacies);
    } catch (error) {
      console.error("Error fetching user pharmacies:", error);
      res.status(500).json({ message: "Failed to fetch user pharmacies" });
    }
  });

  // Medication Routes
  app.get("/api/medications", async (req: any, res) => {
    try {
      const user = req.session?.user || req.user;
      if (!user) {
        return res.status(401).json({ message: "Authentication required" });
      }
      const medications = await storage.getMedicationsByUser(user.id);
      res.json(medications);
    } catch (error) {
      console.error("Error fetching medications:", error);
      res.status(500).json({ message: "Failed to fetch medications" });
    }
  });

  app.post("/api/medications", async (req: any, res) => {
    try {
      const user = req.session?.user || req.user;
      if (!user) {
        return res.status(401).json({ message: "Authentication required" });
      }
      
      // Convert date strings to Date objects
      const medicationData = {
        ...req.body,
        userId: user.id,
        nextRefillDate: req.body.nextRefillDate ? new Date(req.body.nextRefillDate) : null,
        dateStarted: req.body.dateStarted ? new Date(req.body.dateStarted) : null,
        dateFilled: req.body.dateFilled ? new Date(req.body.dateFilled) : null
      };
      
      const validatedData = insertMedicationSchema.parse(medicationData);
      const medication = await storage.createMedication(validatedData);
      res.status(201).json(medication);
    } catch (error) {
      console.error("Error creating medication:", error);
      res.status(500).json({ message: "Failed to create medication" });
    }
  });

  app.put("/api/medications/:id", async (req: any, res) => {
    try {
      const user = req.session?.user || req.user;
      if (!user) {
        return res.status(401).json({ message: "Authentication required" });
      }

      const medicationData = {
        ...req.body,
        nextRefillDate: req.body.nextRefillDate
          ? new Date(req.body.nextRefillDate)
          : null,
      };
      const updateSchema = insertMedicationSchema
        .partial()
        .omit({ userId: true });
      const validatedData = updateSchema.parse(medicationData);
      const medication = await storage.updateMedication(
        Number(req.params.id),
        user.id,
        validatedData,
      );
      if (!medication) {
        return res.status(404).json({ message: "Medication not found" });
      }
      res.json(medication);
    } catch (error) {
      console.error("Error updating medication:", error);
      res.status(500).json({ message: "Failed to update medication" });
    }
  });

  app.delete("/api/medications/:id", async (req: any, res) => {
    try {
      const user = req.session?.user || req.user;
      if (!user) {
        return res.status(401).json({ message: "Authentication required" });
      }

      const deleted = await storage.deleteMedication(
        Number(req.params.id),
        user.id,
      );
      if (!deleted) {
        return res.status(404).json({ message: "Medication not found" });
      }
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting medication:", error);
      res.status(500).json({ message: "Failed to delete medication" });
    }
  });

  app.get("/api/medications/due-for-refill", async (req: any, res) => {
    try {
      const user = req.session?.user || req.user;
      if (!user) {
        return res.status(401).json({ message: "Authentication required" });
      }
      const medications = await storage.getMedicationsDueForRefill(user.id);
      res.json(medications);
    } catch (error) {
      console.error("Error fetching medications due for refill:", error);
      res.status(500).json({ message: "Failed to fetch medications due for refill" });
    }
  });

  // Refill Order Routes
  app.get("/api/refill-orders", async (req, res) => {
    try {
      const user = (req as any).session?.user || (req as any).user;
      if (!user) {
        return res.status(401).json({ message: "Authentication required" });
      }
      const refillOrders = await storage.getRefillOrdersByUser(user.id);
      res.json(refillOrders);
    } catch (error) {
      console.error("Error fetching refill orders:", error);
      res.status(500).json({ message: "Failed to fetch refill orders" });
    }
  });

  app.post("/api/refill-orders", async (req, res) => {
    try {
      const user = (req as any).session?.user || (req as any).user;
      if (!user) {
        return res.status(401).json({ message: "Authentication required" });
      }
      const validatedData = insertRefillOrderSchema.parse({
        ...req.body,
        userId: user.id,
      });
      const refillOrder = await storage.createRefillOrder(validatedData);
      res.status(201).json(refillOrder);
    } catch (error) {
      console.error("Error creating refill order:", error);
      res.status(500).json({ message: "Failed to create refill order" });
    }
  });

  app.patch("/api/refill-orders/:id/status", async (req, res) => {
    try {
      const orderId = parseInt(req.params.id);
      const { status } = req.body;
      const refillOrder = await storage.updateRefillOrderStatus(orderId, status);
      res.json(refillOrder);
    } catch (error) {
      console.error("Error updating refill order status:", error);
      res.status(500).json({ message: "Failed to update refill order status" });
    }
  });

  // Medical Information Routes
  
  // Allergies
  app.get("/api/allergies", async (req, res) => {
    try {
      const userId = 1; // Hardcoded for demo
      const allergies = await storage.getAllergiesByUser(userId);
      res.json(allergies);
    } catch (error) {
      console.error("Error fetching allergies:", error);
      res.status(500).json({ message: "Failed to fetch allergies" });
    }
  });

  app.post("/api/allergies", async (req, res) => {
    try {
      const userId = 1; // Hardcoded for demo
      const allergyData = { ...req.body, userId };
      const allergy = await storage.createAllergy(allergyData);
      res.status(201).json(allergy);
    } catch (error) {
      console.error("Error creating allergy:", error);
      res.status(500).json({ message: "Failed to create allergy" });
    }
  });

  app.put("/api/allergies/:id", async (req, res) => {
    try {
      const allergyId = parseInt(req.params.id);
      const allergy = await storage.updateAllergy(allergyId, req.body);
      res.json(allergy);
    } catch (error) {
      console.error("Error updating allergy:", error);
      res.status(500).json({ message: "Failed to update allergy" });
    }
  });

  app.delete("/api/allergies/:id", async (req, res) => {
    try {
      const allergyId = parseInt(req.params.id);
      const success = await storage.deleteAllergy(allergyId);
      if (!success) {
        return res.status(404).json({ message: "Allergy not found" });
      }
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting allergy:", error);
      res.status(500).json({ message: "Failed to delete allergy" });
    }
  });

  // Medical Conditions
  app.get("/api/medical-conditions", async (req: any, res) => {
    try {
      if (!req.session.userId || !req.session.user) {
        return res.status(401).json({ message: "Authentication required" });
      }
      
      const user = req.session.user;
      const conditions = await storage.getMedicalConditionsByUser(user.id);
      res.json(conditions);
    } catch (error) {
      console.error("Error fetching medical conditions:", error);
      res.status(500).json({ message: "Failed to fetch medical conditions" });
    }
  });

  app.post("/api/medical-conditions", async (req: any, res) => {
    try {
      if (!req.session.userId || !req.session.user) {
        return res.status(401).json({ message: "Authentication required" });
      }
      
      const user = req.session.user;
      // Convert diagnosedDate string to Date object if provided
      const conditionData = { ...req.body, userId: user.id };
      if (conditionData.diagnosedDate) {
        conditionData.diagnosedDate = new Date(conditionData.diagnosedDate);
      }
      const condition = await storage.createMedicalCondition(conditionData);
      res.status(201).json(condition);
    } catch (error) {
      console.error("Error creating medical condition:", error);
      res.status(500).json({ message: "Failed to create medical condition" });
    }
  });

  app.put("/api/medical-conditions/:id", async (req, res) => {
    try {
      const conditionId = parseInt(req.params.id);
      const conditionData = { ...req.body };
      if (conditionData.diagnosedDate) {
        conditionData.diagnosedDate = new Date(conditionData.diagnosedDate);
      }
      const condition = await storage.updateMedicalCondition(conditionId, conditionData);
      if (!condition) {
        return res.status(404).json({ message: "Medical condition not found" });
      }
      res.json(condition);
    } catch (error) {
      console.error("Error updating medical condition:", error);
      res.status(500).json({ message: "Failed to update medical condition" });
    }
  });

  app.delete("/api/medical-conditions/:id", async (req, res) => {
    try {
      const conditionId = parseInt(req.params.id);
      const success = await storage.deleteMedicalCondition(conditionId);
      if (!success) {
        return res.status(404).json({ message: "Medical condition not found" });
      }
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting medical condition:", error);
      res.status(500).json({ message: "Failed to delete medical condition" });
    }
  });

  // Adverse Medications
  app.get("/api/adverse-medications", async (req: any, res) => {
    try {
      if (!req.session.userId || !req.session.user) {
        return res.status(401).json({ message: "Authentication required" });
      }
      
      const user = req.session.user;
      const adverseMeds = await storage.getAdverseMedicationsByUser(user.id);
      res.json(adverseMeds);
    } catch (error) {
      console.error("Error fetching adverse medications:", error);
      res.status(500).json({ message: "Failed to fetch adverse medications" });
    }
  });

  app.post("/api/adverse-medications", async (req: any, res) => {
    try {
      if (!req.session.userId || !req.session.user) {
        return res.status(401).json({ message: "Authentication required" });
      }
      
      const user = req.session.user;
      // Convert reactionDate string to Date object if provided
      const adverseMedData = { ...req.body, userId: user.id };
      if (adverseMedData.reactionDate) {
        adverseMedData.reactionDate = new Date(adverseMedData.reactionDate);
      }
      const adverseMed = await storage.createAdverseMedication(adverseMedData);
      res.status(201).json(adverseMed);
    } catch (error) {
      console.error("Error creating adverse medication:", error);
      res.status(500).json({ message: "Failed to create adverse medication" });
    }
  });

  app.put("/api/adverse-medications/:id", async (req, res) => {
    try {
      const adverseMedId = parseInt(req.params.id);
      const adverseMedData = { ...req.body };
      if (adverseMedData.reactionDate) {
        adverseMedData.reactionDate = new Date(adverseMedData.reactionDate);
      }
      const adverseMed = await storage.updateAdverseMedication(adverseMedId, adverseMedData);
      res.json(adverseMed);
    } catch (error) {
      console.error("Error updating adverse medication:", error);
      res.status(500).json({ message: "Failed to update adverse medication" });
    }
  });

  app.delete("/api/adverse-medications/:id", async (req, res) => {
    try {
      const adverseMedId = parseInt(req.params.id);
      const success = await storage.deleteAdverseMedication(adverseMedId);
      if (!success) {
        return res.status(404).json({ message: "Adverse medication not found" });
      }
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting adverse medication:", error);
      res.status(500).json({ message: "Failed to delete adverse medication" });
    }
  });

  // Sleep Tracking Routes
  const validateSleepSessionFields = (data: any, timeZone?: string): string | null => {
    const requiredFields = [
      ["sleepDate", "Sleep date"],
      ["bedtime", "Bedtime"],
      ["sleepTime", "Time fell asleep"],
      ["wakeTime", "Wake time"],
      ["quality", "Sleep quality"],
    ] as const;

    const missingField = requiredFields.find(([field]) => {
      const value = data?.[field];
      return value === undefined || value === null || String(value).trim() === "";
    });

    if (missingField) return `${missingField[1]} is required`;

    const dateError = getSleepDateValidationError(data.sleepDate, new Date(), timeZone);
    if (dateError) return dateError;

    return getSleepRoutineTimeValidationError(data.bedtime, data.sleepTime, data.wakeTime);
  };

  const withSleepMetrics = (session: any) => {
    const metrics = calculateSleepMetrics(session, DEFAULT_SLEEP_GOAL_MINUTES);
    return {
      ...session,
      totalSleepDuration: metrics.totalSleepDuration ?? session.totalSleepDuration ?? null,
      sleepEfficiency: metrics.sleepEfficiency ?? session.sleepEfficiency ?? null,
      sleepScore: metrics.sleepScore ?? session.sleepScore ?? null,
    };
  };

  app.get("/api/sleep-sessions", async (req: any, res) => {
    try {
      if (!req.session?.userId || !req.session?.user) {
        return res.status(401).json({ message: "Authentication required" });
      }
      
      const sessions = await storage.getSleepSessionsByUser(req.session.user.id);
      res.json(sessions.map(withSleepMetrics));
    } catch (error) {
      console.error("Error fetching sleep sessions:", error);
      res.status(500).json({ message: "Failed to fetch sleep sessions" });
    }
  });

  app.post("/api/sleep-sessions", async (req: any, res) => {
    try {
      if (!req.session?.userId || !req.session?.user) {
        return res.status(401).json({ message: "Authentication required" });
      }
      
      const sessionData = { ...req.body, userId: req.session.user.id };
      const timeZone = req.get("X-User-Timezone") || undefined;
      const validationError = validateSleepSessionFields(sessionData, timeZone);
      if (validationError) {
        return res.status(400).json({ error: validationError, message: validationError });
      }

      const existingSession = await storage.getSleepSessionByDate(
        req.session.user.id,
        sessionData.sleepDate,
      );
      if (existingSession) {
        return res.status(409).json({
          message: "A sleep session already exists for this date",
        });
      }
      
      // Convert ISO strings to Date objects for TIMESTAMP columns
      if (sessionData.bedtime) {
        sessionData.bedtime = new Date(sessionData.bedtime);
      }
      if (sessionData.sleepTime) {
        sessionData.sleepTime = new Date(sessionData.sleepTime);
      }
      if (sessionData.wakeTime) {
        sessionData.wakeTime = new Date(sessionData.wakeTime);
      }

      const metrics = calculateSleepMetrics(sessionData, DEFAULT_SLEEP_GOAL_MINUTES);
      sessionData.totalSleepDuration = metrics.totalSleepDuration;
      sessionData.sleepEfficiency = metrics.sleepEfficiency?.toFixed(2);
      sessionData.sleepScore = metrics.sleepScore;
      
      const session = await storage.createSleepSession(sessionData);
      res.status(201).json(withSleepMetrics(session));
    } catch (error) {
      console.error("Error creating sleep session:", error);
      res.status(500).json({ message: "Failed to create sleep session" });
    }
  });

  app.put("/api/sleep-sessions/:id", async (req: any, res) => {
    try {
      if (!req.session?.userId || !req.session?.user) {
        return res.status(401).json({ message: "Authentication required" });
      }
      
      const sessionId = parseInt(req.params.id);
      const updates = { ...req.body };
      const timeZone = req.get("X-User-Timezone") || undefined;
      const validationError = validateSleepSessionFields(updates, timeZone);
      if (validationError) {
        return res.status(400).json({ error: validationError, message: validationError });
      }
      
      // Convert ISO strings to Date objects for TIMESTAMP columns
      if (updates.bedtime) {
        updates.bedtime = new Date(updates.bedtime);
      }
      if (updates.sleepTime) {
        updates.sleepTime = new Date(updates.sleepTime);
      }
      if (updates.wakeTime) {
        updates.wakeTime = new Date(updates.wakeTime);
      }

      const metrics = calculateSleepMetrics(updates, DEFAULT_SLEEP_GOAL_MINUTES);
      updates.totalSleepDuration = metrics.totalSleepDuration;
      updates.sleepEfficiency = metrics.sleepEfficiency?.toFixed(2);
      updates.sleepScore = metrics.sleepScore;
      
      const session = await storage.updateSleepSession(sessionId, updates);
      if (!session) {
        return res.status(404).json({ message: "Sleep session not found" });
      }
      res.json(withSleepMetrics(session));
    } catch (error) {
      console.error("Error updating sleep session:", error);
      res.status(500).json({ message: "Failed to update sleep session" });
    }
  });

  app.delete("/api/sleep-sessions/:id", async (req: any, res) => {
    try {
      if (!req.session?.userId || !req.session?.user) {
        return res.status(401).json({ message: "Authentication required" });
      }
      
      const sessionId = parseInt(req.params.id);
      const success = await storage.deleteSleepSession(sessionId, req.session.user.id);
      if (!success) {
        return res.status(404).json({ message: "Sleep session not found" });
      }
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting sleep session:", error);
      res.status(500).json({ message: "Failed to delete sleep session" });
    }
  });

  app.get("/api/sleep-sessions/date/:date", async (req: any, res) => {
    try {
      if (!req.session?.userId || !req.session?.user) {
        return res.status(401).json({ message: "Authentication required" });
      }
      
      const session = await storage.getSleepSessionByDate(req.session.user.id, req.params.date);
      if (!session) {
        return res.status(404).json({ message: "No sleep session found for this date" });
      }
      res.json(withSleepMetrics(session));
    } catch (error) {
      console.error("Error fetching sleep session by date:", error);
      res.status(500).json({ message: "Failed to fetch sleep session" });
    }
  });

  // Health Metrics Routes
  app.get("/api/health-metrics", async (req: any, res) => {
    try {
      if (!req.session?.userId || !req.session?.user) {
        return res.status(401).json({ message: "Authentication required" });
      }
      
      const { metricType, startDate, endDate } = req.query;
      const metrics = await storage.getHealthMetricsByUser(
        req.session.user.id, 
        metricType as string,
        startDate as string, 
        endDate as string
      );
      res.json(metrics);
    } catch (error) {
      console.error("Error fetching health metrics:", error);
      res.status(500).json({ message: "Failed to fetch health metrics" });
    }
  });

  app.post("/api/health-metrics", async (req: any, res) => {
    try {
      if (!req.session?.userId || !req.session?.user) {
        return res.status(401).json({ message: "Authentication required" });
      }
      
      const metricData = { ...req.body, userId: req.session.user.id };
      
      // Convert recordedAt to Date object
      if (metricData.recordedAt) {
        metricData.recordedAt = new Date(metricData.recordedAt);
      }
      
      const metric = await storage.createHealthMetric(metricData);
      res.status(201).json(metric);
    } catch (error) {
      console.error("Error creating health metric:", error);
      res.status(500).json({ message: "Failed to create health metric" });
    }
  });

  // Emergency Contacts
  app.get("/api/emergency-contacts", async (req, res) => {
    try {
      const userId = 1; // Hardcoded for demo
      const contacts = await storage.getEmergencyContactsByUser(userId);
      res.json(contacts);
    } catch (error) {
      console.error("Error fetching emergency contacts:", error);
      res.status(500).json({ message: "Failed to fetch emergency contacts" });
    }
  });

  app.post("/api/emergency-contacts", async (req, res) => {
    try {
      const userId = 1; // Hardcoded for demo
      const contactData = insertEmergencyContactSchema.parse({ ...req.body, userId });
      const contact = await storage.createEmergencyContact(contactData);
      res.status(201).json(contact);
    } catch (error) {
      console.error("Error creating emergency contact:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: error.issues[0]?.message ?? "Invalid emergency contact data" });
      }
      res.status(500).json({ message: "Failed to create emergency contact" });
    }
  });

  app.put("/api/emergency-contacts/:id", async (req, res) => {
    try {
      const contactId = parseInt(req.params.id);
      const updates = updateEmergencyContactSchema.parse(req.body);
      const contact = await storage.updateEmergencyContact(contactId, updates);
      res.json(contact);
    } catch (error) {
      console.error("Error updating emergency contact:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: error.issues[0]?.message ?? "Invalid emergency contact data" });
      }
      res.status(500).json({ message: "Failed to update emergency contact" });
    }
  });

  app.delete("/api/emergency-contacts/:id", async (req, res) => {
    try {
      const contactId = parseInt(req.params.id);
      const success = await storage.deleteEmergencyContact(contactId);
      if (!success) {
        return res.status(404).json({ message: "Emergency contact not found" });
      }
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting emergency contact:", error);
      res.status(500).json({ message: "Failed to delete emergency contact" });
    }
  });

  // Primary Care Providers
  app.get("/api/primary-care-providers", async (req, res) => {
    try {
      const userId = 1; // Hardcoded for demo
      const providers = await storage.getPrimaryCareProvidersByUser(userId);
      res.json(providers);
    } catch (error) {
      console.error("Error fetching primary care providers:", error);
      res.status(500).json({ message: "Failed to fetch primary care providers" });
    }
  });

  app.post("/api/primary-care-providers", async (req, res) => {
    try {
      const userId = 1; // Hardcoded for demo
      const providerData = { ...req.body, userId };
      const provider = await storage.createPrimaryCareProvider(providerData);
      res.status(201).json(provider);
    } catch (error) {
      console.error("Error creating primary care provider:", error);
      res.status(500).json({ message: "Failed to create primary care provider" });
    }
  });

  app.put("/api/primary-care-providers/:id", async (req, res) => {
    try {
      const providerId = parseInt(req.params.id);
      const provider = await storage.updatePrimaryCareProvider(providerId, req.body);
      res.json(provider);
    } catch (error) {
      console.error("Error updating primary care provider:", error);
      res.status(500).json({ message: "Failed to update primary care provider" });
    }
  });

  app.delete("/api/primary-care-providers/:id", async (req, res) => {
    try {
      const providerId = parseInt(req.params.id);
      const success = await storage.deletePrimaryCareProvider(providerId);
      if (!success) {
        return res.status(404).json({ message: "Primary care provider not found" });
      }
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting primary care provider:", error);
      res.status(500).json({ message: "Failed to delete primary care provider" });
    }
  });

  // Symptom Tracking Routes
  app.get("/api/symptom-entries", async (req, res) => {
    try {
      if (!req.session.userId || !req.session.user) {
        return res.status(401).json({ message: "Authentication required" });
      }
      const entries = await storage.getSymptomEntriesByUser(req.session.userId);
      res.json(entries);
    } catch (error) {
      console.error("Error fetching symptom entries:", error);
      res.status(500).json({ message: "Failed to fetch symptom entries" });
    }
  });

  app.get("/api/symptom-entries/date-range", async (req, res) => {
    try {
      if (!req.session.userId || !req.session.user) {
        return res.status(401).json({ message: "Authentication required" });
      }
      const { startDate, endDate } = req.query;
      
      if (!startDate || !endDate) {
        return res.status(400).json({ message: "Start date and end date are required" });
      }
      
      const entries = await storage.getSymptomEntriesByDateRange(
        req.session.userId, 
        startDate as string, 
        endDate as string
      );
      res.json(entries);
    } catch (error) {
      console.error("Error fetching symptom entries by date range:", error);
      res.status(500).json({ message: "Failed to fetch symptom entries" });
    }
  });

  app.post("/api/symptom-entries", requireAuth, async (req: any, res) => {
    try {
      console.log("Creating symptom entry for user:", req.user.id);
      console.log("Request body:", req.body);
      
      const entryData = { 
        ...req.body, 
        userId: req.user.id,
        startTime: new Date(req.body.startTime),
        endTime: req.body.endTime ? new Date(req.body.endTime) : null
      };
      
      console.log("Entry data to save:", entryData);
      
      const entry = await storage.createSymptomEntry(entryData);
      console.log("Created symptom entry:", entry);
      res.status(201).json(entry);
    } catch (error) {
      console.error("Error creating symptom entry:", error);
      res.status(500).json({ message: "Failed to create symptom entry" });
    }
  });

  app.patch("/api/symptom-entries/:id", requireAuth, async (req: any, res) => {
    try {
      const entryId = parseInt(req.params.id);
      console.log("PATCH symptom - Original body:", JSON.stringify(req.body, null, 2));
      
      const updates = { ...req.body };
      
      // Convert date strings to Date objects
      if (updates.startTime && typeof updates.startTime === 'string') {
        updates.startTime = new Date(updates.startTime);
        console.log("Converted startTime to Date:", updates.startTime);
      }
      if (updates.endTime && typeof updates.endTime === 'string') {
        updates.endTime = new Date(updates.endTime);
        console.log("Converted endTime to Date:", updates.endTime);
      }
      
      // Remove createdAt if it exists (it's auto-generated)
      delete updates.createdAt;
      delete updates.id;
      delete updates.userId;
      
      console.log("PATCH symptom - Final updates:", JSON.stringify(updates, null, 2));
      
      const updated = await storage.updateSymptomEntry(entryId, updates);
      
      if (!updated) {
        return res.status(404).json({ message: "Symptom entry not found" });
      }
      
      res.json(updated);
    } catch (error) {
      console.error("Error updating symptom entry:", error);
      res.status(500).json({ message: "Failed to update symptom entry" });
    }
  });

  app.delete("/api/symptom-entries/:id", requireAuth, async (req: any, res) => {
    try {
      const entryId = parseInt(req.params.id);
      const deleted = await storage.deleteSymptomEntry(entryId);
      
      if (!deleted) {
        return res.status(404).json({ message: "Symptom entry not found" });
      }
      
      res.json({ message: "Symptom entry deleted successfully" });
    } catch (error) {
      console.error("Error deleting symptom entry:", error);
      res.status(500).json({ message: "Failed to delete symptom entry" });
    }
  });

  // Personal Resources Routes
  app.get("/api/personal-resources", requireAuth, async (req: any, res) => {
    try {
      const userId = req.session.user.id;
      const { category } = req.query;
      
      let resources;
      if (category && typeof category === 'string') {
        resources = await storage.getPersonalResourcesByCategory(userId, category);
      } else {
        resources = await storage.getPersonalResourcesByUser(userId);
      }
      
      res.json(resources);
    } catch (error) {
      console.error("Error fetching personal resources:", error);
      res.status(500).json({ message: "Failed to fetch personal resources" });
    }
  });

  app.post("/api/personal-resources", requireAuth, async (req: any, res) => {
    try {
      const userId = req.session.user.id;
      const resourceData = insertPersonalResourceSchema.parse({ ...req.body, userId });
      
      const resource = await storage.createPersonalResource(resourceData);
      res.status(201).json(resource);
    } catch (error) {
      console.error("Error creating personal resource:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({
          message: "Please provide a title, valid URL, and category.",
          errors: error.flatten().fieldErrors,
        });
      }
      res.status(500).json({ message: "Failed to create personal resource" });
    }
  });

  app.patch("/api/personal-resources/:id", requireAuth, async (req: any, res) => {
    try {
      const resourceId = parseInt(req.params.id);
      const resources = await storage.getPersonalResourcesByUser(
        req.session.user.id,
      );
      if (!resources.some((resource) => resource.id === resourceId)) {
        return res.status(404).json({ message: "Personal resource not found" });
      }

      const updates = { ...req.body };
      delete updates.userId;
      
      const updated = await storage.updatePersonalResource(resourceId, updates);
      
      if (!updated) {
        return res.status(404).json({ message: "Personal resource not found" });
      }
      
      res.json(updated);
    } catch (error) {
      console.error("Error updating personal resource:", error);
      res.status(500).json({ message: "Failed to update personal resource" });
    }
  });

  app.delete("/api/personal-resources/:id", requireAuth, async (req: any, res) => {
    try {
      const resourceId = parseInt(req.params.id);
      const resources = await storage.getPersonalResourcesByUser(
        req.session.user.id,
      );
      if (!resources.some((resource) => resource.id === resourceId)) {
        return res.status(404).json({ message: "Personal resource not found" });
      }

      const deleted = await storage.deletePersonalResource(resourceId);
      
      if (!deleted) {
        return res.status(404).json({ message: "Personal resource not found" });
      }
      
      res.json({ message: "Personal resource deleted successfully" });
    } catch (error) {
      console.error("Error deleting personal resource:", error);
      res.status(500).json({ message: "Failed to delete personal resource" });
    }
  });

  app.patch("/api/personal-resources/:id/access", requireAuth, async (req: any, res) => {
    try {
      const resourceId = parseInt(req.params.id);
      const resources = await storage.getPersonalResourcesByUser(
        req.session.user.id,
      );
      if (!resources.some((resource) => resource.id === resourceId)) {
        return res.status(404).json({ message: "Personal resource not found" });
      }

      const updated = await storage.incrementResourceAccess(resourceId);
      
      if (!updated) {
        return res.status(404).json({ message: "Personal resource not found" });
      }
      
      res.json(updated);
    } catch (error) {
      console.error("Error updating resource access:", error);
      res.status(500).json({ message: "Failed to update resource access" });
    }
  });

  // Bus Schedule Routes
  app.get("/api/bus-schedules", async (req, res) => {
    try {
      const userId = 1; // TODO: Get from auth
      const schedules = await storage.getBusSchedulesByUser(userId);
      res.json(schedules);
    } catch (error) {
      console.error("Error fetching bus schedules:", error);
      res.status(500).json({ message: "Failed to fetch bus schedules" });
    }
  });

  app.get("/api/bus-schedules/day/:day", async (req, res) => {
    try {
      const userId = 1; // TODO: Get from auth
      const { day } = req.params;
      const schedules = await storage.getBusSchedulesByDay(userId, day);
      res.json(schedules);
    } catch (error) {
      console.error("Error fetching bus schedules by day:", error);
      res.status(500).json({ message: "Failed to fetch bus schedules by day" });
    }
  });

  app.get("/api/bus-schedules/frequent", async (req, res) => {
    try {
      const userId = 1; // TODO: Get from auth
      const schedules = await storage.getFrequentBusRoutes(userId);
      res.json(schedules);
    } catch (error) {
      console.error("Error fetching frequent bus routes:", error);
      res.status(500).json({ message: "Failed to fetch frequent bus routes" });
    }
  });

  app.post("/api/bus-schedules", async (req, res) => {
    try {
      const userId = 1; // TODO: Get from auth
      const data = insertBusScheduleSchema.parse({ ...req.body, userId });
      const schedule = await storage.createBusSchedule(data);
      res.json(schedule);
    } catch (error) {
      console.error("Error creating bus schedule:", error);
      res.status(500).json({ message: "Failed to create bus schedule" });
    }
  });

  app.put("/api/bus-schedules/:id", async (req, res) => {
    try {
      const scheduleId = parseInt(req.params.id);
      const data = insertBusScheduleSchema.partial().parse(req.body);
      const schedule = await storage.updateBusSchedule(scheduleId, data);
      
      if (!schedule) {
        return res.status(404).json({ message: "Bus schedule not found" });
      }
      
      res.json(schedule);
    } catch (error) {
      console.error("Error updating bus schedule:", error);
      res.status(500).json({ message: "Failed to update bus schedule" });
    }
  });

  app.delete("/api/bus-schedules/:id", async (req, res) => {
    try {
      const scheduleId = parseInt(req.params.id);
      const success = await storage.deleteBusSchedule(scheduleId);
      
      if (!success) {
        return res.status(404).json({ message: "Bus schedule not found" });
      }
      
      res.json({ message: "Bus schedule deleted successfully" });
    } catch (error) {
      console.error("Error deleting bus schedule:", error);
      res.status(500).json({ message: "Failed to delete bus schedule" });
    }
  });

  // Emergency Treatment Plan Routes
  app.get("/api/emergency-treatment-plans", async (req, res) => {
    try {
      const userId = 1; // TODO: Get from auth
      const plans = await storage.getEmergencyTreatmentPlansByUser(userId);
      res.json(plans);
    } catch (error) {
      console.error("Error fetching emergency treatment plans:", error);
      res.status(500).json({ message: "Failed to fetch emergency treatment plans" });
    }
  });

  app.get("/api/emergency-treatment-plans/active", async (req, res) => {
    try {
      const userId = 1; // TODO: Get from auth
      const plans = await storage.getActiveEmergencyTreatmentPlans(userId);
      res.json(plans);
    } catch (error) {
      console.error("Error fetching active emergency treatment plans:", error);
      res.status(500).json({ message: "Failed to fetch active emergency treatment plans" });
    }
  });

  app.post("/api/emergency-treatment-plans", async (req, res) => {
    try {
      const userId = 1; // TODO: Get from auth
      const data = insertEmergencyTreatmentPlanSchema.parse({ ...req.body, userId });
      const plan = await storage.createEmergencyTreatmentPlan(data);
      res.json(plan);
    } catch (error) {
      console.error("Error creating emergency treatment plan:", error);
      res.status(500).json({ message: "Failed to create emergency treatment plan" });
    }
  });

  app.put("/api/emergency-treatment-plans/:id", async (req, res) => {
    try {
      const planId = parseInt(req.params.id);
      const data = insertEmergencyTreatmentPlanSchema.partial().parse(req.body);
      const plan = await storage.updateEmergencyTreatmentPlan(planId, data);
      
      if (!plan) {
        return res.status(404).json({ message: "Emergency treatment plan not found" });
      }
      
      res.json(plan);
    } catch (error) {
      console.error("Error updating emergency treatment plan:", error);
      res.status(500).json({ message: "Failed to update emergency treatment plan" });
    }
  });

  app.delete("/api/emergency-treatment-plans/:id", async (req, res) => {
    try {
      const planId = parseInt(req.params.id);
      const success = await storage.deleteEmergencyTreatmentPlan(planId);
      
      if (!success) {
        return res.status(404).json({ message: "Emergency treatment plan not found" });
      }
      
      res.json({ message: "Emergency treatment plan deleted successfully" });
    } catch (error) {
      console.error("Error deleting emergency treatment plan:", error);
      res.status(500).json({ message: "Failed to delete emergency treatment plan" });
    }
  });

  // Geofencing API routes
  app.get("/api/geofences", async (req, res) => {
    try {
      const geofences = await storage.getGeofencesByUser(1);
      res.json(geofences);
    } catch (error) {
      console.error("Error fetching geofences:", error);
      res.status(500).json({ message: "Failed to fetch geofences" });
    }
  });

  app.get("/api/geofences/active", async (req, res) => {
    try {
      const geofences = await storage.getActiveGeofencesByUser(1);
      res.json(geofences);
    } catch (error) {
      console.error("Error fetching active geofences:", error);
      res.status(500).json({ message: "Failed to fetch active geofences" });
    }
  });

  app.post("/api/geofences", async (req, res) => {
    try {
      const geofenceData = { ...req.body, userId: 1 };
      const geofence = await storage.createGeofence(geofenceData);
      res.json(geofence);
    } catch (error) {
      console.error("Error creating geofence:", error);
      res.status(500).json({ message: "Failed to create geofence" });
    }
  });

  app.put("/api/geofences/:id", async (req, res) => {
    try {
      const geofenceId = parseInt(req.params.id);
      const updates = req.body;
      const geofence = await storage.updateGeofence(geofenceId, updates);
      
      if (!geofence) {
        return res.status(404).json({ message: "Geofence not found" });
      }
      
      res.json(geofence);
    } catch (error) {
      console.error("Error updating geofence:", error);
      res.status(500).json({ message: "Failed to update geofence" });
    }
  });

  app.delete("/api/geofences/:id", async (req, res) => {
    try {
      const geofenceId = parseInt(req.params.id);
      const success = await storage.deleteGeofence(geofenceId);
      
      if (!success) {
        return res.status(404).json({ message: "Geofence not found" });
      }
      
      res.json({ message: "Geofence deleted successfully" });
    } catch (error) {
      console.error("Error deleting geofence:", error);
      res.status(500).json({ message: "Failed to delete geofence" });
    }
  });

  // Note: The sleep tracking routes were added above with proper session auth

  app.get("/api/geofence-events", async (req, res) => {
    try {
      const limit = parseInt(req.query.limit as string) || 50;
      const events = await storage.getGeofenceEventsByUser(1, limit);
      res.json(events);
    } catch (error) {
      console.error("Error fetching geofence events:", error);
      res.status(500).json({ message: "Failed to fetch geofence events" });
    }
  });

  app.get("/api/geofences/:id/events", async (req, res) => {
    try {
      const geofenceId = parseInt(req.params.id);
      const limit = parseInt(req.query.limit as string) || 50;
      const events = await storage.getGeofenceEventsByGeofence(geofenceId, limit);
      res.json(events);
    } catch (error) {
      console.error("Error fetching geofence events:", error);
      res.status(500).json({ message: "Failed to fetch geofence events" });
    }
  });

  app.post("/api/geofence-events", async (req, res) => {
    try {
      const eventData = { ...req.body, userId: 1 };
      const event = await storage.createGeofenceEvent(eventData);
      
      // Here you could add logic to send notifications to caregivers
      // based on the geofence settings and caregiver preferences
      
      res.json(event);
    } catch (error) {
      console.error("Error creating geofence event:", error);
      res.status(500).json({ message: "Failed to create geofence event" });
    }
  });

  app.put("/api/geofence-events/:id/notify", async (req, res) => {
    try {
      const eventId = parseInt(req.params.id);
      const success = await storage.markGeofenceEventNotified(eventId);
      
      if (!success) {
        return res.status(404).json({ message: "Geofence event not found" });
      }
      
      res.json({ message: "Geofence event marked as notified" });
    } catch (error) {
      console.error("Error marking geofence event as notified:", error);
      res.status(500).json({ message: "Failed to mark geofence event as notified" });
    }
  });

  // User Preferences Routes
  app.get("/api/user-preferences", async (req, res) => {
    try {
      const userId = 1; // TODO: Get from auth
      const preferences = await storage.getUserPreferences(userId);
      
      // Return default preferences if none exist
      if (!preferences) {
        const defaultPreferences = {
          userId,
          notificationSettings: {},
          reminderTiming: {},
          themeSettings: {
            quickActions: ["mood-tracking", "daily-tasks", "financial", "caregiver"]
          },
          accessibilitySettings: {},
          behaviorPatterns: {}
        };
        res.json(defaultPreferences);
      } else {
        res.json(preferences);
      }
    } catch (error) {
      console.error("Error fetching user preferences:", error);
      res.status(500).json({ message: "Failed to fetch user preferences" });
    }
  });

  app.post("/api/user-preferences", async (req, res) => {
    try {
      const userId = 1; // TODO: Get from auth
      const preferencesData = req.body;
      const preferences = await storage.upsertUserPreferences(userId, preferencesData);
      res.json(preferences);
    } catch (error) {
      console.error("Error updating user preferences:", error);
      res.status(400).json({ message: "Failed to update user preferences" });
    }
  });

  // Wearable Devices Demo Routes (Simple static data for demo)
  app.get("/api/wearable-devices", async (req, res) => {
    try {
      const demoDevices = [
        {
          id: 1,
          name: "Apple Watch Series 9",
          type: "smartwatch",
          brand: "Apple",
          model: "Series 9",
          isConnected: true,
          batteryLevel: 87,
          lastSync: new Date().toISOString(),
          features: ["heart_rate", "steps", "sleep", "workouts", "blood_oxygen"]
        },
        {
          id: 2,
          name: "Fitbit Charge 5",
          type: "fitness_tracker",
          brand: "Fitbit",
          model: "Charge 5",
          isConnected: true,
          batteryLevel: 65,
          lastSync: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(), // 2 hours ago
          features: ["heart_rate", "steps", "sleep", "stress"]
        },
        {
          id: 3,
          name: "Galaxy Watch6 Classic",
          type: "smartwatch",
          brand: "Samsung",
          model: "Watch6 Classic",
          isConnected: true,
          batteryLevel: 72,
          lastSync: new Date(Date.now() - 30 * 60 * 1000).toISOString(), // 30 minutes ago
          features: ["heart_rate", "steps", "sleep", "workouts", "blood_oxygen", "body_composition", "ecg"]
        }
      ];
      res.json(demoDevices);
    } catch (error) {
      console.error("Error fetching wearable devices:", error);
      res.status(500).json({ message: "Failed to fetch wearable devices" });
    }
  });

  app.get("/api/health-metrics", async (req, res) => {
    try {
      const demoMetrics = [
        {
          id: 1,
          metricType: "heart_rate",
          value: 72,
          unit: "bpm",
          recordedAt: new Date().toISOString(),
          context: "resting",
          deviceId: 1 // Apple Watch
        },
        {
          id: 2,
          metricType: "steps",
          value: 7543,
          unit: "steps",
          recordedAt: new Date().toISOString(),
          context: "daily_total",
          deviceId: 1 // Apple Watch
        },
        {
          id: 3,
          metricType: "blood_oxygen",
          value: 98,
          unit: "%",
          recordedAt: new Date().toISOString(),
          context: "resting",
          deviceId: 1 // Apple Watch
        },
        {
          id: 4,
          metricType: "heart_rate",
          value: 68,
          unit: "bpm",
          recordedAt: new Date(Date.now() - 30 * 60 * 1000).toISOString(),
          context: "resting",
          deviceId: 3 // Galaxy Watch
        },
        {
          id: 5,
          metricType: "steps",
          value: 8124,
          unit: "steps",
          recordedAt: new Date(Date.now() - 30 * 60 * 1000).toISOString(),
          context: "daily_total",
          deviceId: 3 // Galaxy Watch
        },
        {
          id: 6,
          metricType: "blood_oxygen",
          value: 97,
          unit: "%",
          recordedAt: new Date(Date.now() - 30 * 60 * 1000).toISOString(),
          context: "resting",
          deviceId: 3 // Galaxy Watch
        }
      ];
      res.json(demoMetrics);
    } catch (error) {
      console.error("Error fetching health metrics:", error);
      res.status(500).json({ message: "Failed to fetch health metrics" });
    }
  });

  app.get("/api/activity-sessions", async (req, res) => {
    try {
      const demoActivities = [
        {
          id: 1,
          activityType: "walking",
          duration: 45,
          caloriesBurned: 185,
          steps: 3200,
          startedAt: new Date(Date.now() - 3 * 60 * 60 * 1000).toISOString(), // 3 hours ago
          deviceId: 1 // Apple Watch
        },
        {
          id: 2,
          activityType: "cycling",
          duration: 30,
          caloriesBurned: 240,
          steps: 0,
          startedAt: new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString(), // yesterday
          deviceId: 2 // Fitbit
        },
        {
          id: 3,
          activityType: "strength_training",
          duration: 25,
          caloriesBurned: 120,
          steps: 150,
          startedAt: new Date(Date.now() - 48 * 60 * 60 * 1000).toISOString(), // 2 days ago
          deviceId: 1 // Apple Watch
        },
        {
          id: 4,
          activityType: "running",
          duration: 35,
          caloriesBurned: 320,
          steps: 4200,
          startedAt: new Date(Date.now() - 6 * 60 * 60 * 1000).toISOString(), // 6 hours ago
          deviceId: 3 // Galaxy Watch
        },
        {
          id: 5,
          activityType: "yoga",
          duration: 20,
          caloriesBurned: 95,
          steps: 50,
          startedAt: new Date(Date.now() - 12 * 60 * 60 * 1000).toISOString(), // 12 hours ago
          deviceId: 3 // Galaxy Watch
        }
      ];
      res.json(demoActivities);
    } catch (error) {
      console.error("Error fetching activity sessions:", error);
      res.status(500).json({ message: "Failed to fetch activity sessions" });
    }
  });

  app.get("/api/sleep-sessions", async (req, res) => {
    try {
      const demoSleep = [
        {
          id: 1,
          sleepDate: new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString().split('T')[0], // last night
          totalSleepDuration: 450, // 7.5 hours in minutes
          sleepScore: 85,
          quality: "good"
        },
        {
          id: 2,
          sleepDate: new Date(Date.now() - 48 * 60 * 60 * 1000).toISOString().split('T')[0], // 2 nights ago
          totalSleepDuration: 420, // 7 hours
          sleepScore: 78,
          quality: "fair"
        },
        {
          id: 3,
          sleepDate: new Date(Date.now() - 72 * 60 * 60 * 1000).toISOString().split('T')[0], // 3 nights ago
          totalSleepDuration: 480, // 8 hours
          sleepScore: 92,
          quality: "excellent"
        }
      ];
      res.json(demoSleep);
    } catch (error) {
      console.error("Error fetching sleep sessions:", error);
      res.status(500).json({ message: "Failed to fetch sleep sessions" });
    }
  });

  app.post("/api/wearable-devices/:id/sync", async (req, res) => {
    try {
      const deviceId = parseInt(req.params.id);
      // Simulate sync operation
      setTimeout(() => {
        res.json({ 
          message: "Device synced successfully", 
          deviceId,
          lastSync: new Date().toISOString()
        });
      }, 1000);
    } catch (error) {
      console.error("Error syncing device:", error);
      res.status(500).json({ message: "Failed to sync device" });
    }
  });

  // ── Family Members Routes (Family Plan) ──────────────────────────────────────

  app.get("/api/family-members", async (req: any, res) => {
    try {
      if (!req.session?.userId || !req.session?.user) {
        return res.status(401).json({ message: "Authentication required" });
      }
      const user = req.session.user;
      if (user.subscriptionTier !== 'family' && user.accountType !== 'admin') {
        return res.status(403).json({ message: "Family plan required" });
      }
      const members = await storage.getFamilyMembers(user.id);
      res.json(members);
    } catch (error) {
      console.error("Error fetching family members:", error);
      res.status(500).json({ message: "Failed to fetch family members" });
    }
  });

  app.post("/api/family-members/invite", async (req: any, res) => {
    try {
      if (!req.session?.userId || !req.session?.user) {
        return res.status(401).json({ message: "Authentication required" });
      }
      const user = req.session.user;
      if (user.subscriptionTier !== 'family' && user.accountType !== 'admin') {
        return res.status(403).json({ message: "Family plan required to invite members" });
      }
      // Limit to 5 additional members
      const existing = await storage.getFamilyMembers(user.id);
      if (existing.length >= 5) {
        return res.status(400).json({ message: "Maximum of 5 family members reached" });
      }
      const { inviteEmail, memberName, relationship } = req.body;
      if (!inviteEmail || !memberName) {
        return res.status(400).json({ message: "Email and name are required" });
      }
      const member = await storage.inviteFamilyMember({
        primaryUserId: user.id,
        inviteEmail,
        memberName,
        relationship: relationship || "member",
      });
      res.json(member);
    } catch (error) {
      console.error("Error inviting family member:", error);
      res.status(500).json({ message: "Failed to send invite" });
    }
  });

  app.delete("/api/family-members/:id", async (req: any, res) => {
    try {
      if (!req.session?.userId || !req.session?.user) {
        return res.status(401).json({ message: "Authentication required" });
      }
      const user = req.session.user;
      const memberId = parseInt(req.params.id);
      const success = await storage.removeFamilyMember(memberId, user.id);
      if (!success) {
        return res.status(404).json({ message: "Member not found" });
      }
      res.json({ message: "Family member removed" });
    } catch (error) {
      console.error("Error removing family member:", error);
      res.status(500).json({ message: "Failed to remove member" });
    }
  });

  // Subscription Management Routes
  app.get("/api/subscription", async (req: any, res) => {
    try {
      if (!req.session?.userId || !req.session?.user) {
        return res.status(401).json({ message: "Authentication required" });
      }
      
      // Always read fresh user from DB so a recent purchase is reflected immediately,
      // even if req.session.user is momentarily stale (e.g. right after IAP verify).
      let user: any = req.session.user;
      try {
        const freshUser = await storage.getUserById(req.session.userId);
        if (freshUser) {
          user = freshUser;
          req.session.user = freshUser;
        }
      } catch (e) {
        console.error("Failed to refresh user for /api/subscription, falling back to session:", e);
      }
      
      const now = new Date();
      
      // Admin accounts get full access without payment requirements
      const isAdmin = user.accountType === 'admin' || user.username === 'admin' || user.name?.toLowerCase().includes('admin');
      
      if (isAdmin) {
        const adminSubscription = {
          id: user.id,
          planType: "admin",
          status: "active",
          billingCycle: "lifetime",
          subscriptionPlatform: null,
          currentPeriodStart: user.createdAt,
          currentPeriodEnd: null,
          trialDaysLeft: null,
          usageStats: {
            tasks: { count: 0, limit: null },
            caregivers: { count: 0, limit: null },
            dataExports: { count: 0, limit: null }
          },
          features: {
            wearableDevices: true,
            mealPlanning: true,
            medicationManagement: true,
            locationSafety: true,
            advancedAnalytics: true,
            prioritySupport: true
          }
        };
        return res.json(adminSubscription);
      }
      
      // Calculate trial days left for regular users
      const trialEndDate = new Date(user.createdAt);
      trialEndDate.setDate(trialEndDate.getDate() + FREE_TRIAL_DAYS);
      const trialDaysLeft = Math.max(0, Math.ceil((trialEndDate.getTime() - now.getTime()) / (24 * 60 * 60 * 1000)));
      
      // Check subscription status. Trust subscriptionStatus as the single source of truth.
      // Stripe, Apple, and Google webhooks update this field to 'cancelled'/'past_due' when
      // a subscription lapses — so if it says 'active', that is definitive. We do NOT
      // additionally require stripeSubscriptionId or a non-expired subscriptionExpiresAt,
      // because those fields can be null/stale for valid subscribers.
      const isActiveSubscription = user.subscriptionStatus === 'active';

      const subscription = {
        id: user.id,
        planType: user.subscriptionTier || "free",
        status: isActiveSubscription ? "active" : (trialDaysLeft > 0 ? "trialing" : "expired"),
        billingCycle: "monthly",
        subscriptionPlatform: user.subscriptionPlatform || null,
        currentPeriodStart: user.createdAt,
        currentPeriodEnd: user.subscriptionExpiresAt || trialEndDate.toISOString(),
        trialDaysLeft: trialDaysLeft > 0 ? trialDaysLeft : null,
        usageStats: {
          tasks: { count: 0, limit: user.subscriptionTier === 'family' ? null : (user.subscriptionTier === 'premium' ? 1000 : 50) },
          caregivers: { count: 0, limit: user.subscriptionTier === 'family' ? null : (user.subscriptionTier === 'premium' ? 5 : 1) },
          dataExports: { count: 0, limit: user.subscriptionTier === 'free' ? 0 : null }
        },
        features: {
          // Basic+ features
          taskManagement: user.subscriptionTier !== 'free' || trialDaysLeft > 0,
          moodTracking: user.subscriptionTier !== 'free' || trialDaysLeft > 0,
          financialTracking: user.subscriptionTier !== 'free' || trialDaysLeft > 0,
          basicReminders: user.subscriptionTier !== 'free' || trialDaysLeft > 0,
          // Premium+ features
          wearableDevices: (user.subscriptionTier === 'premium' || user.subscriptionTier === 'family') || trialDaysLeft > 0,
          mealPlanning: (user.subscriptionTier === 'premium' || user.subscriptionTier === 'family') || trialDaysLeft > 0,
          medicationManagement: (user.subscriptionTier === 'premium' || user.subscriptionTier === 'family') || trialDaysLeft > 0,
          advancedAnalytics: (user.subscriptionTier === 'premium' || user.subscriptionTier === 'family') || trialDaysLeft > 0,
          voiceCommands: (user.subscriptionTier === 'premium' || user.subscriptionTier === 'family') || trialDaysLeft > 0,
          academicPlanner: (user.subscriptionTier === 'premium' || user.subscriptionTier === 'family') || trialDaysLeft > 0,
          prioritySupport: (user.subscriptionTier === 'premium' || user.subscriptionTier === 'family') || trialDaysLeft > 0,
          // Family-only features
          locationSafety: user.subscriptionTier === 'family' || trialDaysLeft > 0,
          familyDashboard: user.subscriptionTier === 'family',
          multiUserAccounts: user.subscriptionTier === 'family',
          emergencyProtocols: user.subscriptionTier === 'family',
          customReporting: user.subscriptionTier === 'family',
          unlimitedCaregivers: user.subscriptionTier === 'family',
        }
      };
      
      res.json(subscription);
    } catch (error) {
      console.error("Error fetching subscription:", error);
      res.status(500).json({ message: "Failed to fetch subscription" });
    }
  });

  app.post("/api/subscription/upgrade", async (req: any, res) => {
    try {
      if (!req.session?.userId || !req.session?.user) {
        return res.status(401).json({ message: "Authentication required" });
      }

      const { planType, billingCycle } = req.body;
      const user = req.session.user;
      
      // Calculate the new trial end date from the configured free-trial duration.
      const trialEndDate = new Date();
      trialEndDate.setDate(trialEndDate.getDate() + FREE_TRIAL_DAYS);
      
      // Update user subscription information in session (in production this would update database)
      req.session.user = {
        ...user,
        subscriptionTier: planType,
        subscriptionStatus: 'trialing',
        subscriptionExpiresAt: trialEndDate.toISOString()
      };

      const upgradedSubscription = {
        id: user.id,
        planType,
        status: "trialing",
        billingCycle,
        currentPeriodStart: new Date().toISOString(),
        currentPeriodEnd: trialEndDate.toISOString(),
        trialDaysLeft: FREE_TRIAL_DAYS,
        usageStats: {
          tasks: { count: 0, limit: planType === "family" ? null : 1000 },
          caregivers: { count: 0, limit: planType === "family" ? null : 10 },
          dataExports: { count: 0, limit: null }
        },
        features: {
          wearableDevices: true,
          mealPlanning: true,
          medicationManagement: true,
          locationSafety: planType === "family",
          advancedAnalytics: planType === "family",
          prioritySupport: true,
          familyAccounts: planType === "family" ? 5 : 1
        }
      };

      res.json(upgradedSubscription);
    } catch (error) {
      console.error("Error upgrading subscription:", error);
      res.status(500).json({ message: "Failed to upgrade subscription" });
    }
  });

  // Real Stripe Payment Routes
  app.post("/api/create-payment-intent", async (req, res) => {
    try {
      const { planType, billingCycle } = req.body;
      
      // Check if Stripe is available
      const currentStripe = getStripeInstance();
      if (!currentStripe) {
        console.log("Stripe not configured - using demo mode");
        return res.status(200).json({ 
          clientSecret: "pi_demo_" + Date.now() + "_secret_demo",
          demoMode: true,
          message: "Demo payment mode - Stripe configuration pending"
        });
      }
      
      // Define pricing based on plan
      const pricing = {
        basic: { monthly: 499, annual: 4900 }, // $4.99, $49
        premium: { monthly: 1299, annual: 12900 }, // $12.99, $129
        family: { monthly: 2499, annual: 24900 } // $24.99, $249
      };
      
      const amount = pricing[planType as keyof typeof pricing]?.[billingCycle as keyof typeof pricing.basic] || 1299;
      
      const paymentIntent = await currentStripe.paymentIntents.create({
        amount,
        currency: "usd",
        metadata: {
          planType,
          billingCycle,
          userId: "1" // Replace with actual user ID
        }
      });
      
      res.json({ 
        clientSecret: paymentIntent.client_secret,
        demoMode: false,
        message: "Live payment processing enabled"
      });
    } catch (error: any) {
      console.error("Error creating payment intent:", error);
      
      // Handle specific Stripe authentication errors
      if (error.type === 'StripeAuthenticationError') {
        console.log("Stripe authentication failed - falling back to demo mode");
        
        // Fallback to demo mode while Stripe account is being activated
        return res.status(200).json({ 
          clientSecret: "pi_demo_" + Date.now() + "_secret_demo",
          demoMode: true,
          message: "Demo payment mode - your Stripe account is being activated"
        });
      }
      
      res.status(500).json({ 
        message: "Failed to create payment intent",
        error: error.message || "Unknown error"
      });
    }
  });

  // Retired legacy path. It previously activated access from a standalone
  // PaymentIntent and could leave the account without a recurring Stripe
  // subscription. Web checkout now always uses create/confirm-subscription.
  app.post("/api/upgrade-subscription", (_req: any, res) => {
    return res.status(410).json({
      message: "This checkout flow has been retired. Please subscribe from the subscription page.",
    });
  });

  // Recover subscription for users who paid but whose status wasn't updated
  app.post("/api/recover-subscription", async (req: any, res) => {
    try {
      if (!req.session?.userId) {
        return res.status(401).json({ message: "Authentication required" });
      }
      const userId = req.session.userId;
      const user = await storage.getUserById(userId);
      if (!user) return res.status(404).json({ message: "User not found" });

      const currentStripe = getStripeInstance();
      if (!currentStripe) {
        return res.status(400).json({ message: "Stripe not configured" });
      }

      if (!user.stripeCustomerId) {
        return res.status(400).json({
          code: "NO_SUBSCRIPTION",
          message: "No verified Stripe subscription is linked to this account. Please subscribe below or contact support.",
        });
      }

      const stripeCustomer = await currentStripe.customers.retrieve(user.stripeCustomerId);
      if (
        stripeCustomer.deleted ||
        stripeCustomer.metadata?.userId !== String(userId)
      ) {
        console.warn(`Stripe subscription recovery rejected for user ${userId}: customer ownership mismatch`);
        return res.status(403).json({ message: "The linked Stripe customer does not belong to this account." });
      }

      let subscriptionTier = 'basic';
      let billingCycle = 'monthly';
      let expiresAt = new Date();
      expiresAt.setMonth(expiresAt.getMonth() + 1);
      let found = false;

      // Recovery only trusts an active or trialing recurring subscription.
      const subscriptions = await currentStripe.subscriptions.list({
        customer: stripeCustomer.id,
        status: 'all',
        limit: 5,
        expand: ['data.latest_invoice', 'data.pending_setup_intent', 'data.default_payment_method']
      });
      const validSubscription = subscriptions.data.find((sub) => {
        if (sub.status === 'active') return true;
        if (sub.status !== 'trialing') return false;

        // A new free-trial subscription is trialing before its card SetupIntent
        // completes. Recovery must not turn that unconfirmed trial into access.
        const setupIntent = sub.pending_setup_intent as any;
        const hasSavedPaymentMethod = Boolean(sub.default_payment_method);
        return setupIntent?.status === 'succeeded' || hasSavedPaymentMethod;
      });
      if (validSubscription) {
        const sub = validSubscription;
        const planMeta = (sub.metadata?.planType as string) || 'basic';
        subscriptionTier = planMeta === 'premium' ? 'premium' : planMeta === 'family' ? 'family' : 'basic';
        billingCycle = (sub.metadata?.billingCycle as string) || 'monthly';
        if (sub.current_period_end) expiresAt = new Date(sub.current_period_end * 1000);
        found = true;
      }

      if (!found) {
        return res.status(400).json({ 
          code: "NO_SUBSCRIPTION",
          message: "No active recurring subscription found on your account. If you believe this is an error, please contact support."
        });
      }

      await storage.updateUserSubscription(userId, {
        subscriptionTier,
        subscriptionStatus: 'active',
        subscriptionExpiresAt: expiresAt
      });

      const updatedUser = await storage.getUserById(userId);
      if (updatedUser && req.session) {
        req.session.user = updatedUser;
      }

      console.log(`✅ Subscription recovered for user ${userId}: ${subscriptionTier} plan`);

      res.json({
        message: "Subscription recovered successfully",
        plan: subscriptionTier,
        billing: billingCycle,
        expiresAt: expiresAt.toISOString()
      });
    } catch (error: any) {
      console.error("Error recovering subscription:", error);
      res.status(500).json({ message: "Failed to recover subscription", error: error.message });
    }
  });

  // Subscription status check middleware
  function requireActiveSubscription(req: any, res: any, next: any) {
    if (!req.session?.userId || !req.session?.user) {
      return res.status(401).json({ message: "Authentication required" });
    }
    
    const user = req.session.user;
    const now = new Date();
    
    // Trust subscriptionStatus as the single source of truth. Webhooks (Stripe, Apple,
    // Google) update this field when a subscription lapses — 'active' is definitive.
    if (user.subscriptionStatus === 'active') {
      return next(); // Active paid subscription
    }
    
    // Check if user is in the free trial from account creation.
    const trialEndDate = new Date(user.createdAt);
    trialEndDate.setDate(trialEndDate.getDate() + FREE_TRIAL_DAYS);
    
    if (now < trialEndDate && user.subscriptionTier === 'free') {
      return next(); // Still in free trial
    }
    
    // Trial expired and no active subscription
    return res.status(402).json({ 
      message: "Subscription required",
      trialExpired: true,
      requiresPayment: true
    });
  }

  // ─── Stripe Webhook (recurring billing, cancellations, failures) ────────────
  // Register this URL in Stripe Dashboard → Developers → Webhooks:
  //   https://app.getadaptalyfeapp.com/api/stripe/webhook
  // Events to listen for: invoice.payment_succeeded, invoice.payment_failed,
  //   customer.subscription.updated, customer.subscription.deleted
  app.post("/api/stripe/webhook", async (req: any, res) => {
    const sig = req.headers['stripe-signature'];
    const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET;
    const currentStripe = getStripeInstance();

    if (!currentStripe) {
      console.error("Stripe webhook: Stripe not configured");
      return res.status(500).send("Stripe not configured");
    }

    if (!webhookSecret) {
      console.error("Stripe webhook: STRIPE_WEBHOOK_SECRET is not configured");
      return res.status(500).send("Webhook configuration error");
    }

    if (!sig) {
      console.warn("Stripe webhook: missing Stripe signature");
      return res.status(400).send("Missing Stripe signature");
    }

    let event: any;
    try {
      // Verify the event signature (req.body is raw Buffer via express.raw).
      event = currentStripe.webhooks.constructEvent(req.body, sig, webhookSecret);
    } catch (err: any) {
      console.error("Stripe webhook signature verification failed:", err.message);
      return res.status(400).send(`Webhook Error: ${err.message}`);
    }

    try {
      const tierMap: Record<string, string> = {
        'adaptalyfe_basic_monthly': 'basic', 'adaptalyfe_basic_annual': 'basic',
        'adaptalyfe_premium_monthly': 'premium', 'adaptalyfe_premium_annual': 'premium',
        'adaptalyfe_family_monthly': 'family', 'adaptalyfe_family_annual': 'family',
      };
      const appStatusForStripeSubscription = (sub: any): string => {
        if (sub.status !== 'trialing') return sub.status;
        const setupIntent = sub.pending_setup_intent as any;
        const hasSavedPaymentMethod = Boolean(sub.default_payment_method);
        return setupIntent?.status === 'succeeded' || hasSavedPaymentMethod
          ? 'trialing'
          : 'pending';
      };

      const extendSubscription = async (
        stripeSubId: string,
        periodEnd: number,
        stripeStatus: string,
        tier?: string,
      ) => {
        // Webhook mutations must match the currently stored subscription ID.
        // A customer can have a canceled historical subscription and a new one;
        // customer-only fallback would let delayed old events overwrite the new state.
        const user = await storage.getUserByStripeSubscriptionId(stripeSubId);
        if (!user) {
          console.warn(`Stripe webhook: ignoring event for unknown or replaced subscription ${stripeSubId}`);
          return;
        }

        const statusMap: Record<string, string> = {
          active: 'active', trialing: 'active', past_due: 'past_due',
          canceled: 'cancelled', unpaid: 'past_due', incomplete: 'pending',
        };
        const expiresAt = new Date(periodEnd * 1000);
        await storage.updateUserSubscription(user.id, {
          subscriptionStatus: statusMap[stripeStatus] || stripeStatus,
          subscriptionExpiresAt: expiresAt,
          ...((stripeStatus === 'active' || stripeStatus === 'trialing') && tier ? { subscriptionTier: tier } : {}),
        });
        console.log(`✅ Stripe webhook: synchronized user ${user.id} (${user.username}) to ${stripeStatus} until ${expiresAt.toISOString()}`);
      };

      switch (event.type) {
        case 'invoice.payment_succeeded': {
          const invoice = event.data.object as any;
          const subId = invoice.subscription || invoice.parent?.subscription_details?.subscription;
          // Get the subscription to find current_period_end
          if (subId) {
            const sub = await currentStripe.subscriptions.retrieve(subId, {
              expand: ['pending_setup_intent', 'default_payment_method'],
            });
            const metadata = sub.metadata || {};
            const tierFromMeta = metadata.planType ? tierMap[metadata.planType] || metadata.planType : undefined;
            await extendSubscription(
              subId,
               getStripePeriodEndSeconds(sub),
              appStatusForStripeSubscription(sub),
              tierFromMeta,
            );
          }
          break;
        }
        case 'customer.subscription.updated': {
          const eventSubscription = event.data.object as any;
          const sub = await currentStripe.subscriptions.retrieve(eventSubscription.id, {
            expand: ['pending_setup_intent', 'default_payment_method'],
          });
          const statusMap: Record<string, string> = {
            active: 'active', trialing: 'active', past_due: 'past_due',
            canceled: 'cancelled', unpaid: 'past_due', incomplete: 'pending',
          };
          const user = await storage.getUserByStripeSubscriptionId(sub.id);
          if (user) {
            const periodEnd = getStripePeriodEndSeconds(sub);
            await storage.updateUserSubscription(user.id, {
              subscriptionStatus: statusMap[appStatusForStripeSubscription(sub)] || appStatusForStripeSubscription(sub),
              subscriptionExpiresAt: new Date(periodEnd * 1000),
            });
            console.log(`✅ Stripe webhook: updated user ${user.id} status=${sub.status}`);
          }
          break;
        }
        case 'customer.subscription.deleted': {
          const sub = event.data.object as any;
          const user = await storage.getUserByStripeSubscriptionId(sub.id);
          if (user) {
            await storage.updateUserSubscription(user.id, {
              subscriptionStatus: 'cancelled',
              subscriptionTier: 'free',
            });
            console.log(`✅ Stripe webhook: cancelled user ${user.id}`);
          }
          break;
        }
        case 'invoice.payment_failed': {
          const invoice = event.data.object as any;
          const subId = invoice.subscription || invoice.parent?.subscription_details?.subscription;
          const user = subId
            ? await storage.getUserByStripeSubscriptionId(subId)
            : null;
          if (user) {
            await storage.updateUserSubscription(user.id, { subscriptionStatus: 'past_due' });
            console.log(`⚠️  Stripe webhook: payment failed for user ${user.id}`);
          }
          break;
        }
        default:
          console.log(`Stripe webhook: unhandled event type ${event.type}`);
      }

      // Only acknowledge after subscription state is persisted. A 5xx response
      // tells Stripe to retry if a transient API or database failure occurs.
      return res.status(200).json({ received: true });
    } catch (err: any) {
      console.error("Stripe webhook processing error:", err.message);
      return res.status(500).send("Webhook processing failed");
    }
  });

  // Create Stripe subscription with proper setup
  app.post("/api/create-subscription", async (req: any, res) => {
    try {
      if (!req.session?.userId || !req.session?.user) {
        return res.status(401).json({ message: "Authentication required" });
      }
      
      const user = req.session.user;
      const { planType, billingCycle } = req.body;
      
      const currentStripe = getStripeInstance();
      if (!currentStripe) {
        return res.status(500).json({ message: "Payment processing unavailable" });
      }

      // Native store subscriptions are already active across all platforms.
      // Do not create a second Stripe subscription for the same account.
      const freshUser = await storage.getUserById(req.session.userId);
      const currentUser = freshUser || user;
      if (
        currentUser.subscriptionStatus === 'active' &&
        currentUser.subscriptionPlatform &&
        currentUser.subscriptionPlatform !== 'web'
      ) {
        return res.status(409).json({
          message: `This account already has an active ${currentUser.subscriptionPlatform === 'google_play' ? 'Google Play' : 'Apple App Store'} subscription.`
        });
      }
      
      // Create or retrieve Stripe customer
      let customer;
      if (currentUser.stripeCustomerId) {
        customer = await currentStripe.customers.retrieve(currentUser.stripeCustomerId);
      } else {
        const customerOptions: Stripe.CustomerCreateParams = {
          email: currentUser.email || undefined,
          name: currentUser.name || undefined,
          metadata: { userId: currentUser.id.toString() },
        };

        // Optional accelerated-renewal testing. A Test Clock is accepted only
        // with Stripe test-mode credentials, so it can never attach to a live
        // customer or affect production billing.
        if (
          process.env.STRIPE_SECRET_KEY?.startsWith('sk_test_') &&
          process.env.STRIPE_TEST_CLOCK_ID
        ) {
          customerOptions.test_clock = process.env.STRIPE_TEST_CLOCK_ID;
        }

        customer = await currentStripe.customers.create(customerOptions);

        // Update user with Stripe customer ID
         await storage.updateUser(currentUser.id, { stripeCustomerId: customer.id });
      }
      
      // Define pricing
      const pricing = {
        basic: { monthly: 499, annual: 4900 }, // $4.99, $49
        premium: { monthly: 1299, annual: 12900 }, // $12.99, $129
        family: { monthly: 2499, annual: 24900 } // $24.99, $249
      };
      
      const planPricing = pricing[planType as keyof typeof pricing];
      if (!planPricing || (billingCycle !== 'monthly' && billingCycle !== 'annual')) {
        return res.status(400).json({ message: "Invalid subscription plan or billing cycle" });
      }
      const amount = planPricing[billingCycle];
      
      // If this user already has an active Stripe subscription, cancel it first
      // to avoid duplicate subscriptions building up.
      if (currentUser.stripeSubscriptionId) {
        try {
          const existing = await currentStripe.subscriptions.retrieve(currentUser.stripeSubscriptionId);
          if (existing.status !== 'canceled' && existing.status !== 'incomplete_expired') {
            await currentStripe.subscriptions.cancel(currentUser.stripeSubscriptionId);
            console.log(`Cancelled previous Stripe subscription ${currentUser.stripeSubscriptionId} before creating new one`);
          }
        } catch (e: any) {
          // Subscription may already be gone on Stripe's side — that's fine
          console.warn('Could not cancel previous subscription:', e.message);
        }
      }

      // Look up or create a price for this plan/cycle combination.
      // We search existing prices first so we don't create duplicate products on every attempt.
      const planLabel = `adaptalyfe_${planType}_${billingCycle}`;
      let price: any;
      const existingPrices = await currentStripe.prices.search({
        query: `metadata['plan_key']:'${planLabel}' AND active:'true'`,
        limit: 1,
      });
      if (existingPrices.data.length > 0) {
        price = existingPrices.data[0];
        console.log(`Reusing existing Stripe price ${price.id} for ${planLabel}`);
      } else {
        const product = await currentStripe.products.create({
          name: `Adaptalyfe ${planType.charAt(0).toUpperCase() + planType.slice(1)} Plan`,
          description: `${billingCycle} subscription to Adaptalyfe ${planType} features`,
          metadata: { plan_key: planLabel },
        });
        price = await currentStripe.prices.create({
          currency: 'usd',
          product: product.id,
          unit_amount: amount,
          recurring: { interval: billingCycle === 'annual' ? 'year' : 'month' },
          metadata: { plan_key: planLabel },
        });
        console.log(`Created new Stripe price ${price.id} for ${planLabel}`);
      }

      // Create a recurring subscription. For a free trial, Stripe returns a
      // pending SetupIntent so the card is saved for the first renewal.
      const subscription = await currentStripe.subscriptions.create({
        customer: customer.id,
        items: [{ price: price.id }],
        trial_period_days: FREE_TRIAL_DAYS,
        payment_behavior: 'default_incomplete',
        payment_settings: {
          save_default_payment_method: 'on_subscription',
          payment_method_types: ['card']
        },
        trial_settings: {
          end_behavior: { missing_payment_method: 'cancel' },
        },
        expand: ['latest_invoice.payment_intent', 'pending_setup_intent'],
        metadata: {
           userId: currentUser.id.toString(),
          planType,
          billingCycle
        }
      });

      // A trial uses a SetupIntent; an immediate charge uses the invoice's
      // PaymentIntent. Never create a standalone intent, because it is not
      // linked to the recurring subscription or its future renewal.
      let clientSecret: string | null = null;
      let intentType: 'payment' | 'setup' | null = null;
      let intentId: string | null = null;
      const invoice = subscription.latest_invoice as any;

      if (invoice && invoice.payment_intent) {
        clientSecret = invoice.payment_intent.client_secret;
        intentType = 'payment';
        intentId = invoice.payment_intent.id;
      } else {
        const setupIntent = subscription.pending_setup_intent as any;
        if (setupIntent?.client_secret) {
          clientSecret = setupIntent.client_secret;
          intentType = 'setup';
          intentId = setupIntent.id;
        }
      }

      if (!clientSecret && subscription.status !== 'active') {
        await currentStripe.subscriptions.cancel(subscription.id);
        return res.status(502).json({
          message: "Stripe could not prepare secure payment-method setup for this subscription",
        });
      }

      // Update user subscription info
       await storage.updateUser(currentUser.id, {
        stripeSubscriptionId: subscription.id,
        subscriptionTier: planType,
        subscriptionStatus: 'pending',
        subscriptionPlatform: 'web',
      });

      console.log('Final subscription setup:', {
        subscriptionId: subscription.id,
        hasClientSecret: !!clientSecret,
        intentType,
        subscriptionStatus: subscription.status,
        intentId,
      });

      res.json({
        subscriptionId: subscription.id,
        clientSecret,
        intentType,
        intentId,
        status: subscription.status,
        requiresPayment: !!clientSecret
      });
      
    } catch (error: any) {
      console.error("Error creating subscription:", error);
      res.status(500).json({ 
        message: "Failed to create subscription",
        error: error.message 
      });
    }
  });

  // Confirm subscription payment
  app.post("/api/confirm-subscription", async (req: any, res) => {
    try {
      if (!req.session?.userId || !req.session?.user) {
        return res.status(401).json({ message: "Authentication required" });
      }
      
      const user = req.session.user;
      const { subscriptionId } = req.body;
      if (!subscriptionId || typeof subscriptionId !== 'string') {
        return res.status(400).json({ message: "Subscription ID is required" });
      }
      
      const currentStripe = getStripeInstance();
      if (!currentStripe) {
        return res.status(500).json({ message: "Payment processing unavailable" });
      }
      
      // Retrieve and verify that this subscription belongs to the authenticated
      // user before changing their paid-access status.
      const subscription = await currentStripe.subscriptions.retrieve(subscriptionId, {
        expand: ['pending_setup_intent', 'default_payment_method', 'latest_invoice.payment_intent'],
      });
      const subscriptionCustomerId = typeof subscription.customer === 'string'
        ? subscription.customer
        : subscription.customer?.id;
      const subscriptionUserId = subscription.metadata?.userId;

      if (
        subscriptionUserId !== String(user.id) ||
        (user.stripeCustomerId && subscriptionCustomerId !== user.stripeCustomerId)
      ) {
        console.warn(`Stripe subscription confirmation rejected for user ${user.id}`);
        return res.status(403).json({ message: "Subscription does not belong to this account" });
      }

      const pendingSetupIntent = subscription.pending_setup_intent as any;
      const invoice = subscription.latest_invoice as any;
      const invoicePaymentIntent = invoice?.payment_intent as any;
      const hasSavedPaymentMethod = Boolean(subscription.default_payment_method);
      const trialPaymentReady =
        pendingSetupIntent?.status === 'succeeded' || hasSavedPaymentMethod;
      const immediatePaymentReady =
        !invoicePaymentIntent || invoicePaymentIntent.status === 'succeeded';
      const isReadyToActivate =
        (subscription.status === 'trialing' && trialPaymentReady) ||
        (subscription.status === 'active' && immediatePaymentReady);

      if (isReadyToActivate) {
        const metadata = subscription.metadata;
        // Use Stripe's authoritative period end, not a calculated date
        const expiresAt = new Date(getStripePeriodEndSeconds(subscription) * 1000);
        
        await storage.updateUserSubscription(user.id, {
          subscriptionTier: metadata.planType || 'premium',
          subscriptionStatus: 'active',
          subscriptionExpiresAt: expiresAt,
          stripeSubscriptionId: subscription.id,
          stripeCustomerId: subscriptionCustomerId,
          subscriptionPlatform: 'web',
        });

        // Refresh session so the user doesn't need to log out/in to see the change
        const updatedUser = await storage.getUserById(user.id);
        if (updatedUser && req.session) req.session.user = updatedUser;
        
        res.json({ 
          success: true, 
          message: "Subscription activated successfully",
          plan: metadata.planType,
          expiresAt: expiresAt.toISOString()
        });
      } else {
        res.json({ 
          success: false, 
          status: subscription.status,
          message: "Payment method setup or subscription payment is not complete"
        });
      }
      
    } catch (error: any) {
      console.error("Error confirming subscription:", error);
      res.status(500).json({ 
        message: "Failed to confirm subscription",
        error: error.message 
      });
    }
  });

  // Google Play Store subscription verification
  app.post("/api/google-play/verify-purchase", async (req: any, res) => {
    try {
      if (!req.session?.userId || !req.session?.user) {
        return res.status(401).json({ message: "Authentication required" });
      }

      const user = req.session.user;
      const { purchaseToken, productId, orderId } = req.body;

      if (!purchaseToken || !productId) {
        return res.status(400).json({ message: "Missing purchaseToken or productId" });
      }

      const freshUser = await storage.getUserById(req.session.userId);
      if (
        freshUser?.subscriptionStatus === 'active' &&
        freshUser.subscriptionPlatform &&
        freshUser.subscriptionPlatform !== 'google_play'
      ) {
        return res.status(409).json({
          message: "This account already has an active subscription. It works on Android without another Google Play purchase."
        });
      }

      const productToPlan: Record<string, { planType: string; billingCycle: string; amount: number }> = {
        adaptalyfe_basic_monthly: { planType: 'basic', billingCycle: 'monthly', amount: 499 },
        adaptalyfe_premium_monthly: { planType: 'premium', billingCycle: 'monthly', amount: 1299 },
        adaptalyfe_family_monthly: { planType: 'family', billingCycle: 'monthly', amount: 2499 },
      };

      const planInfo = productToPlan[productId];
      if (!planInfo) {
        return res.status(400).json({ message: "Invalid product ID" });
      }

      let verified = false;
      let expiryTime: Date | null = null;

      if (process.env.GOOGLE_PLAY_SERVICE_ACCOUNT_KEY) {
        try {
          const serviceAccount = JSON.parse(process.env.GOOGLE_PLAY_SERVICE_ACCOUNT_KEY);
          const { google } = await import('googleapis');
          const auth = new google.auth.GoogleAuth({
            credentials: serviceAccount,
            scopes: ['https://www.googleapis.com/auth/androidpublisher'],
          });
          const androidPublisher = google.androidpublisher({ version: 'v3', auth });

          const packageName = 'com.adaptalyfe.app';
          const purchaseResult = await androidPublisher.purchases.subscriptionsv2.get({
            packageName,
            token: purchaseToken,
          });

          const subscriptionState = purchaseResult.data.subscriptionState;
          if (subscriptionState === 'SUBSCRIPTION_STATE_ACTIVE' || subscriptionState === 'SUBSCRIPTION_STATE_IN_GRACE_PERIOD') {
            const lineItems = purchaseResult.data.lineItems;
            if (lineItems && lineItems.length > 0) {
              const matchingItem = lineItems.find((item: any) => item.productId === productId);
              if (!matchingItem) {
                console.error(`Product ID mismatch: expected ${productId}, got ${lineItems.map((i: any) => i.productId).join(',')}`);
                return res.status(400).json({ message: "Product ID mismatch in purchase verification" });
              }

              verified = true;
              const expiryStr = matchingItem.expiryTime;
              if (expiryStr) {
                expiryTime = new Date(expiryStr);
              }
            } else {
              verified = true;
            }

            if (verified && purchaseResult.data.acknowledgementState === 'ACKNOWLEDGEMENT_STATE_PENDING') {
              try {
                await androidPublisher.purchases.subscriptions.acknowledge({
                  packageName,
                  subscriptionId: productId,
                  token: purchaseToken,
                });
                console.log(`Acknowledged purchase for ${productId}`);
              } catch (ackError: any) {
                console.error("Purchase acknowledgement error:", ackError.message);
              }
            }
          } else {
            console.error(`Subscription not active: state=${subscriptionState}`);
            return res.status(400).json({ message: "Subscription is not active" });
          }
        } catch (apiError: any) {
          console.error("Google Play API verification error:", apiError.message);
          return res.status(500).json({ message: "Purchase verification failed - API error" });
        }
      } else {
        console.error("GOOGLE_PLAY_SERVICE_ACCOUNT_KEY is not configured");
        return res.status(503).json({ message: "Google Play verification not configured" });
      }

      if (!verified) {
        return res.status(400).json({ message: "Purchase verification failed" });
      }

      if (!expiryTime) {
        return res.status(502).json({
          message: "Google Play verification did not return an expiration time",
        });
      }

      await storage.updateUser(user.id, {
        subscriptionTier: planInfo.planType,
        subscriptionStatus: 'active',
        subscriptionExpiresAt: expiryTime,
        subscriptionPlatform: 'google_play',
        googlePlayPurchaseToken: purchaseToken,
        googlePlayOrderId: orderId || null,
        googlePlayProductId: productId,
      });

      req.session.user = {
        ...req.session.user,
        subscriptionTier: planInfo.planType,
        subscriptionStatus: 'active',
        subscriptionExpiresAt: expiryTime,
        subscriptionPlatform: 'google_play',
      };

      // Force session persistence before responding so the next /api/subscription
      // call from the client sees the active subscription immediately.
      await new Promise<void>((resolve) => {
        req.session.save((err: any) => {
          if (err) console.error("Session save error after Google Play verify:", err);
          resolve();
        });
      });

      console.log(`Google Play subscription verified for user ${user.id}: ${productId} -> ${planInfo.planType} (${planInfo.billingCycle})`);

      res.json({
        success: true,
        planType: planInfo.planType,
        billingCycle: planInfo.billingCycle,
        expiresAt: expiryTime.toISOString(),
        platform: 'google_play',
      });
    } catch (error: any) {
      console.error("Google Play verification error:", error);
      res.status(500).json({ message: "Failed to verify purchase", error: error.message });
    }
  });

  // ─── Apple App Store Receipt Verification ───────────────────────────────────
  app.post("/api/apple/verify-purchase", async (req: any, res) => {
    try {
      if (!req.session?.userId || !req.session?.user) {
        return res.status(401).json({ message: "Authentication required" });
      }

      const user = req.session.user;
      const { receiptData, productId, transactionId } = req.body;

      if (!receiptData || !productId) {
        return res.status(400).json({ message: "Missing receiptData or productId" });
      }

      const freshUser = await storage.getUserById(req.session.userId);
      if (
        freshUser?.subscriptionStatus === 'active' &&
        freshUser.subscriptionPlatform &&
        freshUser.subscriptionPlatform !== 'app_store'
      ) {
        return res.status(409).json({
          message: "This account already has an active subscription. It works on iPhone without another App Store purchase."
        });
      }

      const productToPlan: Record<string, { planType: string; billingCycle: string; amount: number }> = {
        adaptalyfe_basic_monthly: { planType: 'basic', billingCycle: 'monthly', amount: 499 },
        adaptalyfe_premium_monthly: { planType: 'premium', billingCycle: 'monthly', amount: 1299 },
        adaptalyfe_family_monthly: { planType: 'family', billingCycle: 'monthly', amount: 2499 },
      };

      const planInfo = productToPlan[productId];
      if (!planInfo) {
        return res.status(400).json({ message: "Invalid product ID" });
      }

      let verified = false;
      let expiryTime: Date | null = null;

      const APPLE_SHARED_SECRET = process.env.APPLE_SHARED_SECRET;
      if (APPLE_SHARED_SECRET) {
        try {
          // Try production first, then sandbox
          const verifyReceipt = async (url: string) => {
            const response = await fetch(url, {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                'receipt-data': receiptData,
                'password': APPLE_SHARED_SECRET,
                'exclude-old-transactions': true,
              }),
            });
            return response.json();
          };

          let appleResponse = await verifyReceipt('https://buy.itunes.apple.com/verifyReceipt');

          // status 21007 means sandbox receipt sent to production — retry with sandbox
          if (appleResponse.status === 21007) {
            appleResponse = await verifyReceipt('https://sandbox.itunes.apple.com/verifyReceipt');
          }

          if (appleResponse.status !== 0) {
            console.error(`Apple receipt validation failed: status ${appleResponse.status}`);
            return res.status(400).json({ message: `Apple receipt invalid (status ${appleResponse.status})` });
          }

          // Find latest valid receipt for our product ID
          const latestReceipts: any[] = appleResponse.latest_receipt_info || appleResponse.receipt?.in_app || [];
          const matchingReceipts = latestReceipts.filter((r: any) => r.product_id === productId);

          if (matchingReceipts.length === 0) {
            return res.status(400).json({ message: "No matching subscription found in receipt" });
          }

          // Sort by expires_date_ms descending, pick the latest
          matchingReceipts.sort((a: any, b: any) => Number(b.expires_date_ms || 0) - Number(a.expires_date_ms || 0));
          const latest = matchingReceipts[0];
          const expiresMs = Number(latest.expires_date_ms);

          if (!expiresMs || expiresMs < Date.now()) {
            return res.status(400).json({ message: "Subscription has expired" });
          }

          verified = true;
          expiryTime = new Date(expiresMs);
        } catch (appleError: any) {
          console.error("Apple receipt verification error:", appleError.message);
          return res.status(500).json({ message: "Apple receipt verification failed" });
        }
      } else {
        // Development fallback — no shared secret configured
        console.warn("APPLE_SHARED_SECRET not configured — accepting Apple purchase in dev mode only");
        if (process.env.NODE_ENV === 'production') {
          return res.status(503).json({ message: "Apple receipt verification not configured" });
        }
        verified = true;
      }

      if (!verified) {
        return res.status(400).json({ message: "Apple purchase verification failed" });
      }

      if (!expiryTime) {
        expiryTime = new Date();
        expiryTime.setMonth(expiryTime.getMonth() + 1);
      }

      // Extract original_transaction_id from the verified receipt for server notifications
      let originalTransactionId: string | undefined;
      if (APPLE_SHARED_SECRET) {
        try {
          const verifyForTxId = async (url: string) => {
            const r = await fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ 'receipt-data': receiptData, 'password': APPLE_SHARED_SECRET, 'exclude-old-transactions': true }) });
            return r.json();
          };
          let resp = await verifyForTxId('https://buy.itunes.apple.com/verifyReceipt');
          if (resp.status === 21007) resp = await verifyForTxId('https://sandbox.itunes.apple.com/verifyReceipt');
          if (resp.status === 0) {
            const receipts: any[] = resp.latest_receipt_info || resp.receipt?.in_app || [];
            const match = receipts.filter((r: any) => r.product_id === productId)
              .sort((a: any, b: any) => Number(b.expires_date_ms || 0) - Number(a.expires_date_ms || 0))[0];
            if (match) originalTransactionId = match.original_transaction_id;
          }
        } catch (_) {}
      }
      // Fall back to client-supplied transactionId if receipt lookup didn't produce one
      if (!originalTransactionId && transactionId) originalTransactionId = transactionId;

      await storage.updateUser(user.id, {
        subscriptionTier: planInfo.planType,
        subscriptionStatus: 'active',
        subscriptionExpiresAt: expiryTime,
        subscriptionPlatform: 'app_store',
        ...(originalTransactionId ? { appleOriginalTransactionId: originalTransactionId } : {}),
      });

      req.session.user = {
        ...req.session.user,
        subscriptionTier: planInfo.planType,
        subscriptionStatus: 'active',
        subscriptionExpiresAt: expiryTime,
        subscriptionPlatform: 'app_store',
      };

      // Force session persistence before responding so the next /api/subscription
      // call from the client sees the active subscription immediately.
      await new Promise<void>((resolve) => {
        req.session.save((err: any) => {
          if (err) console.error("Session save error after Apple verify:", err);
          resolve();
        });
      });

      console.log(`Apple subscription verified for user ${user.id}: ${productId} -> ${planInfo.planType}`);

      res.json({
        success: true,
        planType: planInfo.planType,
        billingCycle: planInfo.billingCycle,
        expiresAt: expiryTime.toISOString(),
        platform: 'app_store',
      });
    } catch (error: any) {
      console.error("Apple verification error:", error);
      res.status(500).json({ message: "Failed to verify Apple purchase", error: error.message });
    }
  });

  // ─── Apple Restore Purchases (for reinstalls) ────────────────────────────────
  app.post("/api/apple/restore-purchases", async (req: any, res) => {
    try {
      if (!req.session?.userId || !req.session?.user) {
        return res.status(401).json({ message: "Authentication required" });
      }

      const user = req.session.user;
      const { receiptData } = req.body;

      if (!receiptData) {
        return res.json({ restored: false, message: "No receipt data provided" });
      }

      const APPLE_SHARED_SECRET = process.env.APPLE_SHARED_SECRET;
      if (!APPLE_SHARED_SECRET) {
        if (process.env.NODE_ENV !== 'production') {
          return res.json({ restored: false, message: "Apple not configured (dev mode)" });
        }
        return res.status(503).json({ message: "Apple receipt verification not configured" });
      }

      const productToPlan: Record<string, { planType: string; billingCycle: string }> = {
        adaptalyfe_basic_monthly:   { planType: 'basic',   billingCycle: 'monthly' },
        adaptalyfe_premium_monthly: { planType: 'premium', billingCycle: 'monthly' },
        adaptalyfe_family_monthly:  { planType: 'family',  billingCycle: 'monthly' },
      };

      const verifyUrl = async (url: string) => {
        const r = await fetch(url, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ 'receipt-data': receiptData, 'password': APPLE_SHARED_SECRET, 'exclude-old-transactions': true }),
        });
        return r.json();
      };

      let appleResponse = await verifyUrl('https://buy.itunes.apple.com/verifyReceipt');
      if (appleResponse.status === 21007) {
        appleResponse = await verifyUrl('https://sandbox.itunes.apple.com/verifyReceipt');
      }

      if (appleResponse.status !== 0) {
        return res.json({ restored: false, message: `Apple receipt invalid (status ${appleResponse.status})` });
      }

      const receipts: any[] = appleResponse.latest_receipt_info || [];
      const now = Date.now();

      // Find the active subscription with the latest expiry
      const active = receipts
        .filter((r: any) => productToPlan[r.product_id] && Number(r.expires_date_ms) > now)
        .sort((a: any, b: any) => Number(b.expires_date_ms) - Number(a.expires_date_ms))[0];

      if (!active) {
        return res.json({ restored: false, message: "No active Apple subscription found" });
      }

      const planInfo = productToPlan[active.product_id];
      const expiresAt = new Date(Number(active.expires_date_ms));

      await storage.updateUser(user.id, {
        subscriptionTier: planInfo.planType,
        subscriptionStatus: 'active',
        subscriptionExpiresAt: expiresAt,
        subscriptionPlatform: 'app_store',
      });

      req.session.user = { ...req.session.user, subscriptionTier: planInfo.planType, subscriptionStatus: 'active', subscriptionExpiresAt: expiresAt, subscriptionPlatform: 'app_store' };

      await new Promise<void>((resolve) => {
        req.session.save((err: any) => {
          if (err) console.error("Session save error after Apple restore:", err);
          resolve();
        });
      });

      console.log(`Apple subscription restored for user ${user.id}: ${active.product_id} -> ${planInfo.planType}`);
      res.json({ restored: true, planType: planInfo.planType, expiresAt: expiresAt.toISOString() });
    } catch (error: any) {
      console.error("Apple restore error:", error);
      res.status(500).json({ message: "Failed to restore Apple purchases" });
    }
  });

  // ─── Apple Server-to-Server Notifications (renewals, cancellations, refunds) ─
  // Set this URL in App Store Connect → App Information → App Store Server Notifications
  // URL: https://app.getadaptalyfeapp.com/api/apple/notifications
  app.post("/api/apple/notifications", async (req: any, res) => {
    // Always respond 200 immediately so Apple stops retrying
    res.status(200).json({ received: true });

    try {
      const { signedPayload, unified_receipt, notification_type } = req.body;

      const APPLE_SHARED_SECRET = process.env.APPLE_SHARED_SECRET;
      if (!APPLE_SHARED_SECRET) {
        console.warn("Apple notification received but APPLE_SHARED_SECRET not set");
        return;
      }

      const productToPlan: Record<string, string> = {
        adaptalyfe_basic_monthly:   'basic',
        adaptalyfe_premium_monthly: 'premium',
        adaptalyfe_family_monthly:  'family',
      };

      // ── V1 Notifications ──────────────────────────────────────────────────────
      if (unified_receipt) {
        const latestInfo: any[] = unified_receipt.latest_receipt_info || [];
        const type = (notification_type || '') as string;

        const latestReceipt = latestInfo
          .sort((a: any, b: any) => Number(b.expires_date_ms) - Number(a.expires_date_ms))[0];
        if (!latestReceipt) { console.warn("Apple notif: no receipt in payload"); return; }

        const originalTransactionId: string = latestReceipt.original_transaction_id;
        const productId: string = latestReceipt.product_id;
        const planType = productToPlan[productId];
        const expiresAt = new Date(Number(latestReceipt.expires_date_ms));

        console.log(`Apple notification [${type}] product=${productId} originalTxId=${originalTransactionId} expires=${expiresAt.toISOString()}`);

        // Look up user by stored original_transaction_id
        const user = originalTransactionId
          ? await storage.getUserByAppleTransactionId(originalTransactionId)
          : undefined;

        if (!user) {
          console.warn(`Apple notif: no user found for originalTxId=${originalTransactionId}`);
          return;
        }

        const isRenewal  = ['DID_RENEW','INITIAL_BUY','DID_RECOVER','INTERACTIVE_RENEWAL'].includes(type);
        const isCancel   = ['CANCEL','REFUND','REVOKE'].includes(type);
        const isExpired  = type === 'DID_FAIL_TO_RENEW' || type === 'EXPIRED';

        if (isRenewal && planType) {
          await storage.updateUserSubscription(user.id, {
            subscriptionStatus: 'active',
            subscriptionTier: planType,
            subscriptionExpiresAt: expiresAt,
            subscriptionPlatform: 'app_store',
          });
          console.log(`✅ Apple renewal: updated user ${user.id} (${user.username}) → ${planType} until ${expiresAt.toISOString()}`);
        } else if (isCancel) {
          await storage.updateUserSubscription(user.id, {
            subscriptionStatus: 'cancelled',
            subscriptionTier: 'free',
          });
          console.log(`✅ Apple cancel: user ${user.id} (${user.username}) subscription cancelled`);
        } else if (isExpired) {
          await storage.updateUserSubscription(user.id, {
            subscriptionStatus: 'inactive',
            subscriptionTier: 'free',
          });
          console.log(`✅ Apple expired: user ${user.id} (${user.username}) subscription expired`);
        }
      }

      // ── V2 Signed Notifications (JWT) ─────────────────────────────────────────
      // Apple sends V2 notifications as a signed JWT. Decoding requires the
      // @apple/app-store-server-library package. For now we log it so we can
      // track if App Store Connect is sending V2 format.
      if (signedPayload) {
        console.log("Apple V2 signed notification received — JWT payload length:", signedPayload.length);
        // TODO: install @apple/app-store-server-library and decode the JWT
        // to handle V2 notifications with the same logic as V1 above.
      }
    } catch (error: any) {
      console.error("Apple notification processing error:", error);
    }
  });

  // ─── Google Play Server-to-Server Notifications (Pub/Sub push) ──────────────
  // In Google Play Console → Monetization → Real-time developer notifications:
  //   Topic: create a Cloud Pub/Sub topic, subscribe with push endpoint:
  //   https://app.getadaptalyfeapp.com/api/google-play/notifications
  app.post("/api/google-play/notifications", async (req: any, res) => {
    // Acknowledge immediately so Pub/Sub doesn't retry
    res.status(200).json({ received: true });

    try {
      // Pub/Sub wraps the message in { message: { data: base64, messageId } }
      const pubsubMessage = req.body?.message;
      if (!pubsubMessage?.data) {
        console.warn("Google Play notification: no Pub/Sub message data");
        return;
      }

      const decoded = Buffer.from(pubsubMessage.data, 'base64').toString('utf8');
      const notification = JSON.parse(decoded);
      console.log("Google Play notification:", JSON.stringify(notification));

      const { subscriptionNotification, voidedPurchaseNotification } = notification;
      if (!subscriptionNotification) return;

      const { notificationType, purchaseToken, subscriptionId } = subscriptionNotification;

      // https://developer.android.com/google/play/billing/rtdn-reference
      // 1=RECOVERED 2=RENEWED 3=CANCELED 4=PURCHASED 5=ON_HOLD 6=IN_GRACE_PERIOD
      // 7=RESTARTED 12=REVOKED 13=EXPIRED
      const RENEWED   = [1, 2, 4, 7];
      const CANCELLED = [3, 12];
      const EXPIRED   = [13];

      const productToPlan: Record<string, { tier: string }> = {
        adaptalyfe_basic_monthly:   { tier: 'basic' },
        adaptalyfe_premium_monthly: { tier: 'premium' },
        adaptalyfe_family_monthly:  { tier: 'family' },
      };

      // Find user by stored purchase token
      const user = purchaseToken
        ? await storage.getUserByGooglePlayToken(purchaseToken)
        : undefined;

      if (!user) {
        console.warn(`Google Play notif: no user found for purchaseToken=${purchaseToken?.slice(0, 20)}...`);
        return;
      }

      const planInfo = productToPlan[subscriptionId];

      if (RENEWED.includes(notificationType) && planInfo) {
        // Verify with Google Play API to get the actual expiry date
        let expiresAt = new Date();
        expiresAt.setMonth(expiresAt.getMonth() + 1); // fallback: extend 1 month

        if (process.env.GOOGLE_PLAY_SERVICE_ACCOUNT_KEY) {
          try {
            const { google } = await import('googleapis') as any;
            const serviceAccount = JSON.parse(process.env.GOOGLE_PLAY_SERVICE_ACCOUNT_KEY);
            const auth = new google.auth.GoogleAuth({
              credentials: serviceAccount,
              scopes: ['https://www.googleapis.com/auth/androidpublisher'],
            });
            const androidPublisher = google.androidpublisher({ version: 'v3', auth });
            // Use subscriptionsv2 (same API as verify-purchase endpoint for consistency)
            const result = await androidPublisher.purchases.subscriptionsv2.get({
              packageName: 'com.adaptalyfe.app',
              token: purchaseToken,
            });
            const lineItems = result.data?.lineItems;
            if (lineItems && lineItems.length > 0) {
              const item = lineItems.find((li: any) => li.productId === subscriptionId) || lineItems[0];
              if (item?.expiryTime) {
                expiresAt = new Date(item.expiryTime);
              }
            }
          } catch (gpErr: any) {
            console.warn("Google Play API verification failed, using +1 month fallback:", gpErr.message);
          }
        }

        await storage.updateUserSubscription(user.id, {
          subscriptionStatus: 'active',
          subscriptionTier: planInfo.tier,
          subscriptionExpiresAt: expiresAt,
          subscriptionPlatform: 'google_play',
        });
        console.log(`✅ Google Play renewal: user ${user.id} (${user.username}) → ${planInfo.tier} until ${expiresAt.toISOString()}`);
      } else if (CANCELLED.includes(notificationType)) {
        await storage.updateUserSubscription(user.id, {
          subscriptionStatus: 'cancelled',
          subscriptionTier: 'free',
        });
        console.log(`✅ Google Play cancel: user ${user.id} (${user.username}) subscription cancelled`);
      } else if (EXPIRED.includes(notificationType)) {
        await storage.updateUserSubscription(user.id, {
          subscriptionStatus: 'inactive',
          subscriptionTier: 'free',
        });
        console.log(`✅ Google Play expired: user ${user.id} (${user.username}) subscription expired`);
      } else {
        console.log(`Google Play notif type ${notificationType} for user ${user.id} — no action needed`);
      }
    } catch (error: any) {
      console.error("Google Play notification processing error:", error);
    }
  });

  app.post("/api/google-play/restore-purchases", async (req: any, res) => {
    try {
      if (!req.session?.userId || !req.session?.user) {
        return res.status(401).json({ message: "Authentication required" });
      }

      const user = req.session.user;
      const { purchases } = req.body;

      if (!purchases || !Array.isArray(purchases) || purchases.length === 0) {
        return res.json({ restored: false, message: "No purchases to restore" });
      }

      const productToPlan: Record<string, { planType: string; billingCycle: string }> = {
        adaptalyfe_basic_monthly: { planType: 'basic', billingCycle: 'monthly' },
        adaptalyfe_premium_monthly: { planType: 'premium', billingCycle: 'monthly' },
        adaptalyfe_family_monthly: { planType: 'family', billingCycle: 'monthly' },
      };

      let restored = false;
      for (const purchase of purchases) {
        if (!purchase.purchaseToken || !purchase.productId) continue;
        const planInfo = productToPlan[purchase.productId];
        if (!planInfo) continue;

        let expiresAt: Date | null = null;

        if (process.env.GOOGLE_PLAY_SERVICE_ACCOUNT_KEY) {
          try {
            const serviceAccount = JSON.parse(process.env.GOOGLE_PLAY_SERVICE_ACCOUNT_KEY);
            const { google } = await import('googleapis');
            const auth = new google.auth.GoogleAuth({
              credentials: serviceAccount,
              scopes: ['https://www.googleapis.com/auth/androidpublisher'],
            });
            const androidPublisher = google.androidpublisher({ version: 'v3', auth });
            const purchaseResult = await androidPublisher.purchases.subscriptionsv2.get({
              packageName: 'com.adaptalyfe.app',
              token: purchase.purchaseToken,
            });
            const state = purchaseResult.data.subscriptionState;
            if (state !== 'SUBSCRIPTION_STATE_ACTIVE' && state !== 'SUBSCRIPTION_STATE_IN_GRACE_PERIOD') {
              continue;
            }
            const lineItems = purchaseResult.data.lineItems;
            if (lineItems && lineItems.length > 0 && lineItems[0].expiryTime) {
              expiresAt = new Date(lineItems[0].expiryTime);
            }
          } catch (verifyError: any) {
            console.error("Restore verification error:", verifyError.message);
            continue;
          }
        } else {
          console.error("GOOGLE_PLAY_SERVICE_ACCOUNT_KEY is not configured");
          return res.status(503).json({ message: "Google Play verification not configured" });
        }

        if (!expiresAt) {
          continue;
        }

        await storage.updateUser(user.id, {
          subscriptionTier: planInfo.planType,
          subscriptionStatus: 'active',
          subscriptionExpiresAt: expiresAt,
          subscriptionPlatform: 'google_play',
          googlePlayPurchaseToken: purchase.purchaseToken,
          googlePlayOrderId: purchase.orderId || null,
          googlePlayProductId: purchase.productId,
        });

        req.session.user = {
          ...req.session.user,
          subscriptionTier: planInfo.planType,
          subscriptionStatus: 'active',
          subscriptionExpiresAt: expiresAt,
          subscriptionPlatform: 'google_play',
        };

        console.log(`Restored Google Play subscription for user ${user.id}: ${purchase.productId}`);
        restored = true;
        break;
      }

      res.json({ restored, message: restored ? "Subscription restored successfully" : "No valid purchases found" });
    } catch (error: any) {
      console.error("Restore purchases error:", error);
      res.status(500).json({ message: "Failed to restore purchases", error: error.message });
    }
  });

  app.get("/api/subscription/payment-history", async (req, res) => {
    try {
      // Get actual payment history from Stripe
      const stripeInstance = getStripeInstance();
      if (!stripeInstance) {
        return res.json([]);
      }
      const payments = await stripeInstance.paymentIntents.list({
        limit: 10,
        metadata: { userId: "1" } // Replace with actual user ID
      });
      
      const formattedPayments = payments.data.map((payment: any) => ({
        id: payment.id,
        amount: payment.amount,
        currency: payment.currency,
        status: payment.status,
        description: payment.description || "Adaptalyfe Subscription",
        paidAt: new Date(payment.created * 1000).toISOString(),
        paymentMethod: payment.payment_method ? "•••• " + payment.payment_method.slice(-4) : "N/A"
      }));
      
      res.json(formattedPayments);
    } catch (error) {
      console.error("Error fetching payment history:", error);
      res.status(500).json({ message: "Failed to fetch payment history" });
    }
  });

  // Caregiver dashboard routes
  app.get("/api/caregiver-users", async (req, res) => {
    try {
      // In a real app, this would get users assigned to the authenticated caregiver
      // For demo purposes, return the demo user
      // Demo caregiver users - replace with actual data from storage
      const users = [{ id: 1, username: "demo_user", name: "Demo User" }];
      const userProgress = users.map((user: any) => ({
        userId: user.id,
        userName: user.name || user.username,
        streakDays: user.streakDays || 12,
        lastActive: new Date().toISOString(),
        completionRate: 85,
        moodTrend: 'stable' as const,
        alertsCount: 1
      }));
      res.json(userProgress);
    } catch (error) {
      console.error("Error fetching caregiver users:", error);
      res.status(500).json({ message: "Failed to fetch users" });
    }
  });

  app.get("/api/user-summary/:userId", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      const user = await storage.getUser(userId);
      const tasks = await storage.getDailyTasks(userId);
      const moods = await storage.getMoodEntries(userId);
      const appointments = await storage.getAppointments(userId);
      const medications = await storage.getMedications(userId);

      const summary = {
        user,
        taskCompletion: {
          total: tasks.length,
          completed: tasks.filter(t => t.isCompleted).length,
          rate: tasks.length > 0 ? Math.round((tasks.filter(t => t.isCompleted).length / tasks.length) * 100) : 0
        },
        moodData: {
          recent: moods.slice(-7),
          average: moods.length > 0 ? (moods.reduce((sum, m) => sum + m.mood, 0) / moods.length).toFixed(1) : 0
        },
        upcomingAppointments: appointments.filter(a => new Date(a.appointmentDate) > new Date()).slice(0, 3),
        medications: medications.filter(m => !m.isDiscontinued)
      };

      res.json(summary);
    } catch (error) {
      console.error("Error fetching user summary:", error);
      res.status(500).json({ message: "Failed to fetch user summary" });
    }
  });

  // Banking demo routes (simplified for now)
  app.post('/api/bank-accounts/connect-plaid', (req, res) => {
    res.json({ 
      message: 'Demo bank accounts connected successfully',
      demo_mode: true,
      linkToken: 'demo-link-token-12345'
    });
  });

  app.get('/api/bank-accounts', (req, res) => {
    res.json([
      {
        id: 1,
        accountName: 'Demo Checking Account',
        accountType: 'checking',
        bankName: 'Demo Bank',
        accountNumber: '****1234',
        routingNumber: '****5678',
        balance: 2500.00,
        isActive: true,
        lastSynced: new Date().toISOString()
      },
      {
        id: 2,
        accountName: 'Demo Savings Account',
        accountType: 'savings',
        bankName: 'Demo Bank',
        accountNumber: '****9876',
        routingNumber: '****5678',
        balance: 8750.00,
        isActive: true,
        lastSynced: new Date().toISOString()
      }
    ]);
  });

  app.get('/api/bill-payments', (req, res) => {
    res.json([
      {
        id: 1,
        billName: 'Electric Bill',
        payeeWebsite: 'demo-electric.com',
        accountNumber: '****1234',
        isAutoPay: true,
        paymentAmount: 85.00,
        paymentDate: 15,
        nextPayment: '2025-08-15',
        status: 'active'
      }
    ]);
  });

  app.post('/api/bill-payments', (req, res) => {
    try {
      const { billName, payeeWebsite, accountNumber, paymentAmount, paymentDate, isAutoPay } = req.body;
      
      // Create a new bill payment record
      const newPayment = {
        id: Date.now(), // Simple ID generation for demo
        billName,
        payeeWebsite: payeeWebsite || 'demo-payee.com',
        accountNumber: accountNumber || '****1234',
        isAutoPay,
        paymentAmount,
        paymentDate,
        isActive: true,
        nextPayment: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0], // 30 days from now
        status: 'active'
      };
      
      res.json(newPayment);
    } catch (error) {
      console.error('Error creating bill payment:', error);
      res.status(400).json({ message: 'Failed to create bill payment' });
    }
  });

  // Payment limits endpoint
  app.get('/api/payment-limits', (req, res) => {
    res.json([
      {
        id: 1,
        limitType: 'daily',
        amount: 500,
        isActive: true
      },
      {
        id: 2,
        limitType: 'monthly',
        amount: 2000,
        isActive: true
      },
      {
        id: 3,
        limitType: 'per_transaction',
        amount: 1000,
        isActive: true
      }
    ]);
  });

  // Bank account sync endpoint
  app.post('/api/bank-accounts/:id/sync', (req, res) => {
    const accountId = parseInt(req.params.id);
    res.json({ 
      message: 'Account balance synced successfully',
      accountId,
      lastSynced: new Date().toISOString()
    });
  });

  // Bill payment toggle endpoint
  app.patch('/api/bill-payments/:id/toggle', (req, res) => {
    const paymentId = parseInt(req.params.id);
    const { isActive } = req.body;
    res.json({ 
      message: 'Auto pay setting updated',
      paymentId,
      isActive
    });
  });

  // Serve screenshot capture tool
  app.get("/screenshot-capture", (_req, res) => {
    res.sendFile(path.resolve("screenshot-capture.html"));
  });

  // Alternative route for screenshots
  app.get("/screenshots", (_req, res) => {
    res.sendFile(path.resolve("public/screenshot-capture.html"));
  });

  // Simple screenshot generator
  app.get("/screenshots-simple", (_req, res) => {
    res.sendFile(path.resolve("screenshot-simple.html"));
  });

  // Rewards Program routes
  app.get("/api/rewards", async (req: any, res) => {
    try {
      console.log("=== REWARDS: GET /api/rewards ===");
      console.log("Session data:", req.session);
      
      if (!req.session.userId || !req.session.user) {
        return res.status(401).json({ message: "Authentication required" });
      }

      // Get user from session
      let user = req.session.user;
      
      // If still no user, try to fetch by ID
      if (!user && req.session.userId) {
        user = await storage.getUser(req.session.userId);
        req.session.user = user;
      }

      console.log("Final user:", user?.id, user?.username);
      
      if (!user) {
        console.log("No user found after all attempts, returning 401");
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      const rewards = await storage.getRewardsByUser(user.id);
      console.log("Found rewards count:", rewards.length);
      res.json(rewards);
    } catch (error) {
      console.error("Error fetching rewards:", error);
      res.status(500).json({ message: "Failed to fetch rewards" });
    }
  });

  app.get("/api/rewards/badges", async (req: any, res) => {
    try {
      if (!req.session.userId || !req.session.user) {
        return res.status(401).json({ message: "Authentication required" });
      }

      const badges = await storage.getRewardBadges(req.session.user.id);
      res.json(badges);
    } catch (error) {
      console.error("Error fetching reward badges:", error);
      res.status(500).json({ message: "Failed to fetch reward badges" });
    }
  });

  app.get("/api/rewards/caregiver", async (req: any, res) => {
    try {
      if (!req.session.userId || !req.session.user) {
        return res.status(401).json({ message: "Authentication required" });
      }

      const user = req.session.user;
      if (!user) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      const rewards = await storage.getRewardsByCaregiver(user.id);
      res.json(rewards);
    } catch (error) {
      console.error("Error fetching caregiver rewards:", error);
      res.status(500).json({ message: "Failed to fetch caregiver rewards" });
    }
  });

  app.post("/api/rewards", async (req: any, res) => {
    try {
      console.log("=== REWARDS: POST /api/rewards ===");
      console.log("Session data:", req.session);
      console.log("Request body:", req.body);

      if (!req.session.userId || !req.session.user) {
        console.log("No authenticated user found, returning 401");
        return res.status(401).json({ message: "Authentication required" });
      }

      // Get user from session
      let user = req.session.user;
      
      // If still no user, try to fetch by ID
      if (!user && req.session.userId) {
        user = await storage.getUser(req.session.userId);
        req.session.user = user;
      }

      console.log("Final user:", user?.id, user?.username);
      
      if (!user) {
        console.log("No user found after all attempts, returning 401");
        return res.status(401).json({ message: "Not authenticated" });
      }

      const rewardData = {
        ...req.body,
        userId: req.body.userId || user.id, // Use session user if userId not provided
        caregiverId: user.id // Caregiver creating the reward
      };

      console.log("Creating reward with data:", rewardData);
      const reward = await storage.createReward(rewardData);
      console.log("Created reward:", reward);
      res.json(reward);
    } catch (error) {
      console.error("Error creating reward:", error);
      res.status(500).json({ message: "Failed to create reward", error: error.message });
    }
  });

  app.patch("/api/rewards/:id", async (req: any, res) => {
    try {
      console.log("=== REWARDS: PATCH /api/rewards/:id ===");
      console.log("Session data:", req.session);
      console.log("Request body:", req.body);

      if (!req.session.userId || !req.session.user) {
        return res.status(401).json({ message: "Authentication required" });
      }

      const rewardId = parseInt(req.params.id);
      const updatedReward = await storage.updateReward(rewardId, req.body);
      console.log("Updated reward:", updatedReward);
      res.json(updatedReward);
    } catch (error) {
      console.error("Error updating reward:", error);
      res.status(500).json({ message: "Failed to update reward", error: error.message });
    }
  });

  app.delete("/api/rewards/:id", async (req: any, res) => {
    try {
      console.log("=== REWARDS: DELETE /api/rewards/:id ===");
      console.log("Session data:", req.session);

      if (!req.session.userId || !req.session.user) {
        return res.status(401).json({ message: "Authentication required" });
      }

      const rewardId = parseInt(req.params.id);
      const redemptions = await storage.getRewardRedemptions(req.session.user.id);
      const hasBeenRedeemed = redemptions.some((redemption) => redemption.rewardId === rewardId);

      if (hasBeenRedeemed) {
        return res.status(409).json({
          error: "This reward cannot be deleted because it has already been redeemed.",
          code: "REWARD_ALREADY_REDEEMED",
        });
      }

      await storage.deleteReward(rewardId);
      console.log("Deleted reward:", rewardId);
      res.json({ success: true, message: "Reward deleted successfully" });
    } catch (error) {
      console.error("Error deleting reward:", error);
      res.status(500).json({ message: "Failed to delete reward", error: error.message });
    }
  });

  app.get("/api/points/balance", async (req: any, res) => {
    try {
      if (!req.session.userId || !req.session.user) {
        return res.status(401).json({ message: "Authentication required" });
      }

      const user = req.session.user || storage.getCurrentUser();
      if (!user) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      const balance = await storage.getUserPointsBalance(user.id);
      res.json(balance);
    } catch (error) {
      console.error("Error fetching points balance:", error);
      res.status(500).json({ message: "Failed to fetch points balance" });
    }
  });

  app.get("/api/points/transactions", async (req: any, res) => {
    try {
      if (!req.session.userId || !req.session.user) {
        return res.status(401).json({ message: "Authentication required" });
      }

      const user = req.session.user || storage.getCurrentUser();
      if (!user) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      const transactions = await storage.getPointsTransactions(user.id);
      res.json(transactions);
    } catch (error) {
      console.error("Error fetching points transactions:", error);
      res.status(500).json({ message: "Failed to fetch points transactions" });
    }
  });

  app.post("/api/points/award", async (req: any, res) => {
    try {
      if (!req.session.userId || !req.session.user) {
        return res.status(401).json({ message: "Authentication required" });
      }

      const user = req.session.user || storage.getCurrentUser();
      if (!user) {
        return res.status(401).json({ message: "Not authenticated" });
      }

      const { userId, points, source, description } = req.body;
      const balance = await storage.updateUserPoints(userId, points, source, description, user.id);
      res.json(balance);
    } catch (error) {
      console.error("Error awarding points:", error);
      res.status(500).json({ message: "Failed to award points" });
    }
  });

  app.post("/api/rewards/redeem", async (req: any, res) => {
    try {
      if (!req.session.userId || !req.session.user) {
        return res.status(401).json({ message: "Authentication required" });
      }

      const user = req.session.user || storage.getCurrentUser();
      if (!user) {
        return res.status(401).json({ message: "Not authenticated" });
      }

      const rewardId = Number(req.body?.rewardId);
      if (!Number.isInteger(rewardId) || rewardId <= 0) {
        return res.status(400).json({ message: "A valid reward is required" });
      }

      const redemption = await storage.redeemReward(user.id, rewardId);

      res.json(redemption);
    } catch (error) {
      if (error instanceof RewardRedemptionError) {
        const status =
          error.code === "REWARD_NOT_FOUND" ? 404 : 409;
        return res.status(status).json({ message: error.message });
      }
      console.error("Error redeeming reward:", error);
      res.status(500).json({ message: "Failed to redeem reward" });
    }
  });

  app.get("/api/rewards/redemptions", async (req: any, res) => {
    try {
      if (!req.session.userId || !req.session.user) {
        return res.status(401).json({ message: "Authentication required" });
      }

      const user = req.session.user || storage.getCurrentUser();
      if (!user) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      
      const redemptions = await storage.getRewardRedemptions(user.id);
      res.json(redemptions);
    } catch (error) {
      console.error("Error fetching reward redemptions:", error);
      res.status(500).json({ message: "Failed to fetch reward redemptions" });
    }
  });

  // Personal Documents routes
  app.get("/api/personal-documents", async (req: any, res) => {
    try {
      if (!req.session.userId || !req.session.user) {
        return res.status(401).json({ message: "Authentication required" });
      }
      
      const user = req.session.user;
      const documents = await storage.getPersonalDocuments(user.id);
      res.json(documents);
    } catch (error) {
      console.error("Error fetching personal documents:", error);
      res.status(500).json({ message: "Failed to fetch documents" });
    }
  });

  app.get("/api/personal-documents/category/:category", async (req: any, res) => {
    try {
      if (!req.session.userId || !req.session.user) {
        return res.status(401).json({ message: "Authentication required" });
      }
      
      const user = req.session.user;
      const { category } = req.params;
      const documents = await storage.getPersonalDocumentsByCategory(user.id, category);
      res.json(documents);
    } catch (error) {
      console.error("Error fetching documents by category:", error);
      res.status(500).json({ message: "Failed to fetch documents" });
    }
  });

  app.post("/api/personal-documents", async (req: any, res) => {
    try {
      if (!req.session.userId || !req.session.user) {
        return res.status(401).json({ message: "Authentication required" });
      }
      
      const user = req.session.user;
      const documentData = { ...req.body, userId: user.id };
      const document = await storage.createPersonalDocument(documentData);
      res.json(document);
    } catch (error) {
      console.error("Error creating personal document:", error);
      res.status(500).json({ message: "Failed to create document" });
    }
  });

  app.put("/api/personal-documents/:id", async (req, res) => {
    try {
      const documentId = parseInt(req.params.id);
      const document = await storage.updatePersonalDocument(documentId, req.body);
      res.json(document);
    } catch (error) {
      console.error("Error updating personal document:", error);
      res.status(500).json({ message: "Failed to update document" });
    }
  });

  app.patch("/api/personal-documents/:id", async (req, res) => {
    try {
      const documentId = parseInt(req.params.id);
      const document = await storage.updatePersonalDocument(documentId, req.body);
      res.json(document);
    } catch (error) {
      console.error("Error updating personal document:", error);
      res.status(500).json({ message: "Failed to update document" });
    }
  });

  app.delete("/api/personal-documents/:id", async (req, res) => {
    try {
      const documentId = parseInt(req.params.id);
      await storage.deletePersonalDocument(documentId);
      res.json({ message: "Document deleted successfully" });
    } catch (error) {
      console.error("Error deleting personal document:", error);
      res.status(500).json({ message: "Failed to delete document" });
    }
  });

  // Object storage routes for personal document images
  app.post("/api/personal-documents/upload", async (req: any, res) => {
    try {
      if (!req.session.userId || !req.session.user) {
        return res.status(401).json({ message: "Authentication required" });
      }

      const { ObjectStorageService } = await import('./objectStorage');
      const objectStorageService = new ObjectStorageService();
      // Use public upload URL for personal documents so images can be displayed
      const uploadURL = await objectStorageService.getPublicObjectUploadURL();
      res.json({ uploadURL });
    } catch (error) {
      console.error("Error getting upload URL:", error);
      res.status(500).json({ message: "Failed to get upload URL" });
    }
  });

  // Set public ACL for uploaded personal document images
  app.post("/api/personal-documents/set-public-acl", async (req: any, res) => {
    try {
      if (!req.session.userId || !req.session.user) {
        return res.status(401).json({ message: "Authentication required" });
      }

      const { imageUrl } = req.body;
      if (!imageUrl) {
        return res.status(400).json({ error: "imageUrl is required" });
      }

      const { ObjectStorageService } = await import('./objectStorage');
      const objectStorageService = new ObjectStorageService();
      
      await objectStorageService.setPublicObjectAcl(imageUrl, {
        owner: req.session.user.id.toString(),
        visibility: "public"
      });

      res.json({ success: true });
    } catch (error) {
      console.error("Error setting public ACL:", error);
      res.status(500).json({ error: "Failed to set public ACL" });
    }
  });


  // Route to serve uploaded personal document images
  app.get("/objects/:objectPath(*)", async (req: any, res) => {
    try {
      if (!req.session.userId || !req.session.user) {
        return res.status(401).json({ message: "Authentication required" });
      }

      const { ObjectStorageService, ObjectNotFoundError } = await import('./objectStorage');
      const { ObjectPermission } = await import('./objectAcl');
      const objectStorageService = new ObjectStorageService();
      
      try {
        const objectFile = await objectStorageService.getObjectEntityFile(req.path);
        const canAccess = await objectStorageService.canAccessObjectEntity({
          objectFile,
          userId: req.session.user.id.toString(),
          requestedPermission: ObjectPermission.READ,
        });
        
        if (!canAccess) {
          return res.sendStatus(401);
        }
        
        objectStorageService.downloadObject(objectFile, res);
      } catch (error) {
        console.error("Error checking object access:", error);
        if (error instanceof ObjectNotFoundError) {
          return res.sendStatus(404);
        }
        return res.sendStatus(500);
      }
    } catch (error) {
      console.error("Error in objects route:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  // Mount banking routes
  app.use("/api/banking", bankingRoutes);
  
  // Register analytics routes
  registerAnalyticsRoutes(app);
  
  // Register bill payment routes
  registerBillPaymentRoutes(app);

  // Super Admin - Get all subscription users (restricted to super admin only)
  app.get("/api/super-admin/subscription-users", async (req: any, res) => {
    try {
      // Check if user is authenticated
      if (!req.session?.user) {
        return res.status(401).json({ message: "Not authenticated" });
      }

      // Check if user is super admin (username === 'admin')
      const currentUser = req.session.user;
      if (currentUser.username !== 'admin') {
        return res.status(403).json({ message: "Access denied. Super admin only." });
      }

      // Get all users from storage
      const allUsers = await storage.getAllUsers();

      // Filter to only return subscription-relevant data (excluding password)
      const subscriptionUsers = allUsers.map(user => ({
        id: user.id,
        username: user.username,
        name: user.name,
        email: user.email,
        accountType: user.accountType,
        subscriptionTier: user.subscriptionTier || 'free',
        subscriptionStatus: user.subscriptionStatus || 'inactive',
        subscriptionExpiresAt: user.subscriptionExpiresAt,
        stripeCustomerId: user.stripeCustomerId,
        stripeSubscriptionId: user.stripeSubscriptionId,
        streakDays: user.streakDays,
        isActive: user.isActive,
        createdAt: user.createdAt
      }));

      res.json(subscriptionUsers);
    } catch (error) {
      console.error("Error fetching subscription users:", error);
      res.status(500).json({ message: "Failed to fetch subscription users" });
    }
  });

  // Super Admin: Soft-delete a user (disables the account but keeps all data)
  app.post("/api/super-admin/users/:id/soft-delete", async (req: any, res) => {
    try {
      if (!req.session?.user) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      const currentUser = req.session.user;
      if (currentUser.username !== 'admin') {
        return res.status(403).json({ message: "Access denied. Super admin only." });
      }

      const targetId = parseInt(req.params.id, 10);
      if (Number.isNaN(targetId)) {
        return res.status(400).json({ message: "Invalid user id" });
      }
      if (targetId === currentUser.id) {
        return res.status(400).json({ message: "You cannot delete your own admin account." });
      }

      const target = await storage.getUserById(targetId);
      if (!target) {
        return res.status(404).json({ message: "User not found" });
      }
      if (target.username === 'admin' || target.accountType === 'admin') {
        return res.status(400).json({ message: "Cannot delete an admin account." });
      }

      await storage.updateUser(targetId, {
        isActive: false,
        subscriptionStatus: 'cancelled',
      } as any);

      console.log(`🟠 Super admin ${currentUser.username} soft-deleted user ${target.username} (id=${targetId})`);
      res.json({
        success: true,
        type: 'soft',
        userId: targetId,
        message: `User '${target.username}' has been disabled. Their data is retained and the account can be restored.`
      });
    } catch (error: any) {
      console.error("Error soft-deleting user:", error);
      res.status(500).json({ message: error?.message || "Failed to soft-delete user" });
    }
  });

  // Super Admin: Hard-delete a user (PERMANENT — removes user record and all related data)
  app.delete("/api/super-admin/users/:id", async (req: any, res) => {
    try {
      if (!req.session?.user) {
        return res.status(401).json({ message: "Not authenticated" });
      }
      const currentUser = req.session.user;
      if (currentUser.username !== 'admin') {
        return res.status(403).json({ message: "Access denied. Super admin only." });
      }

      const targetId = parseInt(req.params.id, 10);
      if (Number.isNaN(targetId)) {
        return res.status(400).json({ message: "Invalid user id" });
      }
      if (targetId === currentUser.id) {
        return res.status(400).json({ message: "You cannot delete your own admin account." });
      }

      const target = await storage.getUserById(targetId);
      if (!target) {
        return res.status(404).json({ message: "User not found" });
      }
      if (target.username === 'admin' || target.accountType === 'admin') {
        return res.status(400).json({ message: "Cannot delete an admin account." });
      }

      // Require an explicit confirmation phrase in the request body to avoid accidents.
      const confirmation = (req.body?.confirm || '').toString();
      if (confirmation !== 'DELETE') {
        return res.status(400).json({
          message: "Confirmation required. Pass { confirm: 'DELETE' } in the request body."
        });
      }

      await storage.deleteUserAccount(targetId);

      console.log(`🔴 Super admin ${currentUser.username} PERMANENTLY DELETED user ${target.username} (id=${targetId})`);
      res.json({
        success: true,
        type: 'hard',
        userId: targetId,
        message: `User '${target.username}' and all related data have been permanently deleted.`
      });
    } catch (error: any) {
      console.error("Error hard-deleting user:", error);
      res.status(500).json({ message: error?.message || "Failed to permanently delete user" });
    }
  });

  // ==================== ORGANIZATION CODE MANAGEMENT ====================

  // Admin: Get all org codes with member counts
  app.get("/api/admin/org-codes", async (req: any, res) => {
    try {
      if (!req.session?.user) return res.status(401).json({ message: "Authentication required" });
      const user = req.session.user;
      if (user.accountType !== 'admin' && user.username !== 'admin') {
        return res.status(403).json({ message: "Admin access required" });
      }

      const codes = await storage.getAllOrgCodes();
      const codesWithCounts = await Promise.all(codes.map(async (code) => {
        const count = await storage.countActiveMembersByCode(code.id);
        const members = await storage.getOrgMembershipsByCode(code.id);
        return { ...code, activeMembers: count, totalMembers: members.length };
      }));

      res.json(codesWithCounts);
    } catch (error: any) {
      console.error("Error fetching org codes:", error);
      res.status(500).json({ message: "Failed to fetch organization codes" });
    }
  });

  // Admin: Get org code details with members
  app.get("/api/admin/org-codes/:id", async (req: any, res) => {
    try {
      if (!req.session?.user) return res.status(401).json({ message: "Authentication required" });
      const user = req.session.user;
      if (user.accountType !== 'admin' && user.username !== 'admin') {
        return res.status(403).json({ message: "Admin access required" });
      }

      const code = await storage.getOrgCodeById(parseInt(req.params.id));
      if (!code) return res.status(404).json({ message: "Organization code not found" });

      const memberships = await storage.getOrgMembershipsByCode(code.id);
      const allUsers = await storage.getAllUsers();
      const membersWithDetails = memberships.map(m => {
        const memberUser = allUsers.find(u => u.id === m.userId);
        return {
          ...m,
          userName: memberUser?.name || 'Unknown',
          userEmail: memberUser?.email || '',
          userUsername: memberUser?.username || ''
        };
      });

      res.json({ ...code, members: membersWithDetails });
    } catch (error: any) {
      console.error("Error fetching org code details:", error);
      res.status(500).json({ message: "Failed to fetch organization code details" });
    }
  });

  // Admin: Create org code
  app.post("/api/admin/org-codes", async (req: any, res) => {
    try {
      if (!req.session?.user) return res.status(401).json({ message: "Authentication required" });
      const user = req.session.user;
      if (user.accountType !== 'admin' && user.username !== 'admin') {
        return res.status(403).json({ message: "Admin access required" });
      }

      const { orgName, code, maxUsers, expiresAt } = req.body;
      if (!orgName || !code) {
        return res.status(400).json({ message: "Organization name and code are required" });
      }

      const existing = await storage.getOrgCodeByCode(code);
      if (existing) {
        return res.status(400).json({ message: "This code is already in use" });
      }

      const newCode = await storage.createOrgCode({
        orgName,
        code: code.toUpperCase(),
        maxUsers: maxUsers || null,
        createdBy: user.id,
        isActive: true,
        expiresAt: expiresAt ? new Date(expiresAt) : null
      });

      res.json(newCode);
    } catch (error: any) {
      console.error("Error creating org code:", error);
      res.status(500).json({ message: "Failed to create organization code" });
    }
  });

  // Admin: Update org code (activate/deactivate)
  app.patch("/api/admin/org-codes/:id", async (req: any, res) => {
    try {
      if (!req.session?.user) return res.status(401).json({ message: "Authentication required" });
      const user = req.session.user;
      if (user.accountType !== 'admin' && user.username !== 'admin') {
        return res.status(403).json({ message: "Admin access required" });
      }

      const updated = await storage.updateOrgCode(parseInt(req.params.id), req.body);
      if (!updated) return res.status(404).json({ message: "Organization code not found" });

      res.json(updated);
    } catch (error: any) {
      console.error("Error updating org code:", error);
      res.status(500).json({ message: "Failed to update organization code" });
    }
  });

  // Admin: Delete org code
  app.delete("/api/admin/org-codes/:id", async (req: any, res) => {
    try {
      if (!req.session?.user) return res.status(401).json({ message: "Authentication required" });
      const user = req.session.user;
      if (user.accountType !== 'admin' && user.username !== 'admin') {
        return res.status(403).json({ message: "Admin access required" });
      }

      await storage.deleteOrgCode(parseInt(req.params.id));
      res.json({ message: "Organization code deleted" });
    } catch (error: any) {
      console.error("Error deleting org code:", error);
      res.status(500).json({ message: "Failed to delete organization code" });
    }
  });

  // Admin: Revoke a user's org membership
  app.post("/api/admin/org-memberships/:id/revoke", async (req: any, res) => {
    try {
      if (!req.session?.user) return res.status(401).json({ message: "Authentication required" });
      const user = req.session.user;
      if (user.accountType !== 'admin' && user.username !== 'admin') {
        return res.status(403).json({ message: "Admin access required" });
      }

      const membership = await storage.revokeOrgMembership(parseInt(req.params.id), user.id);
      if (!membership) return res.status(404).json({ message: "Membership not found" });

      res.json({ message: "Access revoked. User will need a paid subscription to continue.", membership });
    } catch (error: any) {
      console.error("Error revoking membership:", error);
      res.status(500).json({ message: "Failed to revoke membership" });
    }
  });

  // User: Redeem an organization code
  app.post("/api/org-codes/redeem", async (req: any, res) => {
    try {
      if (!req.session?.user) return res.status(401).json({ message: "Authentication required" });
      const userId = req.session.user.id;
      const { code } = req.body;

      if (!code) return res.status(400).json({ message: "Organization code is required" });

      const orgCode = await storage.getOrgCodeByCode(code.toUpperCase());
      if (!orgCode) return res.status(404).json({ message: "Invalid organization code" });
      if (!orgCode.isActive) return res.status(400).json({ message: "This organization code is no longer active" });
      if (orgCode.expiresAt && new Date(orgCode.expiresAt) < new Date()) {
        return res.status(400).json({ message: "This organization code has expired" });
      }

      const existingMembership = await storage.getActiveOrgMembershipByUser(userId);
      if (existingMembership) {
        return res.status(400).json({ message: "You already have an active organization membership" });
      }

      const priorMembership = await storage.getOrgMembershipByUserAndCode(userId, orgCode.id);
      if (priorMembership && priorMembership.status === 'revoked') {
        return res.status(400).json({ message: "Your access through this organization has been revoked. Please contact the organization or administrator." });
      }

      if (orgCode.maxUsers) {
        const currentCount = await storage.countActiveMembersByCode(orgCode.id);
        if (currentCount >= orgCode.maxUsers) {
          return res.status(400).json({ message: "This organization code has reached its maximum number of users" });
        }
      }

      const membership = await storage.createOrgMembership({
        userId,
        orgCodeId: orgCode.id,
        status: 'active'
      });

      res.json({ message: "Organization code redeemed! You now have free access.", membership, orgName: orgCode.orgName });
    } catch (error: any) {
      console.error("Error redeeming org code:", error);
      res.status(500).json({ message: "Failed to redeem organization code" });
    }
  });

  // User: Get their current org membership
  app.get("/api/org-codes/my", async (req: any, res) => {
    try {
      if (!req.session?.user) return res.status(401).json({ message: "Authentication required" });
      const userId = req.session.user.id;

      const membership = await storage.getActiveOrgMembershipByUser(userId);
      if (!membership) return res.json(null);

      const orgCode = await storage.getOrgCodeById(membership.orgCodeId);
      res.json({ ...membership, orgName: orgCode?.orgName || 'Unknown Organization' });
    } catch (error: any) {
      console.error("Error fetching user org membership:", error);
      res.status(500).json({ message: "Failed to fetch organization membership" });
    }
  });

  // ── Adaptalyfe Guide — Daily Guide AI endpoint (Phase 1, Step 11) ─────────────
  // READ-ONLY. No writes to any data source. No AI tool/function calling.
  // userId is sourced exclusively from req.session.userId — never from the request body.
  // The full security boundary (whitelist, user-isolation, sensitive-field exclusion)
  // is enforced inside buildDailyGuideContext() (server/ai-context.ts).
  // generateDailyGuide() never throws — returns a safe fallback on any provider error.
  app.post(
    "/api/ai/daily-guide",
    requireAuth,
    async (req: any, res) => {
      try {
        console.log("[daily-guide] Request received");

        // Identity from the authenticated server-side session only.
        // Any userId present in the request body is intentionally not read here.
        const userId: number = req.session.userId;
        const sessionUser = { name: (req.session.user?.name as string) ?? "" };

        // Accept client's local date/time so the AI generates the right time-of-day tone.
        // These are display-only values — never used for auth or data access.
        const clientTime: { localDate?: string; localTime?: string; timezone?: string } = {
          localDate: typeof req.body?.localDate === "string" ? req.body.localDate : undefined,
          localTime: typeof req.body?.localTime === "string" ? req.body.localTime : undefined,
          timezone:  typeof req.body?.timezone  === "string" ? req.body.timezone  : undefined,
        };

        // Context assembly: whitelisted, user-scoped, read-only.
        const context = await buildDailyGuideContext(userId, sessionUser, clientTime);

        // AI call: validated response via Zod schema; safe fallback on any failure.
        const guide = await generateDailyGuide(context);

        console.log("[daily-guide] Generated successfully");
        return res.json(guide);
      } catch (err) {
        // Defensive outer catch — generateDailyGuide() handles its own errors,
        // so this path should not normally be reached. Log operational info only.
        console.error("[daily-guide] Unexpected route error");
        return res.status(500).json({
          greeting: "Hello",
          summary: "Your Daily Guide is temporarily unavailable.",
          highlights: [],
        });
      }
    }
  );

  const httpServer = createServer(app);
  return httpServer;
}
