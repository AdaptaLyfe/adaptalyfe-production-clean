# Subscription-only update for Adaptalyfe Flutter

**ZIP created:** 2026-10-05 04:36:14 IST  
**Compared with:** `adaptalyfe-flutter-main_1791101615561.zip`  
**Scope:** Flutter subscription purchase/restore only; no backend, Home, Settings, or other app features are included.

## Apply the files

1. Commit or back up your working Git project first.
2. Extract this ZIP into the Flutter project root—the directory containing `pubspec.yaml`. The included `lib/`, `android/`, and `test/` paths are relative to that root.
3. Copy the included paths over the matching paths in your project. The subscription feature files, Android manifest entry, tests, and Play setup guide are provided as overlay files.
4. Apply the two small wiring patches from that same project root:

   ```bash
   git apply PATCH_SNIPPETS/routes.subscription.patch
   git apply PATCH_SNIPPETS/pubspec.android-billing.patch
   ```

   The route patch removes the old `StripePaymentService` argument from the subscription BLoC wiring. The dependency patch only enables `in_app_purchase_android: ^0.5.3`; it does not replace your `pubspec.yaml`, remove `flutter_stripe`, or change your SDK constraints. Your uploaded project already has `in_app_purchase: ^3.3.1`.

5. Keep your existing Android upload keystore and `android/key.properties`; neither is included in this ZIP. Do not put service-account JSON or other backend credentials in the Flutter project.
6. Resolve dependencies and run the focused checks:

   ```bash
   flutter pub get
   flutter test test/features/subscription
   flutter analyze
   ```

## Products and server verification

The app maps the three existing monthly Google Play subscription IDs:

| Plan | Product ID |
| --- | --- |
| Basic | `adaptalyfe_basic_monthly` |
| Premium | `adaptalyfe_premium_monthly` |
| Family | `adaptalyfe_family_monthly` |

Do not recreate these products. Confirm each has an active monthly auto-renewing base plan in Play Console. The app queries localized store products, passes the eligible offer token, and starts the matching plan's purchase from its button.

The existing backend remains authoritative. The client uses authenticated `POST /api/google-play/verify-purchase`. Only after successful verification does it complete the store transaction and grant the verified entitlement. If the verification response omits the subscription object, the client falls back to `GET /api/subscription` to read the server's persisted entitlement. No server files are included or changed.

For full Play Console, tester, Android Publisher service-account, RTDN, and end-to-end setup steps, see `GOOGLE_PLAY_SUBSCRIPTIONS_SETUP.md` in this ZIP.

## Files included

- `lib/features/subscription/` — updated subscription UI, state, store adapter, API client/repository, and models.
- `android/app/src/main/AndroidManifest.xml` — Play Billing permission.
- `PATCH_SNIPPETS/` — minimal route and dependency edits, so unrelated routes and dependencies stay intact.
- `test/features/subscription/` — focused tests for the catalog, entitlement rules, and pending purchases.
- `GOOGLE_PLAY_SUBSCRIPTIONS_SETUP.md` — Play Console and backend setup guide.

This is a patch bundle, not a complete app ZIP. It intentionally excludes generated build files, credentials/signing files, and unrelated Flutter files. Flutter tests/builds were not run in the packaging workspace because the Flutter SDK is unavailable there.
