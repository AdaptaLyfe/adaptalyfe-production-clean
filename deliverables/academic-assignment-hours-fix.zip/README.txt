Adaptalyfe estimated-hours fix

Flutter sends estimatedHours as a numeric double and validates whole or fractional values. The Dart model and focused test are included.

The create/update 500 errors are returned after API validation, during database storage. The included migration converts an older integer assignments.estimated_hours column to PostgreSQL REAL while preserving existing values. Apply it once to the Railway service database used by the Flutter API (the DATABASE_URL configured in that Railway service). Do not run it against a different Replit-managed database.

Validation: backend assignment input tests pass. The Flutter SDK is not installed in the Replit workspace, so the Flutter test could not be run here.
