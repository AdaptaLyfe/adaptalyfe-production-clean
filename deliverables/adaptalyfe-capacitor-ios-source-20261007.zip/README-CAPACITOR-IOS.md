# Adaptalyfe Capacitor iOS source

This archive contains the Capacitor iOS native project, the current web app source/assets, and the build configuration needed to sync them. It is source code, not a signed IPA or App Store upload.

## Build on macOS

Requirements: Node.js 20+, Xcode 15+, CocoaPods, and an Apple Developer account for device distribution.

From the archive root:

1. `npm ci`
2. `npx vite build`
3. `npx cap sync ios`
4. `cd ios/App && pod install`
5. Open `ios/App/App.xcworkspace` in Xcode, select the App target, and configure your Apple signing team.

The Capacitor config points to `https://app.getadaptalyfeapp.com`; the app requires an internet connection to load the hosted service. Signing certificates, provisioning profiles, environment files, and credentials are intentionally not included.
