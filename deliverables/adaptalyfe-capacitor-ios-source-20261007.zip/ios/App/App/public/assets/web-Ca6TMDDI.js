import{bf as n}from"./index-DcuLdmOJ.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};
