const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-Ca6TMDDI.js","assets/index-DcuLdmOJ.js","assets/index-CsKnprw0.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-DcuLdmOJ.js";const n=r("SplashScreen",{web:()=>t(()=>import("./web-Ca6TMDDI.js"),__vite__mapDeps([0,1,2])).then(e=>new e.SplashScreenWeb)});export{n as SplashScreen};
