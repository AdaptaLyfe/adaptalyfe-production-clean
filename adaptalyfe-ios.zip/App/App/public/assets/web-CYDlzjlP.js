import{W as n}from"./index-TSD3Pk0K.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};
