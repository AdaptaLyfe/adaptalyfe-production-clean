import{W as n}from"./index-DR3BBcNi.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};
