Emergency Resource database migration

Cause
The API's emergency-resource storage guard returns HTTP 409 when a request contains website, availabilityHours, or isEmergencyOnly=true but the connected database is missing one or more corresponding columns.

Target
Apply this only to the Railway staging service database used by https://staging.getadaptalyfeapp.com. Use that Railway service's DATABASE_URL. Do not use the Replit development database or NEON_DATABASE_URL.

Apply
From the Railway service environment, with its DATABASE_URL set:
  psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -f migrations/0003_emergency_resource_optional_columns.sql

Verify
Run this against the same DATABASE_URL:
  psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -c "SELECT column_name, data_type, column_default FROM information_schema.columns WHERE table_schema = 'public' AND table_name = 'emergency_resources' AND column_name IN ('website', 'availability_hours', 'is_emergency_only') ORDER BY column_name;"

Expected columns:
  availability_hours | character varying
  is_emergency_only | boolean | false
  website | text

The migration uses ADD COLUMN IF NOT EXISTS, does not drop or rewrite existing data, and can be rerun safely. Restart/redeploy the API only if the Railway platform requires it; the current API detects the columns at request time.
