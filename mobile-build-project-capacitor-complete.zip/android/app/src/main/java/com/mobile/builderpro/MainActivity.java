package com.mobile.builderpro;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}