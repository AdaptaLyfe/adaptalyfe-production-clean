package com.capacitorjs.plugins.splashscreen;

public interface SplashListener {
    void completed();
    void error();
}
