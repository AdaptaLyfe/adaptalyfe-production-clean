# Capacitor Core JS

See the [Capacitor website](https://capacitorjs.com) for more information.
