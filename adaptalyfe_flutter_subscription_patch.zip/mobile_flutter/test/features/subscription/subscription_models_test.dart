import 'package:flutter_test/flutter_test.dart';

import 'package:adaptalyfe_mobile/features/subscription/bloc/subscription_state.dart';
import 'package:adaptalyfe_mobile/features/subscription/models/subscription_models.dart';

void main() {
  group('subscription product and entitlement models', () {
    test('centralizes the existing monthly product IDs per platform', () {
      expect(
        subscriptionPlans.map((plan) => plan.productId).toList(),
        [
          'adaptalyfe_basic_monthly',
          'adaptalyfe_premium_monthly',
          'adaptalyfe_family_monthly',
        ],
      );
      expect(SubscriptionProducts.android, SubscriptionProducts.ios);
      expect(
        SubscriptionProducts.forPlatform('android'),
        SubscriptionProducts.android,
      );
      expect(
        SubscriptionProducts.forPlatform('ios'),
        SubscriptionProducts.ios,
      );
      expect(SubscriptionProducts.forPlatform('web'), isEmpty);
      expect(
        subscriptionPlans.any(
          (plan) => plan.features.any(
            (feature) => feature.contains('free trial'),
          ),
        ),
        isFalse,
      );
    });

    test('reads server trial status and remaining days without local guessing',
        () {
      final subscription = SubscriptionModel.fromJson({
        'id': 5,
        'planType': 'free',
        'status': 'trialing',
        'billingCycle': 'monthly',
        'subscriptionPlatform': 'web',
        'trialDaysLeft': 1,
      });

      expect(subscription.isTrialing, isTrue);
      expect(subscription.trialDaysLeft, 1);
      expect(subscription.isActive, isFalse);
      expect(subscription.platformLabel, 'the Adaptalyfe website');
    });

    test('recognizes an active store subscription and restore response', () {
      final subscription = SubscriptionModel.fromJson({
        'id': 9,
        'planType': 'premium',
        'status': 'active',
        'billingCycle': 'monthly',
        'subscriptionPlatform': 'google_play',
      });
      final restored = PurchaseVerification.fromJson({
        'restored': true,
        'planType': 'premium',
        'expiresAt': '2027-01-15T12:00:00.000Z',
      });

      expect(subscription.isActive, isTrue);
      expect(subscription.platformLabel, 'Google Play');
      expect(restored.success, isTrue);
      expect(restored.planType, 'premium');
    });

    test('active Basic access follows wrapper status while features stay gated',
        () {
      final subscription = SubscriptionModel.fromJson({
        'id': 10,
        'planType': 'basic',
        'status': 'active',
        'billingCycle': 'monthly',
        'subscriptionPlatform': 'google_play',
        'features': {'mealPlanning': false},
      });

      expect(subscription.grantsAccess, isTrue);
      expect(subscription.hasPlanEntitlement, isTrue);
      expect(subscription.hasPremiumAccess, isTrue);
      expect(subscription.hasFeatureAccess('mealPlanning'), isFalse);
    });

    test('valid Basic trial grants generic access but respects feature flags',
        () {
      final subscription = SubscriptionModel.fromJson({
        'id': 10,
        'planType': 'basic',
        'status': 'trialing',
        'billingCycle': 'monthly',
        'trialDaysLeft': 4,
        'features': {
          'wearableDevices': true,
          'mealPlanning': false,
        },
      });

      expect(subscription.grantsAccess, isTrue);
      expect(subscription.hasPlanEntitlement, isTrue);
      expect(subscription.hasPremiumAccess, isTrue);
      expect(subscription.hasFeatureAccess('mealPlanning'), isFalse);
    });

    test('free account trial allows plan purchase and uses server feature flags',
        () {
      final subscription = SubscriptionModel.fromJson({
        'id': 12,
        'planType': 'free',
        'status': 'trialing',
        'billingCycle': 'monthly',
        'trialDaysLeft': 4,
        'features': {
          'taskManagement': true,
          'wearableDevices': true,
          'mealPlanning': true,
          'advancedAnalytics': true,
        },
      });
      final state = SubscriptionState(
        status: SubscriptionStatus.ready,
        accountStatusLoaded: true,
        subscription: subscription,
        storeAvailable: true,
      );

      expect(subscription.grantsAccess, isTrue);
      expect(subscription.hasPlanEntitlement, isFalse);
      expect(subscription.hasPremiumAccess, isTrue);
      expect(state.hasActiveSubscription, isFalse);
      expect(state.canPurchase, isTrue);
    });

    test('expired free trial does not retain stale server feature access', () {
      final subscription = SubscriptionModel.fromJson({
        'id': 13,
        'planType': 'free',
        'status': 'expired',
        'billingCycle': 'monthly',
        'features': {'wearableDevices': true},
      });

      expect(subscription.grantsAccess, isFalse);
      expect(subscription.hasPlanEntitlement, isFalse);
      expect(subscription.hasPremiumAccess, isFalse);
      expect(subscription.hasApplicationAccess, isFalse);
    });

    test('active organization membership grants app and feature access', () {
      const expiredPlan = SubscriptionModel(
        id: 14,
        planType: 'free',
        status: 'expired',
        billingCycle: 'monthly',
        features: {'mealPlanning': false},
      );
      final organizationMember = expiredPlan.withOrganizationAccess(true);

      expect(organizationMember.hasApplicationAccess, isTrue);
      expect(organizationMember.hasFeatureAccess('mealPlanning'), isTrue);
    });

    test('Premium and Family trials include Premium features', () {
      for (final tier in ['premium', 'family']) {
        final subscription = SubscriptionModel.fromJson({
          'id': 11,
          'planType': tier,
          'status': 'trialing',
          'billingCycle': 'monthly',
          'trialDaysLeft': 4,
        });

        expect(subscription.hasPremiumAccess, isTrue, reason: tier);
      }
    });

    test('Premium and Family plans include Premium features only while active',
        () {
      for (final tier in ['premium', 'family']) {
        final active = SubscriptionModel.fromJson({
          'id': 11,
          'planType': tier,
          'status': 'active',
          'billingCycle': 'monthly',
        });
        final expired = SubscriptionModel.fromJson({
          'id': 12,
          'planType': tier,
          'status': 'expired',
          'billingCycle': 'monthly',
        });

        expect(active.hasPremiumAccess, isTrue, reason: tier);
        expect(expired.hasPremiumAccess, isFalse, reason: tier);
      }
    });
  });
}