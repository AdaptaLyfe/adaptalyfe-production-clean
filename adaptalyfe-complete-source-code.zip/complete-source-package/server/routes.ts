import type { Express } from "express";
import { createServer, type Server } from "http";
import path from "path";
import { storage } from "./storage";
import OpenAI from "openai";
import Stripe from "stripe";
import bankingRoutes from "./banking-routes";

// Initialize Stripe with dynamic key support
function getStripeInstance() {
  if (!process.env.STRIPE_SECRET_KEY) {
    console.warn('STRIPE_SECRET_KEY not found, using demo mode');
    return null;
  }
  
  console.log('Using Stripe key prefix:', process.env.STRIPE_SECRET_KEY.substring(0, 10) + '...');
  
  return new Stripe(process.env.STRIPE_SECRET_KEY, {
    apiVersion: "2025-05-28.basil",
  });
}

// Stripe instance is created dynamically when needed
import { 
  insertDailyTaskSchema, insertBillSchema, insertMoodEntrySchema, 
  insertAchievementSchema, insertCaregiverSchema, insertMessageSchema,
  insertBudgetEntrySchema, insertAppointmentSchema, insertMealPlanSchema,
  insertShoppingListSchema, loginSchema, registerSchema, insertUserPharmacySchema,
  insertMedicationSchema, insertRefillOrderSchema, insertPersonalResourceSchema,
  insertBusScheduleSchema, insertEmergencyTreatmentPlanSchema,
  insertNotificationSchema, insertUserPreferencesSchema, insertUserAchievementSchema,
  insertStreakTrackingSchema, insertVoiceInteractionSchema, insertQuickResponseSchema,
  insertMessageReactionSchema, insertActivityPatternSchema
} from "@shared/schema";

// Initialize OpenAI
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

// Fallback responses when OpenAI is unavailable
function getFallbackResponse(message: string): string {
  const lowerMessage = message.toLowerCase();
  
  if (lowerMessage.includes('help') || lowerMessage.includes('how')) {
    return "I'd love to help you! Here are some things I can guide you with:\n\n• Daily task planning and organization\n• Managing your schedule and appointments\n• Setting up medication reminders\n• Building independence skills\n• Connecting with your support team\n\nWhat specific area would you like assistance with?";
  }
  
  if (lowerMessage.includes('sad') || lowerMessage.includes('down') || lowerMessage.includes('upset')) {
    return "I understand you're feeling down, and that's completely okay. Remember that difficult feelings are temporary. Here are some things that might help:\n\n• Take deep breaths or try the breathing exercise in Resources\n• Talk to someone you trust\n• Do something small that makes you feel accomplished\n• Remember your recent successes\n\nYour support team is here for you. Consider reaching out to a caregiver if you need extra support today.";
  }
  
  if (lowerMessage.includes('task') || lowerMessage.includes('todo') || lowerMessage.includes('routine')) {
    return "Great question about managing tasks! Here's how to build a good routine:\n\n• Start with 2-3 easy tasks each day\n• Break big tasks into smaller steps\n• Celebrate when you complete things\n• Use the Daily Tasks section to track progress\n• Set reminders for important activities\n\nWould you like help setting up specific tasks or building a daily routine?";
  }
  
  if (lowerMessage.includes('money') || lowerMessage.includes('budget') || lowerMessage.includes('bill')) {
    return "Managing money is an important independence skill! Here are some tips:\n\n• Track your income and expenses in the Financial section\n• Set up reminders for bill due dates\n• Start with a simple budget for essentials\n• Ask for help from trusted people when needed\n• Celebrate small financial wins\n\nThe Financial Management tools can help you stay organized with bills and budgeting.";
  }
  
  if (lowerMessage.includes('medication') || lowerMessage.includes('medicine') || lowerMessage.includes('pill')) {
    return "Medication management is very important for your health. Here's what helps:\n\n• Use the Pharmacy section to track medications\n• Set up reminders for taking medicine\n• Keep a list of all your medications\n• Never skip doses without talking to your doctor\n• Ask questions if you're unsure about anything\n\nThe medication tracking tools can help you stay organized and safe.";
  }
  
  // Default encouraging response
  return "Thank you for reaching out! I'm here to support you on your independence journey. While I'm having some technical difficulties right now, I want you to know that:\n\n• You're doing great by using AdaptaLyfe\n• Every small step forward matters\n• Your support team believes in you\n• It's okay to ask for help when you need it\n\nTry exploring the different sections of the app, and remember that your caregivers are always here to support you too!";
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Middleware to ensure user is logged in for protected routes
  const requireAuth = (req: any, res: any, next: any) => {
    const user = storage.getCurrentUser();
    if (!user) {
      return res.status(401).json({ message: "Authentication required" });
    }
    req.user = user;
    next();
  };

  // User registration endpoint
  app.post("/api/register", async (req, res) => {
    try {
      const { name, email, username, password, plan, subscribeNewsletter } = req.body;
      
      // Check if username already exists
      const existingUser = await storage.getUserByUsername(username);
      if (existingUser) {
        return res.status(400).json({ message: "Username already exists" });
      }

      // Create new user
      const user = await storage.createUser({
        username,
        password, // In production, this would be hashed
        name,
        email
      });

      // Set as current user
      storage.setCurrentUser(user);

      res.json({ 
        message: "Registration successful",
        user: {
          id: user.id,
          username: user.username,
          name: user.name,
          email: user.email
        },
        plan
      });
    } catch (error) {
      console.error("Registration error:", error);
      res.status(500).json({ message: "Registration failed" });
    }
  });

  // User login endpoint
  app.post("/api/login", async (req, res) => {
    try {
      const { username, password } = req.body;
      
      const user = await storage.getUserByUsername(username);
      if (!user || user.password !== password) { // In production, compare hashed passwords
        return res.status(401).json({ message: "Invalid credentials" });
      }

      // Set as current user
      storage.setCurrentUser(user);

      res.json({ 
        message: "Login successful",
        user: { 
          id: user.id,
          username: user.username,
          name: user.name,
          email: user.email
        }
      });
    } catch (error) {
      console.error("Login error:", error);
      res.status(500).json({ message: "Login failed" });
    }
  });

  // Demo login endpoint
  app.post("/api/demo-login", async (req, res) => {
    try {
      const { username, password } = req.body;
      
      const user = await storage.getUserByUsername(username);
      if (!user) {
        return res.status(401).json({ message: "Invalid credentials" });
      }
      
      // Simple password check for demo (in production, use proper hashing)
      if (user.password !== password) {
        return res.status(401).json({ message: "Invalid credentials" });
      }
      
      // Set the current user in storage
      storage.setCurrentUser(user);
      
      res.json({ 
        message: "Login successful", 
        user: { 
          id: user.id, 
          username: user.username, 
          name: user.name, 
          email: user.email 
        } 
      });
    } catch (error) {
      console.error("Demo login error:", error);
      res.status(500).json({ message: "Login failed" });
    }
  });

  // Logout endpoint
  app.post("/api/logout", async (req, res) => {
    try {
      storage.setCurrentUser(null);
      res.json({ message: "Logout successful" });
    } catch (error) {
      console.error("Logout error:", error);
      res.status(500).json({ message: "Logout failed" });
    }
  });

  // Get current user
  app.get("/api/user", async (req, res) => {
    const user = storage.getCurrentUser();
    
    if (!user) {
      return res.status(401).json({ message: "No user logged in" });
    }
    
    // Don't return password in response
    const { password, ...userResponse } = user;
    res.json(userResponse);
  });

  // Authentication routes
  app.post("/api/auth/register", async (req, res) => {
    try {
      const validatedData = registerSchema.parse(req.body);
      
      // Check if username already exists
      const existingUser = await storage.getUserByUsername(validatedData.username);
      if (existingUser) {
        return res.status(400).json({ message: "Username already exists" });
      }

      // Create new user (excluding confirmPassword)
      const { confirmPassword, ...userData } = validatedData;
      const newUser = await storage.createUser(userData);
      
      // Don't return password in response
      const { password, ...userResponse } = newUser;
      res.status(201).json(userResponse);
    } catch (error: any) {
      res.status(400).json({ message: error.message || "Registration failed" });
    }
  });

  app.post("/api/auth/login", async (req, res) => {
    try {
      const { username, password } = loginSchema.parse(req.body);
      
      const user = await storage.authenticateUser(username, password);
      if (!user) {
        return res.status(401).json({ message: "Invalid username or password" });
      }

      // Don't return password in response
      const { password: _, ...userResponse } = user;
      res.json(userResponse);
    } catch (error: any) {
      res.status(400).json({ message: error.message || "Login failed" });
    }
  });



  // Daily Tasks routes
  app.get("/api/daily-tasks", async (req, res) => {
    try {
      const user = storage.getCurrentUser();
      if (!user) {
        return res.status(401).json({ message: "Authentication required" });
      }
      const tasks = await storage.getDailyTasksByUser(user.id);
      res.json(tasks);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch tasks" });
    }
  });

  app.post("/api/daily-tasks", async (req, res) => {
    try {
      const user = storage.getCurrentUser();
      if (!user) {
        return res.status(401).json({ message: "Authentication required" });
      }
      const data = insertDailyTaskSchema.parse({ ...req.body, userId: user.id });
      const task = await storage.createDailyTask(data);
      res.json(task);
    } catch (error) {
      console.error("Failed to create task:", error);
      res.status(400).json({ message: "Invalid task data" });
    }
  });

  app.patch("/api/daily-tasks/:id/complete", async (req, res) => {
    const taskId = parseInt(req.params.id);
    const { isCompleted } = req.body;
    const task = await storage.updateTaskCompletion(taskId, isCompleted);
    if (!task) {
      return res.status(404).json({ message: "Task not found" });
    }
    res.json(task);
  });

  // Bills routes
  app.get("/api/bills", async (req, res) => {
    try {
      const user = storage.getCurrentUser();
      if (!user) {
        return res.status(401).json({ message: "Authentication required" });
      }
      const bills = await storage.getBillsByUser(user.id);
      res.json(bills);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch bills" });
    }
  });

  app.post("/api/bills", async (req, res) => {
    try {
      const user = storage.getCurrentUser();
      if (!user) {
        return res.status(401).json({ message: "Authentication required" });
      }
      const data = insertBillSchema.parse({ ...req.body, userId: user.id });
      const bill = await storage.createBill(data);
      res.json(bill);
    } catch (error) {
      console.error("Failed to create bill:", error);
      res.status(400).json({ message: "Invalid bill data" });
    }
  });

  app.patch("/api/bills/:id/pay", async (req, res) => {
    const billId = parseInt(req.params.id);
    const { isPaid } = req.body;
    const bill = await storage.updateBillPayment(billId, isPaid);
    if (!bill) {
      return res.status(404).json({ message: "Bill not found" });
    }
    res.json(bill);
  });

  // Mood entries routes
  app.get("/api/mood-entries", async (req, res) => {
    try {
      const user = storage.getCurrentUser();
      if (!user) {
        return res.status(401).json({ message: "Authentication required" });
      }
      const entries = await storage.getMoodEntriesByUser(user.id);
      res.json(entries);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch mood entries" });
    }
  });

  app.get("/api/mood-entries/today", async (req, res) => {
    try {
      const user = storage.getCurrentUser();
      if (!user) {
        return res.status(401).json({ message: "Authentication required" });
      }
      const entry = await storage.getTodayMoodEntry(user.id);
      res.json(entry);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch today's mood entry" });
    }
  });

  app.post("/api/mood-entries", async (req, res) => {
    try {
      const user = storage.getCurrentUser();
      if (!user) {
        return res.status(401).json({ message: "Authentication required" });
      }
      const data = insertMoodEntrySchema.parse({ ...req.body, userId: user.id });
      const entry = await storage.createMoodEntry(data);
      res.json(entry);
    } catch (error) {
      res.status(400).json({ message: "Invalid mood entry data" });
    }
  });

  // Achievements routes
  app.get("/api/achievements", async (req, res) => {
    const achievements = await storage.getAchievementsByUser(1);
    res.json(achievements);
  });

  app.post("/api/achievements", async (req, res) => {
    try {
      const data = insertAchievementSchema.parse({ ...req.body, userId: 1 });
      const achievement = await storage.createAchievement(data);
      res.json(achievement);
    } catch (error) {
      res.status(400).json({ message: "Invalid achievement data" });
    }
  });

  // Caregivers routes
  app.get("/api/caregivers", async (req, res) => {
    const caregivers = await storage.getCaregiversByUser(1);
    res.json(caregivers);
  });

  app.post("/api/caregivers", async (req, res) => {
    try {
      const data = insertCaregiverSchema.parse({ ...req.body, userId: 1 });
      const caregiver = await storage.createCaregiver(data);
      res.json(caregiver);
    } catch (error) {
      res.status(400).json({ message: "Invalid caregiver data" });
    }
  });

  // Messages routes
  app.get("/api/messages", async (req, res) => {
    const messages = await storage.getMessagesByUser(1);
    res.json(messages);
  });

  app.post("/api/messages", async (req, res) => {
    try {
      const data = insertMessageSchema.parse({ ...req.body, userId: 1 });
      const message = await storage.createMessage(data);
      res.json(message);
    } catch (error) {
      res.status(400).json({ message: "Invalid message data" });
    }
  });

  // Budget entries routes
  app.get("/api/budget-entries", async (req, res) => {
    try {
      const user = storage.getCurrentUser();
      if (!user) {
        return res.status(401).json({ message: "Authentication required" });
      }
      const entries = await storage.getBudgetEntriesByUser(user.id);
      res.json(entries);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch budget entries" });
    }
  });

  app.post("/api/budget-entries", async (req, res) => {
    try {
      const user = storage.getCurrentUser();
      if (!user) {
        return res.status(401).json({ message: "Authentication required" });
      }
      const data = insertBudgetEntrySchema.parse({ ...req.body, userId: user.id });
      const entry = await storage.createBudgetEntry(data);
      res.json(entry);
    } catch (error) {
      res.status(400).json({ message: "Invalid budget entry data" });
    }
  });

  // Appointments routes
  app.get("/api/appointments", async (req, res) => {
    try {
      const user = storage.getCurrentUser();
      if (!user) {
        return res.status(401).json({ message: "Authentication required" });
      }
      const appointments = await storage.getAppointmentsByUser(user.id);
      res.json(appointments);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch appointments" });
    }
  });

  app.get("/api/appointments/upcoming", async (req, res) => {
    try {
      const user = storage.getCurrentUser();
      if (!user) {
        return res.status(401).json({ message: "Authentication required" });
      }
      const appointments = await storage.getUpcomingAppointments(user.id);
      res.json(appointments);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch upcoming appointments" });
    }
  });

  app.post("/api/appointments", async (req, res) => {
    try {
      const user = storage.getCurrentUser();
      if (!user) {
        return res.status(401).json({ message: "Authentication required" });
      }
      
      const data = insertAppointmentSchema.parse({ ...req.body, userId: user.id });
      const appointment = await storage.createAppointment(data);
      res.json(appointment);
    } catch (error) {
      console.error("Failed to create appointment:", error);
      res.status(400).json({ message: "Invalid appointment data" });
    }
  });

  app.patch("/api/appointments/:id/complete", async (req, res) => {
    try {
      const appointmentId = parseInt(req.params.id);
      const { isCompleted } = req.body;
      const appointment = await storage.updateAppointmentCompletion(appointmentId, isCompleted);
      if (!appointment) {
        return res.status(404).json({ message: "Appointment not found" });
      }
      res.json(appointment);
    } catch (error) {
      res.status(400).json({ message: "Invalid request" });
    }
  });

  // Academic routes
  app.get("/api/assignments", async (req, res) => {
    try {
      const user = storage.getCurrentUser();
      if (!user) {
        return res.status(401).json({ message: "Authentication required" });
      }
      const assignments = await storage.getAssignmentsByUser(user.id);
      res.json(assignments);
    } catch (error) {
      console.error("Error fetching assignments:", error);
      res.status(500).json({ message: "Failed to fetch assignments" });
    }
  });

  app.post("/api/assignments", async (req, res) => {
    try {
      const user = storage.getCurrentUser();
      if (!user) {
        return res.status(401).json({ message: "Authentication required" });
      }
      
      // Convert dueDate string to proper timestamp
      const dueDate = new Date(req.body.dueDate);
      if (isNaN(dueDate.getTime())) {
        throw new Error("Invalid due date provided");
      }
      
      const assignmentData = { 
        ...req.body, 
        userId: user.id,
        dueDate: dueDate
      };
      
      const assignment = await storage.createAssignment(assignmentData);
      
      res.json(assignment);
    } catch (error) {
      console.error("Failed to create assignment:", error);
      res.status(400).json({ message: "Invalid assignment data", error: error instanceof Error ? error.message : "Unknown error" });
    }
  });

  app.get("/api/academic-classes", async (req, res) => {
    try {
      const user = storage.getCurrentUser();
      if (!user) {
        return res.status(401).json({ message: "Authentication required" });
      }
      const classes = await storage.getAcademicClassesByUser(user.id);
      res.json(classes);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch classes" });
    }
  });

  app.post("/api/academic-classes", async (req, res) => {
    try {
      const user = storage.getCurrentUser();
      if (!user) {
        return res.status(401).json({ message: "Authentication required" });
      }
      const classData = { ...req.body, userId: user.id };
      const academicClass = await storage.createAcademicClass(classData);
      res.json(academicClass);
    } catch (error) {
      console.error("Failed to create class:", error);
      res.status(400).json({ message: "Invalid class data" });
    }
  });

  app.get("/api/study-sessions", async (req, res) => {
    try {
      const user = storage.getCurrentUser();
      if (!user) {
        return res.status(401).json({ message: "Authentication required" });
      }
      const studySessions = await storage.getStudySessionsByUser(user.id);
      res.json(studySessions);
    } catch (error) {
      console.error("Error fetching study sessions:", error);
      res.status(500).json({ message: "Failed to fetch study sessions" });
    }
  });

  app.post("/api/study-sessions", async (req, res) => {
    try {
      const user = storage.getCurrentUser();
      if (!user) {
        return res.status(401).json({ message: "Authentication required" });
      }
      const sessionData = { ...req.body, userId: user.id };
      const studySession = await storage.createStudySession(sessionData);
      res.json(studySession);
    } catch (error) {
      console.error("Error creating study session:", error);
      res.status(500).json({ message: "Failed to create study session" });
    }
  });

  app.patch("/api/study-sessions/:id", async (req, res) => {
    try {
      const user = storage.getCurrentUser();
      if (!user) {
        return res.status(401).json({ message: "Authentication required" });
      }
      const sessionId = parseInt(req.params.id);
      const updateData = req.body;
      const studySession = await storage.updateStudySession(sessionId, updateData);
      res.json(studySession);
    } catch (error) {
      console.error("Error updating study session:", error);
      res.status(500).json({ message: "Failed to update study session" });
    }
  });

  app.get("/api/campus-transport", async (req, res) => {
    try {
      const user = storage.getCurrentUser();
      if (!user) {
        return res.status(401).json({ message: "Authentication required" });
      }
      const transport = await storage.getCampusTransportByUser(user.id);
      res.json(transport);
    } catch (error) {
      console.error("Failed to fetch campus transport:", error);
      res.status(500).json({ message: "Failed to fetch campus transport" });
    }
  });

  app.post("/api/campus-transport", async (req, res) => {
    try {
      const user = storage.getCurrentUser();
      if (!user) {
        return res.status(401).json({ message: "Authentication required" });
      }
      
      const transportData = {
        ...req.body,
        userId: user.id
      };
      
      const transport = await storage.createCampusTransport(transportData);
      res.json(transport);
    } catch (error) {
      console.error("Failed to create campus transport:", error);
      res.status(500).json({ message: "Failed to create campus transport" });
    }
  });

  app.get("/api/campus-locations", async (req, res) => {
    try {
      const user = storage.getCurrentUser();
      if (!user) {
        return res.status(401).json({ message: "Authentication required" });
      }
      const locations = await storage.getCampusLocationsByUser(user.id);
      res.json(locations);
    } catch (error) {
      console.error("Failed to fetch campus locations:", error);
      res.status(500).json({ message: "Failed to fetch campus locations" });
    }
  });

  app.post("/api/campus-locations", async (req, res) => {
    try {
      const user = storage.getCurrentUser();
      if (!user) {
        return res.status(401).json({ message: "Authentication required" });
      }
      
      const locationData = {
        ...req.body,
        userId: user.id
      };
      
      const location = await storage.createCampusLocation(locationData);
      res.json(location);
    } catch (error) {
      console.error("Failed to create campus location:", error);
      res.status(500).json({ message: "Failed to create campus location" });
    }
  });

  app.get("/api/study-groups", async (req, res) => {
    try {
      const user = storage.getCurrentUser();
      if (!user) {
        return res.status(401).json({ message: "Authentication required" });
      }
      res.json([]);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch study groups" });
    }
  });

  app.post("/api/study-groups", async (req, res) => {
    try {
      const user = storage.getCurrentUser();
      if (!user) {
        return res.status(401).json({ message: "Authentication required" });
      }
      const studyGroup = { id: Date.now(), ...req.body, userId: user.id };
      res.json(studyGroup);
    } catch (error) {
      res.status(500).json({ message: "Failed to create study group" });
    }
  });

  app.get("/api/transition-skills", async (req, res) => {
    try {
      const user = storage.getCurrentUser();
      if (!user) {
        return res.status(401).json({ message: "Authentication required" });
      }
      const skills = await storage.getTransitionSkillsByUser(user.id);
      res.json(skills);
    } catch (error) {
      console.error("Failed to fetch transition skills:", error);
      res.status(500).json({ message: "Failed to fetch transition skills" });
    }
  });

  app.post("/api/transition-skills", async (req, res) => {
    try {
      const user = storage.getCurrentUser();
      if (!user) {
        return res.status(401).json({ message: "Authentication required" });
      }
      
      const skillData = {
        ...req.body,
        userId: user.id
      };
      
      const skill = await storage.createTransitionSkill(skillData);
      res.json(skill);
    } catch (error) {
      console.error("Failed to create transition skill:", error);
      res.status(500).json({ message: "Failed to create transition skill" });
    }
  });

  // Calendar Events routes
  app.get("/api/calendar-events", async (req, res) => {
    try {
      const user = storage.getCurrentUser();
      if (!user) {
        return res.status(401).json({ message: "Authentication required" });
      }
      const events = await storage.getCalendarEventsByUser(user.id);
      res.json(events);
    } catch (error) {
      console.error("Failed to fetch calendar events:", error);
      res.status(500).json({ message: "Failed to fetch calendar events" });
    }
  });

  app.post("/api/calendar-events", async (req, res) => {
    try {
      const user = storage.getCurrentUser();
      if (!user) {
        return res.status(401).json({ message: "Authentication required" });
      }
      
      // Convert date strings to Date objects
      const eventData = {
        ...req.body,
        userId: user.id,
        startDate: new Date(req.body.startDate),
        endDate: req.body.endDate ? new Date(req.body.endDate) : null
      };
      
      const event = await storage.createCalendarEvent(eventData);
      res.json(event);
    } catch (error) {
      console.error("Failed to create calendar event:", error);
      res.status(500).json({ message: "Failed to create calendar event" });
    }
  });

  app.put("/api/calendar-events/:id", async (req, res) => {
    try {
      const user = storage.getCurrentUser();
      if (!user) {
        return res.status(401).json({ message: "Authentication required" });
      }
      const eventId = parseInt(req.params.id);
      
      // Convert date strings to Date objects if they exist
      const updateData = {
        ...req.body
      };
      if (req.body.startDate) {
        updateData.startDate = new Date(req.body.startDate);
      }
      if (req.body.endDate) {
        updateData.endDate = new Date(req.body.endDate);
      }
      
      const event = await storage.updateCalendarEvent(eventId, updateData);
      res.json(event);
    } catch (error) {
      console.error("Failed to update calendar event:", error);
      res.status(500).json({ message: "Failed to update calendar event" });
    }
  });

  app.delete("/api/calendar-events/:id", async (req, res) => {
    try {
      const user = storage.getCurrentUser();
      if (!user) {
        return res.status(401).json({ message: "Authentication required" });
      }
      const eventId = parseInt(req.params.id);
      const deleted = await storage.deleteCalendarEvent(eventId);
      if (deleted) {
        res.json({ success: true });
      } else {
        res.status(404).json({ message: "Event not found" });
      }
    } catch (error) {
      console.error("Failed to delete calendar event:", error);
      res.status(500).json({ message: "Failed to delete calendar event" });
    }
  });

  // Meal Plans routes
  app.get("/api/meal-plans", async (req, res) => {
    try {
      const user = storage.getCurrentUser();
      if (!user) {
        return res.status(401).json({ message: "Authentication required" });
      }
      const mealPlans = await storage.getMealPlansByUser(user.id);
      res.json(mealPlans);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch meal plans" });
    }
  });

  app.post("/api/meal-plans", async (req, res) => {
    try {
      const user = storage.getCurrentUser();
      if (!user) {
        return res.status(401).json({ message: "Authentication required" });
      }
      const data = insertMealPlanSchema.parse({ ...req.body, userId: user.id });
      const mealPlan = await storage.createMealPlan(data);
      res.json(mealPlan);
    } catch (error) {
      res.status(400).json({ message: "Invalid meal plan data" });
    }
  });

  app.patch("/api/meal-plans/:id/completion", async (req, res) => {
    try {
      const mealPlanId = parseInt(req.params.id);
      const { isCompleted } = req.body;
      const mealPlan = await storage.updateMealPlanCompletion(mealPlanId, isCompleted);
      if (!mealPlan) {
        return res.status(404).json({ message: "Meal plan not found" });
      }
      res.json(mealPlan);
    } catch (error) {
      res.status(400).json({ message: "Invalid request" });
    }
  });

  app.get("/api/meal-plans/date/:date", async (req, res) => {
    try {
      const user = storage.getCurrentUser();
      if (!user) {
        return res.status(401).json({ message: "Authentication required" });
      }
      const date = req.params.date;
      const mealPlans = await storage.getMealPlansByDate(user.id, date);
      res.json(mealPlans);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch meal plans" });
    }
  });

  // Shopping Lists routes
  app.get("/api/shopping-lists", async (req, res) => {
    try {
      const user = storage.getCurrentUser();
      if (!user) {
        return res.status(401).json({ message: "Authentication required" });
      }
      const items = await storage.getShoppingListsByUser(user.id);
      res.json(items);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch shopping lists" });
    }
  });

  app.get("/api/shopping-lists/active", async (req, res) => {
    try {
      const user = storage.getCurrentUser();
      if (!user) {
        return res.status(401).json({ message: "Authentication required" });
      }
      const items = await storage.getActiveShoppingItems(user.id);
      res.json(items);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch active shopping items" });
    }
  });

  app.post("/api/shopping-lists", async (req, res) => {
    try {
      const user = storage.getCurrentUser();
      if (!user) {
        return res.status(401).json({ message: "Authentication required" });
      }
      const data = insertShoppingListSchema.parse({ ...req.body, userId: user.id });
      const item = await storage.createShoppingListItem(data);
      res.json(item);
    } catch (error) {
      console.error("Failed to create shopping list item:", error);
      res.status(400).json({ message: "Invalid shopping list item data" });
    }
  });

  app.patch("/api/shopping-lists/:id/purchased", async (req, res) => {
    try {
      const itemId = parseInt(req.params.id);
      const { isPurchased, actualCost } = req.body;
      const item = await storage.updateShoppingItemPurchased(itemId, isPurchased, actualCost);
      if (!item) {
        return res.status(404).json({ message: "Shopping item not found" });
      }
      res.json(item);
    } catch (error) {
      res.status(400).json({ message: "Invalid request" });
    }
  });

  // Grocery Stores routes
  app.get("/api/grocery-stores", async (req, res) => {
    try {
      const stores = await storage.getGroceryStoresByUser(1);
      res.json(stores);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch grocery stores" });
    }
  });

  app.post("/api/grocery-stores", async (req, res) => {
    try {
      const data = { ...req.body, userId: 1 };
      const store = await storage.createGroceryStore(data);
      res.json(store);
    } catch (error) {
      res.status(400).json({ message: "Invalid grocery store data" });
    }
  });

  app.put("/api/grocery-stores/:id", async (req, res) => {
    try {
      const storeId = parseInt(req.params.id);
      const store = await storage.updateGroceryStore(storeId, req.body);
      if (!store) {
        return res.status(404).json({ message: "Grocery store not found" });
      }
      res.json(store);
    } catch (error) {
      res.status(400).json({ message: "Invalid request" });
    }
  });

  app.delete("/api/grocery-stores/:id", async (req, res) => {
    try {
      const storeId = parseInt(req.params.id);
      const success = await storage.deleteGroceryStore(storeId);
      if (!success) {
        return res.status(404).json({ message: "Grocery store not found" });
      }
      res.json({ message: "Grocery store deleted successfully" });
    } catch (error) {
      res.status(400).json({ message: "Invalid request" });
    }
  });

  // Emergency resources routes
  app.get("/api/emergency-resources", async (req: any, res) => {
    try {
      const userId = req.session?.user?.id || 1;
      const resources = await storage.getEmergencyResourcesByUser(userId);
      res.json(resources);
    } catch (error) {
      console.error("Error fetching emergency resources:", error);
      res.status(500).json({ message: "Failed to fetch emergency resources" });
    }
  });

  app.post("/api/emergency-resources", async (req: any, res) => {
    try {
      const userId = req.session?.user?.id || 1;
      const resourceData = { ...req.body, userId };
      const resource = await storage.createEmergencyResource(resourceData);
      res.status(201).json(resource);
    } catch (error) {
      console.error("Error creating emergency resource:", error);
      res.status(500).json({ message: "Failed to create emergency resource" });
    }
  });

  app.put("/api/emergency-resources/:id", async (req: any, res) => {
    try {
      const resourceId = parseInt(req.params.id);
      const updates = req.body;
      const resource = await storage.updateEmergencyResource(resourceId, updates);
      
      if (!resource) {
        return res.status(404).json({ message: "Emergency resource not found" });
      }
      
      res.json(resource);
    } catch (error) {
      console.error("Error updating emergency resource:", error);
      res.status(500).json({ message: "Failed to update emergency resource" });
    }
  });

  app.delete("/api/emergency-resources/:id", async (req: any, res) => {
    try {
      const resourceId = parseInt(req.params.id);
      const success = await storage.deleteEmergencyResource(resourceId);
      
      if (!success) {
        return res.status(404).json({ message: "Emergency resource not found" });
      }
      
      res.json({ message: "Emergency resource deleted successfully" });
    } catch (error) {
      console.error("Error deleting emergency resource:", error);
      res.status(500).json({ message: "Failed to delete emergency resource" });
    }
  });

  // Caregiver access control endpoint
  app.get("/api/caregiver-access", async (req, res) => {
    try {
      const currentUser = await storage.getCurrentUser();
      if (!currentUser) {
        return res.status(401).json({ message: "User not authenticated" });
      }

      // Check if user has caregiver role
      // For demo purposes, admin users and caregivers have access
      // In production, this would check a caregivers table or user role
      const isCaregiver = currentUser.id === 1 || currentUser.username === "caregiver" || currentUser.username === "admin";
      
      res.json({ 
        isCaregiver,
        userId: currentUser.id,
        username: currentUser.username 
      });
    } catch (error) {
      console.error("Error checking caregiver access:", error);
      res.status(500).json({ message: "Failed to verify caregiver access" });
    }
  });

  // Backup sync endpoint for mobile app
  app.post('/api/backup/sync', requireAuth, async (req: any, res) => {
    try {
      const backupData = req.body;
      const userId = req.user.id;
      
      // Store backup data (simplified implementation)
      // In production, this would sync to cloud storage
      res.json({ 
        success: true, 
        message: 'Backup synced successfully',
        timestamp: new Date().toISOString()
      });
    } catch (error) {
      console.error('Backup sync error:', error);
      res.status(500).json({ error: 'Failed to sync backup' });
    }
  });

  // Sync offline data endpoint
  app.post('/api/sync-offline-data', requireAuth, async (req: any, res) => {
    try {
      const offlineData = req.body;
      const userId = req.user.id;
      
      // Process offline task completions, notes, etc.
      // This would update the database with offline changes
      
      res.json({ 
        success: true, 
        message: 'Offline data synced successfully' 
      });
    } catch (error) {
      console.error('Offline sync error:', error);
      res.status(500).json({ error: 'Failed to sync offline data' });
    }
  });

  // AI Chatbot API endpoints
  app.post("/api/chat", async (req, res) => {
    try {
      const { message, userId } = req.body;
      
      if (!message || !userId) {
        return res.status(400).json({ error: "Message and userId are required" });
      }

      // Get user data for context
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }

      // Create system prompt with user context
      const systemPrompt = `You are AdaptAI, an AI assistant for Adaptalyfe, an app helping individuals with developmental disabilities build independence. 

User context:
- Name: ${user.name || user.username}
- Subscription: ${user.subscriptionTier || 'basic'}

Guidelines:
- Use simple, clear language appropriate for someone with developmental disabilities
- Be encouraging, patient, and supportive
- Focus on building independence and confidence
- Offer practical, step-by-step advice
- Keep responses concise but warm
- If the user seems distressed, provide comfort and suggest talking to their caregiver or support person

Respond helpfully to: ${message}`;

      const completion = await openai.chat.completions.create({
        model: "gpt-3.5-turbo",
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: message }
        ],
        max_tokens: 300,
        temperature: 0.7,
      });

      const response = completion.choices[0]?.message?.content || "I'm here to help! Could you ask me again?";
      
      res.json({ 
        message: response,
        type: "text"
      });
    } catch (error: any) {
      console.error("Error in chat endpoint:", error);
      
      // Handle OpenAI quota exceeded or rate limiting
      if (error.status === 429 || error.code === 'insufficient_quota') {
        // Provide helpful fallback responses based on common queries
        const fallbackResponse = getFallbackResponse(req.body.message);
        res.json({ 
          message: fallbackResponse,
          type: "fallback",
          notice: "AI assistant is temporarily unavailable. Here's some helpful guidance:"
        });
      } else {
        res.status(500).json({ 
          error: "I'm having trouble connecting right now. Please try again in a moment.",
          type: "general_error"
        });
      }
    }
  });

  // Get quick suggestions for chatbot
  app.get("/api/chat/suggestions", async (req, res) => {
    try {
      const suggestions = [
        {
          id: "help-1",
          text: "How do I create a daily routine?",
          category: "help",
        },
        {
          id: "encouragement-1", 
          text: "I'm feeling overwhelmed today",
          category: "encouragement",
        },
        {
          id: "planning-1",
          text: "Help me plan my week",
          category: "planning",
        },
        {
          id: "skills-1",
          text: "I want to learn something new",
          category: "skills",
        }
      ];
      
      res.json(suggestions);
    } catch (error) {
      console.error("Error getting chat suggestions:", error);
      res.status(500).json({ error: "Failed to get suggestions" });
    }
  });

  // Caregiver Permission Management Routes
  app.get("/api/caregiver-permissions/:userId/:caregiverId", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      const caregiverId = parseInt(req.params.caregiverId);
      const permissions = await storage.getCaregiverPermissions(userId, caregiverId);
      res.json(permissions);
    } catch (error) {
      console.error("Error fetching caregiver permissions:", error);
      res.status(500).json({ message: "Failed to fetch caregiver permissions" });
    }
  });

  app.post("/api/caregiver-permissions", async (req, res) => {
    try {
      const permission = await storage.setCaregiverPermission(req.body);
      res.json(permission);
    } catch (error) {
      console.error("Error setting caregiver permission:", error);
      res.status(400).json({ message: "Failed to set caregiver permission" });
    }
  });

  app.delete("/api/caregiver-permissions/:userId/:caregiverId/:permissionType", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      const caregiverId = parseInt(req.params.caregiverId);
      const { permissionType } = req.params;
      const success = await storage.removeCaregiverPermission(userId, caregiverId, permissionType);
      
      if (!success) {
        return res.status(404).json({ message: "Permission not found" });
      }
      
      res.json({ message: "Permission removed successfully" });
    } catch (error) {
      console.error("Error removing caregiver permission:", error);
      res.status(500).json({ message: "Failed to remove caregiver permission" });
    }
  });

  // Locked User Settings Routes
  app.get("/api/locked-settings/:userId", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      const settings = await storage.getLockedUserSettings(userId);
      res.json(settings);
    } catch (error) {
      console.error("Error fetching locked settings:", error);
      res.status(500).json({ message: "Failed to fetch locked settings" });
    }
  });

  // Caregiver Invitation Routes
  app.post("/api/caregiver-invitations", async (req, res) => {
    try {
      const invitation = await storage.createCaregiverInvitation(req.body);
      res.json(invitation);
    } catch (error) {
      console.error("Error creating caregiver invitation:", error);
      res.status(400).json({ message: "Failed to create caregiver invitation" });
    }
  });

  app.get("/api/caregiver-invitations/:caregiverId", async (req, res) => {
    try {
      const caregiverId = parseInt(req.params.caregiverId);
      const invitations = await storage.getCaregiverInvitationsByCaregiver(caregiverId);
      res.json(invitations);
    } catch (error) {
      console.error("Error fetching caregiver invitations:", error);
      res.status(500).json({ message: "Failed to fetch caregiver invitations" });
    }
  });

  app.get("/api/invitation/:code", async (req, res) => {
    try {
      const { code } = req.params;
      const invitation = await storage.getCaregiverInvitation(code);
      
      if (!invitation) {
        return res.status(404).json({ message: "Invitation not found" });
      }

      // Check if invitation is expired
      if (new Date() > new Date(invitation.expiresAt)) {
        await storage.expireCaregiverInvitation(code);
        return res.status(410).json({ message: "Invitation has expired" });
      }

      if (invitation.status !== 'pending') {
        return res.status(400).json({ message: "Invitation is no longer valid" });
      }

      res.json(invitation);
    } catch (error) {
      console.error("Error fetching invitation:", error);
      res.status(500).json({ message: "Failed to fetch invitation" });
    }
  });

  app.post("/api/accept-invitation", async (req, res) => {
    try {
      const { invitationCode, userId } = req.body;
      
      if (!invitationCode || !userId) {
        return res.status(400).json({ message: "Invitation code and user ID are required" });
      }

      const acceptedInvitation = await storage.acceptCaregiverInvitation(invitationCode, userId);
      
      if (!acceptedInvitation) {
        return res.status(400).json({ message: "Invalid or expired invitation" });
      }

      res.json({ 
        message: "Invitation accepted successfully",
        invitation: acceptedInvitation
      });
    } catch (error) {
      console.error("Error accepting invitation:", error);
      res.status(500).json({ message: "Failed to accept invitation" });
    }
  });

  // Care Relationship Routes
  app.get("/api/care-relationships/user/:userId", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      const relationships = await storage.getCareRelationshipsByUser(userId);
      res.json(relationships);
    } catch (error) {
      console.error("Error fetching care relationships:", error);
      res.status(500).json({ message: "Failed to fetch care relationships" });
    }
  });

  app.get("/api/care-relationships/caregiver/:caregiverId", async (req, res) => {
    try {
      const caregiverId = parseInt(req.params.caregiverId);
      const relationships = await storage.getCareRelationshipsByCaregiver(caregiverId);
      res.json(relationships);
    } catch (error) {
      console.error("Error fetching care relationships:", error);
      res.status(500).json({ message: "Failed to fetch care relationships" });
    }
  });

  app.get("/api/locked-settings/:userId/:settingKey", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      const { settingKey } = req.params;
      const setting = await storage.getLockedUserSetting(userId, settingKey);
      if (!setting) {
        return res.status(404).json({ message: "Setting not found" });
      }
      res.json(setting);
    } catch (error) {
      console.error("Error fetching locked setting:", error);
      res.status(500).json({ message: "Failed to fetch locked setting" });
    }
  });

  app.post("/api/locked-settings", async (req, res) => {
    try {
      const setting = await storage.lockUserSetting(req.body);
      res.json(setting);
    } catch (error) {
      console.error("Error locking user setting:", error);
      res.status(400).json({ message: "Failed to lock user setting" });
    }
  });

  app.delete("/api/locked-settings/:userId/:settingKey", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      const { settingKey } = req.params;
      const caregiverId = parseInt(req.body.caregiverId || req.query.caregiverId as string);
      
      if (!caregiverId) {
        return res.status(400).json({ message: "Caregiver ID is required" });
      }
      
      const success = await storage.unlockUserSetting(userId, settingKey, caregiverId);
      
      if (!success) {
        return res.status(403).json({ message: "Permission denied or setting not found" });
      }
      
      res.json({ message: "Setting unlocked successfully" });
    } catch (error) {
      console.error("Error unlocking user setting:", error);
      res.status(500).json({ message: "Failed to unlock user setting" });
    }
  });

  app.get("/api/settings-check/:userId/:settingKey/locked", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      const { settingKey } = req.params;
      const isLocked = await storage.isSettingLocked(userId, settingKey);
      res.json({ isLocked });
    } catch (error) {
      console.error("Error checking if setting is locked:", error);
      res.status(500).json({ message: "Failed to check setting lock status" });
    }
  });

  app.get("/api/settings-check/:userId/:settingKey/modifiable", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      const { settingKey } = req.params;
      const canModify = await storage.canUserModifySetting(userId, settingKey);
      res.json({ canModify });
    } catch (error) {
      console.error("Error checking if user can modify setting:", error);
      res.status(500).json({ message: "Failed to check setting modification permissions" });
    }
  });

  // Pharmacy Integration Routes
  app.get("/api/pharmacies", async (req, res) => {
    try {
      const pharmacies = await storage.getPharmacies();
      res.json(pharmacies);
    } catch (error) {
      console.error("Error fetching pharmacies:", error);
      res.status(500).json({ message: "Failed to fetch pharmacies" });
    }
  });

  app.post("/api/user-pharmacies", async (req, res) => {
    try {
      const validatedData = insertUserPharmacySchema.parse(req.body);
      const userPharmacy = await storage.addUserPharmacy(validatedData);
      res.status(201).json(userPharmacy);
    } catch (error) {
      console.error("Error adding user pharmacy:", error);
      res.status(500).json({ message: "Failed to add pharmacy" });
    }
  });

  app.get("/api/user-pharmacies", async (req, res) => {
    try {
      const userId = 1; // Hardcoded for demo
      const userPharmacies = await storage.getUserPharmacies(userId);
      res.json(userPharmacies);
    } catch (error) {
      console.error("Error fetching user pharmacies:", error);
      res.status(500).json({ message: "Failed to fetch user pharmacies" });
    }
  });

  // Medication Routes
  app.get("/api/medications", async (req, res) => {
    try {
      const userId = 1; // Hardcoded for demo
      const medications = await storage.getMedicationsByUser(userId);
      res.json(medications);
    } catch (error) {
      console.error("Error fetching medications:", error);
      res.status(500).json({ message: "Failed to fetch medications" });
    }
  });

  app.post("/api/medications", async (req, res) => {
    try {
      const validatedData = insertMedicationSchema.parse(req.body);
      const medication = await storage.createMedication(validatedData);
      res.status(201).json(medication);
    } catch (error) {
      console.error("Error creating medication:", error);
      res.status(500).json({ message: "Failed to create medication" });
    }
  });

  app.get("/api/medications/due-for-refill", async (req, res) => {
    try {
      const userId = 1; // Hardcoded for demo
      const medications = await storage.getMedicationsDueForRefill(userId);
      res.json(medications);
    } catch (error) {
      console.error("Error fetching medications due for refill:", error);
      res.status(500).json({ message: "Failed to fetch medications due for refill" });
    }
  });

  // Refill Order Routes
  app.get("/api/refill-orders", async (req, res) => {
    try {
      const userId = 1; // Hardcoded for demo
      const refillOrders = await storage.getRefillOrdersByUser(userId);
      res.json(refillOrders);
    } catch (error) {
      console.error("Error fetching refill orders:", error);
      res.status(500).json({ message: "Failed to fetch refill orders" });
    }
  });

  app.post("/api/refill-orders", async (req, res) => {
    try {
      const validatedData = insertRefillOrderSchema.parse(req.body);
      const refillOrder = await storage.createRefillOrder(validatedData);
      res.status(201).json(refillOrder);
    } catch (error) {
      console.error("Error creating refill order:", error);
      res.status(500).json({ message: "Failed to create refill order" });
    }
  });

  app.patch("/api/refill-orders/:id/status", async (req, res) => {
    try {
      const orderId = parseInt(req.params.id);
      const { status } = req.body;
      const refillOrder = await storage.updateRefillOrderStatus(orderId, status);
      res.json(refillOrder);
    } catch (error) {
      console.error("Error updating refill order status:", error);
      res.status(500).json({ message: "Failed to update refill order status" });
    }
  });

  // Medical Information Routes
  
  // Allergies
  app.get("/api/allergies", async (req, res) => {
    try {
      const userId = 1; // Hardcoded for demo
      const allergies = await storage.getAllergiesByUser(userId);
      res.json(allergies);
    } catch (error) {
      console.error("Error fetching allergies:", error);
      res.status(500).json({ message: "Failed to fetch allergies" });
    }
  });

  app.post("/api/allergies", async (req, res) => {
    try {
      const userId = 1; // Hardcoded for demo
      const allergyData = { ...req.body, userId };
      const allergy = await storage.createAllergy(allergyData);
      res.status(201).json(allergy);
    } catch (error) {
      console.error("Error creating allergy:", error);
      res.status(500).json({ message: "Failed to create allergy" });
    }
  });

  app.put("/api/allergies/:id", async (req, res) => {
    try {
      const allergyId = parseInt(req.params.id);
      const allergy = await storage.updateAllergy(allergyId, req.body);
      res.json(allergy);
    } catch (error) {
      console.error("Error updating allergy:", error);
      res.status(500).json({ message: "Failed to update allergy" });
    }
  });

  app.delete("/api/allergies/:id", async (req, res) => {
    try {
      const allergyId = parseInt(req.params.id);
      const success = await storage.deleteAllergy(allergyId);
      if (!success) {
        return res.status(404).json({ message: "Allergy not found" });
      }
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting allergy:", error);
      res.status(500).json({ message: "Failed to delete allergy" });
    }
  });

  // Medical Conditions
  app.get("/api/medical-conditions", async (req, res) => {
    try {
      const user = storage.getCurrentUser();
      if (!user) {
        return res.status(401).json({ message: "Authentication required" });
      }
      const conditions = await storage.getMedicalConditionsByUser(user.id);
      res.json(conditions);
    } catch (error) {
      console.error("Error fetching medical conditions:", error);
      res.status(500).json({ message: "Failed to fetch medical conditions" });
    }
  });

  app.post("/api/medical-conditions", async (req, res) => {
    try {
      const user = storage.getCurrentUser();
      if (!user) {
        return res.status(401).json({ message: "Authentication required" });
      }
      // Convert diagnosedDate string to Date object if provided
      const conditionData = { ...req.body, userId: user.id };
      if (conditionData.diagnosedDate) {
        conditionData.diagnosedDate = new Date(conditionData.diagnosedDate);
      }
      const condition = await storage.createMedicalCondition(conditionData);
      res.status(201).json(condition);
    } catch (error) {
      console.error("Error creating medical condition:", error);
      res.status(500).json({ message: "Failed to create medical condition" });
    }
  });

  app.put("/api/medical-conditions/:id", async (req, res) => {
    try {
      const conditionId = parseInt(req.params.id);
      const condition = await storage.updateMedicalCondition(conditionId, req.body);
      res.json(condition);
    } catch (error) {
      console.error("Error updating medical condition:", error);
      res.status(500).json({ message: "Failed to update medical condition" });
    }
  });

  app.delete("/api/medical-conditions/:id", async (req, res) => {
    try {
      const conditionId = parseInt(req.params.id);
      const success = await storage.deleteMedicalCondition(conditionId);
      if (!success) {
        return res.status(404).json({ message: "Medical condition not found" });
      }
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting medical condition:", error);
      res.status(500).json({ message: "Failed to delete medical condition" });
    }
  });

  // Adverse Medications
  app.get("/api/adverse-medications", async (req, res) => {
    try {
      const user = storage.getCurrentUser();
      if (!user) {
        return res.status(401).json({ message: "Authentication required" });
      }
      const adverseMeds = await storage.getAdverseMedicationsByUser(user.id);
      res.json(adverseMeds);
    } catch (error) {
      console.error("Error fetching adverse medications:", error);
      res.status(500).json({ message: "Failed to fetch adverse medications" });
    }
  });

  app.post("/api/adverse-medications", async (req, res) => {
    try {
      const user = storage.getCurrentUser();
      if (!user) {
        return res.status(401).json({ message: "Authentication required" });
      }
      // Convert reactionDate string to Date object if provided
      const adverseMedData = { ...req.body, userId: user.id };
      if (adverseMedData.reactionDate) {
        adverseMedData.reactionDate = new Date(adverseMedData.reactionDate);
      }
      const adverseMed = await storage.createAdverseMedication(adverseMedData);
      res.status(201).json(adverseMed);
    } catch (error) {
      console.error("Error creating adverse medication:", error);
      res.status(500).json({ message: "Failed to create adverse medication" });
    }
  });

  app.put("/api/adverse-medications/:id", async (req, res) => {
    try {
      const adverseMedId = parseInt(req.params.id);
      const adverseMed = await storage.updateAdverseMedication(adverseMedId, req.body);
      res.json(adverseMed);
    } catch (error) {
      console.error("Error updating adverse medication:", error);
      res.status(500).json({ message: "Failed to update adverse medication" });
    }
  });

  app.delete("/api/adverse-medications/:id", async (req, res) => {
    try {
      const adverseMedId = parseInt(req.params.id);
      const success = await storage.deleteAdverseMedication(adverseMedId);
      if (!success) {
        return res.status(404).json({ message: "Adverse medication not found" });
      }
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting adverse medication:", error);
      res.status(500).json({ message: "Failed to delete adverse medication" });
    }
  });

  // Emergency Contacts
  app.get("/api/emergency-contacts", async (req, res) => {
    try {
      const userId = 1; // Hardcoded for demo
      const contacts = await storage.getEmergencyContactsByUser(userId);
      res.json(contacts);
    } catch (error) {
      console.error("Error fetching emergency contacts:", error);
      res.status(500).json({ message: "Failed to fetch emergency contacts" });
    }
  });

  app.post("/api/emergency-contacts", async (req, res) => {
    try {
      const userId = 1; // Hardcoded for demo
      const contactData = { ...req.body, userId };
      const contact = await storage.createEmergencyContact(contactData);
      res.status(201).json(contact);
    } catch (error) {
      console.error("Error creating emergency contact:", error);
      res.status(500).json({ message: "Failed to create emergency contact" });
    }
  });

  app.put("/api/emergency-contacts/:id", async (req, res) => {
    try {
      const contactId = parseInt(req.params.id);
      const contact = await storage.updateEmergencyContact(contactId, req.body);
      res.json(contact);
    } catch (error) {
      console.error("Error updating emergency contact:", error);
      res.status(500).json({ message: "Failed to update emergency contact" });
    }
  });

  app.delete("/api/emergency-contacts/:id", async (req, res) => {
    try {
      const contactId = parseInt(req.params.id);
      const success = await storage.deleteEmergencyContact(contactId);
      if (!success) {
        return res.status(404).json({ message: "Emergency contact not found" });
      }
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting emergency contact:", error);
      res.status(500).json({ message: "Failed to delete emergency contact" });
    }
  });

  // Primary Care Providers
  app.get("/api/primary-care-providers", async (req, res) => {
    try {
      const userId = 1; // Hardcoded for demo
      const providers = await storage.getPrimaryCareProvidersByUser(userId);
      res.json(providers);
    } catch (error) {
      console.error("Error fetching primary care providers:", error);
      res.status(500).json({ message: "Failed to fetch primary care providers" });
    }
  });

  app.post("/api/primary-care-providers", async (req, res) => {
    try {
      const userId = 1; // Hardcoded for demo
      const providerData = { ...req.body, userId };
      const provider = await storage.createPrimaryCareProvider(providerData);
      res.status(201).json(provider);
    } catch (error) {
      console.error("Error creating primary care provider:", error);
      res.status(500).json({ message: "Failed to create primary care provider" });
    }
  });

  app.put("/api/primary-care-providers/:id", async (req, res) => {
    try {
      const providerId = parseInt(req.params.id);
      const provider = await storage.updatePrimaryCareProvider(providerId, req.body);
      res.json(provider);
    } catch (error) {
      console.error("Error updating primary care provider:", error);
      res.status(500).json({ message: "Failed to update primary care provider" });
    }
  });

  app.delete("/api/primary-care-providers/:id", async (req, res) => {
    try {
      const providerId = parseInt(req.params.id);
      const success = await storage.deletePrimaryCareProvider(providerId);
      if (!success) {
        return res.status(404).json({ message: "Primary care provider not found" });
      }
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting primary care provider:", error);
      res.status(500).json({ message: "Failed to delete primary care provider" });
    }
  });

  // Symptom Tracking Routes
  app.get("/api/symptom-entries", async (req, res) => {
    try {
      const user = storage.getCurrentUser();
      if (!user) {
        return res.status(401).json({ message: "Authentication required" });
      }
      const entries = await storage.getSymptomEntriesByUser(user.id);
      res.json(entries);
    } catch (error) {
      console.error("Error fetching symptom entries:", error);
      res.status(500).json({ message: "Failed to fetch symptom entries" });
    }
  });

  app.get("/api/symptom-entries/date-range", async (req, res) => {
    try {
      const user = storage.getCurrentUser();
      if (!user) {
        return res.status(401).json({ message: "Authentication required" });
      }
      const { startDate, endDate } = req.query;
      
      if (!startDate || !endDate) {
        return res.status(400).json({ message: "Start date and end date are required" });
      }
      
      const entries = await storage.getSymptomEntriesByDateRange(
        user.id, 
        startDate as string, 
        endDate as string
      );
      res.json(entries);
    } catch (error) {
      console.error("Error fetching symptom entries by date range:", error);
      res.status(500).json({ message: "Failed to fetch symptom entries" });
    }
  });

  app.post("/api/symptom-entries", async (req, res) => {
    try {
      const user = storage.getCurrentUser();
      if (!user) {
        return res.status(401).json({ message: "Authentication required" });
      }
      
      console.log("Creating symptom entry for user:", user.id);
      console.log("Request body:", req.body);
      
      const entryData = { 
        ...req.body, 
        userId: user.id,
        startTime: new Date(req.body.startTime),
        endTime: req.body.endTime ? new Date(req.body.endTime) : null
      };
      
      console.log("Entry data to save:", entryData);
      
      const entry = await storage.createSymptomEntry(entryData);
      console.log("Created symptom entry:", entry);
      res.status(201).json(entry);
    } catch (error) {
      console.error("Error creating symptom entry:", error);
      res.status(500).json({ message: "Failed to create symptom entry" });
    }
  });

  app.patch("/api/symptom-entries/:id", async (req, res) => {
    try {
      const entryId = parseInt(req.params.id);
      const updates = req.body;
      
      const updated = await storage.updateSymptomEntry(entryId, updates);
      
      if (!updated) {
        return res.status(404).json({ message: "Symptom entry not found" });
      }
      
      res.json(updated);
    } catch (error) {
      console.error("Error updating symptom entry:", error);
      res.status(500).json({ message: "Failed to update symptom entry" });
    }
  });

  app.delete("/api/symptom-entries/:id", async (req, res) => {
    try {
      const entryId = parseInt(req.params.id);
      const deleted = await storage.deleteSymptomEntry(entryId);
      
      if (!deleted) {
        return res.status(404).json({ message: "Symptom entry not found" });
      }
      
      res.json({ message: "Symptom entry deleted successfully" });
    } catch (error) {
      console.error("Error deleting symptom entry:", error);
      res.status(500).json({ message: "Failed to delete symptom entry" });
    }
  });

  // Personal Resources Routes
  app.get("/api/personal-resources", async (req, res) => {
    try {
      const userId = 1; // Hardcoded for demo
      const { category } = req.query;
      
      let resources;
      if (category && typeof category === 'string') {
        resources = await storage.getPersonalResourcesByCategory(userId, category);
      } else {
        resources = await storage.getPersonalResourcesByUser(userId);
      }
      
      res.json(resources);
    } catch (error) {
      console.error("Error fetching personal resources:", error);
      res.status(500).json({ message: "Failed to fetch personal resources" });
    }
  });

  app.post("/api/personal-resources", async (req, res) => {
    try {
      const userId = 1; // Hardcoded for demo
      const resourceData = insertPersonalResourceSchema.parse({ ...req.body, userId });
      
      const resource = await storage.createPersonalResource(resourceData);
      res.status(201).json(resource);
    } catch (error) {
      console.error("Error creating personal resource:", error);
      res.status(500).json({ message: "Failed to create personal resource" });
    }
  });

  app.patch("/api/personal-resources/:id", async (req, res) => {
    try {
      const resourceId = parseInt(req.params.id);
      const updates = req.body;
      
      const updated = await storage.updatePersonalResource(resourceId, updates);
      
      if (!updated) {
        return res.status(404).json({ message: "Personal resource not found" });
      }
      
      res.json(updated);
    } catch (error) {
      console.error("Error updating personal resource:", error);
      res.status(500).json({ message: "Failed to update personal resource" });
    }
  });

  app.delete("/api/personal-resources/:id", async (req, res) => {
    try {
      const resourceId = parseInt(req.params.id);
      const deleted = await storage.deletePersonalResource(resourceId);
      
      if (!deleted) {
        return res.status(404).json({ message: "Personal resource not found" });
      }
      
      res.json({ message: "Personal resource deleted successfully" });
    } catch (error) {
      console.error("Error deleting personal resource:", error);
      res.status(500).json({ message: "Failed to delete personal resource" });
    }
  });

  app.patch("/api/personal-resources/:id/access", async (req, res) => {
    try {
      const resourceId = parseInt(req.params.id);
      const updated = await storage.incrementResourceAccess(resourceId);
      
      if (!updated) {
        return res.status(404).json({ message: "Personal resource not found" });
      }
      
      res.json(updated);
    } catch (error) {
      console.error("Error updating resource access:", error);
      res.status(500).json({ message: "Failed to update resource access" });
    }
  });

  // Bus Schedule Routes
  app.get("/api/bus-schedules", async (req, res) => {
    try {
      const userId = 1; // TODO: Get from auth
      const schedules = await storage.getBusSchedulesByUser(userId);
      res.json(schedules);
    } catch (error) {
      console.error("Error fetching bus schedules:", error);
      res.status(500).json({ message: "Failed to fetch bus schedules" });
    }
  });

  app.get("/api/bus-schedules/day/:day", async (req, res) => {
    try {
      const userId = 1; // TODO: Get from auth
      const { day } = req.params;
      const schedules = await storage.getBusSchedulesByDay(userId, day);
      res.json(schedules);
    } catch (error) {
      console.error("Error fetching bus schedules by day:", error);
      res.status(500).json({ message: "Failed to fetch bus schedules by day" });
    }
  });

  app.get("/api/bus-schedules/frequent", async (req, res) => {
    try {
      const userId = 1; // TODO: Get from auth
      const schedules = await storage.getFrequentBusRoutes(userId);
      res.json(schedules);
    } catch (error) {
      console.error("Error fetching frequent bus routes:", error);
      res.status(500).json({ message: "Failed to fetch frequent bus routes" });
    }
  });

  app.post("/api/bus-schedules", async (req, res) => {
    try {
      const userId = 1; // TODO: Get from auth
      const data = insertBusScheduleSchema.parse({ ...req.body, userId });
      const schedule = await storage.createBusSchedule(data);
      res.json(schedule);
    } catch (error) {
      console.error("Error creating bus schedule:", error);
      res.status(500).json({ message: "Failed to create bus schedule" });
    }
  });

  app.put("/api/bus-schedules/:id", async (req, res) => {
    try {
      const scheduleId = parseInt(req.params.id);
      const data = insertBusScheduleSchema.partial().parse(req.body);
      const schedule = await storage.updateBusSchedule(scheduleId, data);
      
      if (!schedule) {
        return res.status(404).json({ message: "Bus schedule not found" });
      }
      
      res.json(schedule);
    } catch (error) {
      console.error("Error updating bus schedule:", error);
      res.status(500).json({ message: "Failed to update bus schedule" });
    }
  });

  app.delete("/api/bus-schedules/:id", async (req, res) => {
    try {
      const scheduleId = parseInt(req.params.id);
      const success = await storage.deleteBusSchedule(scheduleId);
      
      if (!success) {
        return res.status(404).json({ message: "Bus schedule not found" });
      }
      
      res.json({ message: "Bus schedule deleted successfully" });
    } catch (error) {
      console.error("Error deleting bus schedule:", error);
      res.status(500).json({ message: "Failed to delete bus schedule" });
    }
  });

  // Emergency Treatment Plan Routes
  app.get("/api/emergency-treatment-plans", async (req, res) => {
    try {
      const userId = 1; // TODO: Get from auth
      const plans = await storage.getEmergencyTreatmentPlansByUser(userId);
      res.json(plans);
    } catch (error) {
      console.error("Error fetching emergency treatment plans:", error);
      res.status(500).json({ message: "Failed to fetch emergency treatment plans" });
    }
  });

  app.get("/api/emergency-treatment-plans/active", async (req, res) => {
    try {
      const userId = 1; // TODO: Get from auth
      const plans = await storage.getActiveEmergencyTreatmentPlans(userId);
      res.json(plans);
    } catch (error) {
      console.error("Error fetching active emergency treatment plans:", error);
      res.status(500).json({ message: "Failed to fetch active emergency treatment plans" });
    }
  });

  app.post("/api/emergency-treatment-plans", async (req, res) => {
    try {
      const userId = 1; // TODO: Get from auth
      const data = insertEmergencyTreatmentPlanSchema.parse({ ...req.body, userId });
      const plan = await storage.createEmergencyTreatmentPlan(data);
      res.json(plan);
    } catch (error) {
      console.error("Error creating emergency treatment plan:", error);
      res.status(500).json({ message: "Failed to create emergency treatment plan" });
    }
  });

  app.put("/api/emergency-treatment-plans/:id", async (req, res) => {
    try {
      const planId = parseInt(req.params.id);
      const data = insertEmergencyTreatmentPlanSchema.partial().parse(req.body);
      const plan = await storage.updateEmergencyTreatmentPlan(planId, data);
      
      if (!plan) {
        return res.status(404).json({ message: "Emergency treatment plan not found" });
      }
      
      res.json(plan);
    } catch (error) {
      console.error("Error updating emergency treatment plan:", error);
      res.status(500).json({ message: "Failed to update emergency treatment plan" });
    }
  });

  app.delete("/api/emergency-treatment-plans/:id", async (req, res) => {
    try {
      const planId = parseInt(req.params.id);
      const success = await storage.deleteEmergencyTreatmentPlan(planId);
      
      if (!success) {
        return res.status(404).json({ message: "Emergency treatment plan not found" });
      }
      
      res.json({ message: "Emergency treatment plan deleted successfully" });
    } catch (error) {
      console.error("Error deleting emergency treatment plan:", error);
      res.status(500).json({ message: "Failed to delete emergency treatment plan" });
    }
  });

  // Geofencing API routes
  app.get("/api/geofences", async (req, res) => {
    try {
      const geofences = await storage.getGeofencesByUser(1);
      res.json(geofences);
    } catch (error) {
      console.error("Error fetching geofences:", error);
      res.status(500).json({ message: "Failed to fetch geofences" });
    }
  });

  app.get("/api/geofences/active", async (req, res) => {
    try {
      const geofences = await storage.getActiveGeofencesByUser(1);
      res.json(geofences);
    } catch (error) {
      console.error("Error fetching active geofences:", error);
      res.status(500).json({ message: "Failed to fetch active geofences" });
    }
  });

  app.post("/api/geofences", async (req, res) => {
    try {
      const geofenceData = { ...req.body, userId: 1 };
      const geofence = await storage.createGeofence(geofenceData);
      res.json(geofence);
    } catch (error) {
      console.error("Error creating geofence:", error);
      res.status(500).json({ message: "Failed to create geofence" });
    }
  });

  app.put("/api/geofences/:id", async (req, res) => {
    try {
      const geofenceId = parseInt(req.params.id);
      const updates = req.body;
      const geofence = await storage.updateGeofence(geofenceId, updates);
      
      if (!geofence) {
        return res.status(404).json({ message: "Geofence not found" });
      }
      
      res.json(geofence);
    } catch (error) {
      console.error("Error updating geofence:", error);
      res.status(500).json({ message: "Failed to update geofence" });
    }
  });

  app.delete("/api/geofences/:id", async (req, res) => {
    try {
      const geofenceId = parseInt(req.params.id);
      const success = await storage.deleteGeofence(geofenceId);
      
      if (!success) {
        return res.status(404).json({ message: "Geofence not found" });
      }
      
      res.json({ message: "Geofence deleted successfully" });
    } catch (error) {
      console.error("Error deleting geofence:", error);
      res.status(500).json({ message: "Failed to delete geofence" });
    }
  });

  app.get("/api/geofence-events", async (req, res) => {
    try {
      const limit = parseInt(req.query.limit as string) || 50;
      const events = await storage.getGeofenceEventsByUser(1, limit);
      res.json(events);
    } catch (error) {
      console.error("Error fetching geofence events:", error);
      res.status(500).json({ message: "Failed to fetch geofence events" });
    }
  });

  app.get("/api/geofences/:id/events", async (req, res) => {
    try {
      const geofenceId = parseInt(req.params.id);
      const limit = parseInt(req.query.limit as string) || 50;
      const events = await storage.getGeofenceEventsByGeofence(geofenceId, limit);
      res.json(events);
    } catch (error) {
      console.error("Error fetching geofence events:", error);
      res.status(500).json({ message: "Failed to fetch geofence events" });
    }
  });

  app.post("/api/geofence-events", async (req, res) => {
    try {
      const eventData = { ...req.body, userId: 1 };
      const event = await storage.createGeofenceEvent(eventData);
      
      // Here you could add logic to send notifications to caregivers
      // based on the geofence settings and caregiver preferences
      
      res.json(event);
    } catch (error) {
      console.error("Error creating geofence event:", error);
      res.status(500).json({ message: "Failed to create geofence event" });
    }
  });

  app.put("/api/geofence-events/:id/notify", async (req, res) => {
    try {
      const eventId = parseInt(req.params.id);
      const success = await storage.markGeofenceEventNotified(eventId);
      
      if (!success) {
        return res.status(404).json({ message: "Geofence event not found" });
      }
      
      res.json({ message: "Geofence event marked as notified" });
    } catch (error) {
      console.error("Error marking geofence event as notified:", error);
      res.status(500).json({ message: "Failed to mark geofence event as notified" });
    }
  });

  // User Preferences Routes
  app.get("/api/user-preferences", async (req, res) => {
    try {
      const userId = 1; // TODO: Get from auth
      const preferences = await storage.getUserPreferences(userId);
      
      // Return default preferences if none exist
      if (!preferences) {
        const defaultPreferences = {
          userId,
          notificationSettings: {},
          reminderTiming: {},
          themeSettings: {
            quickActions: ["mood-tracking", "daily-tasks", "financial", "caregiver"]
          },
          accessibilitySettings: {},
          behaviorPatterns: {}
        };
        res.json(defaultPreferences);
      } else {
        res.json(preferences);
      }
    } catch (error) {
      console.error("Error fetching user preferences:", error);
      res.status(500).json({ message: "Failed to fetch user preferences" });
    }
  });

  app.post("/api/user-preferences", async (req, res) => {
    try {
      const userId = 1; // TODO: Get from auth
      const preferencesData = req.body;
      const preferences = await storage.upsertUserPreferences(userId, preferencesData);
      res.json(preferences);
    } catch (error) {
      console.error("Error updating user preferences:", error);
      res.status(400).json({ message: "Failed to update user preferences" });
    }
  });

  // Wearable Devices Demo Routes (Simple static data for demo)
  app.get("/api/wearable-devices", async (req, res) => {
    try {
      const demoDevices = [
        {
          id: 1,
          name: "Apple Watch Series 9",
          type: "smartwatch",
          brand: "Apple",
          model: "Series 9",
          isConnected: true,
          batteryLevel: 87,
          lastSync: new Date().toISOString(),
          features: ["heart_rate", "steps", "sleep", "workouts", "blood_oxygen"]
        },
        {
          id: 2,
          name: "Fitbit Charge 5",
          type: "fitness_tracker",
          brand: "Fitbit",
          model: "Charge 5",
          isConnected: true,
          batteryLevel: 65,
          lastSync: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(), // 2 hours ago
          features: ["heart_rate", "steps", "sleep", "stress"]
        },
        {
          id: 3,
          name: "Galaxy Watch6 Classic",
          type: "smartwatch",
          brand: "Samsung",
          model: "Watch6 Classic",
          isConnected: true,
          batteryLevel: 72,
          lastSync: new Date(Date.now() - 30 * 60 * 1000).toISOString(), // 30 minutes ago
          features: ["heart_rate", "steps", "sleep", "workouts", "blood_oxygen", "body_composition", "ecg"]
        }
      ];
      res.json(demoDevices);
    } catch (error) {
      console.error("Error fetching wearable devices:", error);
      res.status(500).json({ message: "Failed to fetch wearable devices" });
    }
  });

  app.get("/api/health-metrics", async (req, res) => {
    try {
      const demoMetrics = [
        {
          id: 1,
          metricType: "heart_rate",
          value: 72,
          unit: "bpm",
          recordedAt: new Date().toISOString(),
          context: "resting",
          deviceId: 1 // Apple Watch
        },
        {
          id: 2,
          metricType: "steps",
          value: 7543,
          unit: "steps",
          recordedAt: new Date().toISOString(),
          context: "daily_total",
          deviceId: 1 // Apple Watch
        },
        {
          id: 3,
          metricType: "blood_oxygen",
          value: 98,
          unit: "%",
          recordedAt: new Date().toISOString(),
          context: "resting",
          deviceId: 1 // Apple Watch
        },
        {
          id: 4,
          metricType: "heart_rate",
          value: 68,
          unit: "bpm",
          recordedAt: new Date(Date.now() - 30 * 60 * 1000).toISOString(),
          context: "resting",
          deviceId: 3 // Galaxy Watch
        },
        {
          id: 5,
          metricType: "steps",
          value: 8124,
          unit: "steps",
          recordedAt: new Date(Date.now() - 30 * 60 * 1000).toISOString(),
          context: "daily_total",
          deviceId: 3 // Galaxy Watch
        },
        {
          id: 6,
          metricType: "blood_oxygen",
          value: 97,
          unit: "%",
          recordedAt: new Date(Date.now() - 30 * 60 * 1000).toISOString(),
          context: "resting",
          deviceId: 3 // Galaxy Watch
        }
      ];
      res.json(demoMetrics);
    } catch (error) {
      console.error("Error fetching health metrics:", error);
      res.status(500).json({ message: "Failed to fetch health metrics" });
    }
  });

  app.get("/api/activity-sessions", async (req, res) => {
    try {
      const demoActivities = [
        {
          id: 1,
          activityType: "walking",
          duration: 45,
          caloriesBurned: 185,
          steps: 3200,
          startedAt: new Date(Date.now() - 3 * 60 * 60 * 1000).toISOString(), // 3 hours ago
          deviceId: 1 // Apple Watch
        },
        {
          id: 2,
          activityType: "cycling",
          duration: 30,
          caloriesBurned: 240,
          steps: 0,
          startedAt: new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString(), // yesterday
          deviceId: 2 // Fitbit
        },
        {
          id: 3,
          activityType: "strength_training",
          duration: 25,
          caloriesBurned: 120,
          steps: 150,
          startedAt: new Date(Date.now() - 48 * 60 * 60 * 1000).toISOString(), // 2 days ago
          deviceId: 1 // Apple Watch
        },
        {
          id: 4,
          activityType: "running",
          duration: 35,
          caloriesBurned: 320,
          steps: 4200,
          startedAt: new Date(Date.now() - 6 * 60 * 60 * 1000).toISOString(), // 6 hours ago
          deviceId: 3 // Galaxy Watch
        },
        {
          id: 5,
          activityType: "yoga",
          duration: 20,
          caloriesBurned: 95,
          steps: 50,
          startedAt: new Date(Date.now() - 12 * 60 * 60 * 1000).toISOString(), // 12 hours ago
          deviceId: 3 // Galaxy Watch
        }
      ];
      res.json(demoActivities);
    } catch (error) {
      console.error("Error fetching activity sessions:", error);
      res.status(500).json({ message: "Failed to fetch activity sessions" });
    }
  });

  app.get("/api/sleep-sessions", async (req, res) => {
    try {
      const demoSleep = [
        {
          id: 1,
          sleepDate: new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString().split('T')[0], // last night
          totalSleepDuration: 450, // 7.5 hours in minutes
          sleepScore: 85,
          quality: "good"
        },
        {
          id: 2,
          sleepDate: new Date(Date.now() - 48 * 60 * 60 * 1000).toISOString().split('T')[0], // 2 nights ago
          totalSleepDuration: 420, // 7 hours
          sleepScore: 78,
          quality: "fair"
        },
        {
          id: 3,
          sleepDate: new Date(Date.now() - 72 * 60 * 60 * 1000).toISOString().split('T')[0], // 3 nights ago
          totalSleepDuration: 480, // 8 hours
          sleepScore: 92,
          quality: "excellent"
        }
      ];
      res.json(demoSleep);
    } catch (error) {
      console.error("Error fetching sleep sessions:", error);
      res.status(500).json({ message: "Failed to fetch sleep sessions" });
    }
  });

  app.post("/api/wearable-devices/:id/sync", async (req, res) => {
    try {
      const deviceId = parseInt(req.params.id);
      // Simulate sync operation
      setTimeout(() => {
        res.json({ 
          message: "Device synced successfully", 
          deviceId,
          lastSync: new Date().toISOString()
        });
      }, 1000);
    } catch (error) {
      console.error("Error syncing device:", error);
      res.status(500).json({ message: "Failed to sync device" });
    }
  });

  // Subscription Management Routes
  app.get("/api/subscription", async (req, res) => {
    try {
      const userId = 1; // Use logged-in user ID when auth is available
      
      // Demo subscription data - in production this would come from database
      const demoSubscription = {
        id: 1,
        planType: "free",
        status: "active",
        billingCycle: "monthly",
        currentPeriodStart: new Date().toISOString(),
        currentPeriodEnd: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(),
        trialDaysLeft: null,
        usageStats: {
          tasks: { count: 8, limit: 10 },
          caregivers: { count: 1, limit: 1 },
          dataExports: { count: 0, limit: 0 }
        },
        features: {
          wearableDevices: false,
          mealPlanning: false,
          medicationManagement: false,
          locationSafety: false,
          advancedAnalytics: false,
          prioritySupport: false
        }
      };
      
      res.json(demoSubscription);
    } catch (error) {
      console.error("Error fetching subscription:", error);
      res.status(500).json({ message: "Failed to fetch subscription" });
    }
  });

  app.post("/api/subscription/upgrade", async (req, res) => {
    try {
      const { planType, billingCycle } = req.body;
      
      // Demo upgrade response
      const upgradedSubscription = {
        id: 1,
        planType,
        status: "trialing",
        billingCycle,
        currentPeriodStart: new Date().toISOString(),
        currentPeriodEnd: new Date(Date.now() + 14 * 24 * 60 * 60 * 1000).toISOString(),
        trialDaysLeft: 14,
        usageStats: {
          tasks: { count: 8, limit: planType === "family" ? null : 1000 },
          caregivers: { count: 1, limit: planType === "family" ? null : 10 },
          dataExports: { count: 0, limit: null }
        },
        features: {
          wearableDevices: true,
          mealPlanning: true,
          medicationManagement: true,
          locationSafety: true,
          advancedAnalytics: planType === "family",
          prioritySupport: true,
          familyAccounts: planType === "family" ? 5 : 1
        }
      };

      res.json(upgradedSubscription);
    } catch (error) {
      console.error("Error upgrading subscription:", error);
      res.status(500).json({ message: "Failed to upgrade subscription" });
    }
  });

  // Real Stripe Payment Routes
  app.post("/api/create-payment-intent", async (req, res) => {
    try {
      const { planType, billingCycle } = req.body;
      
      // Check if Stripe is available
      const currentStripe = getStripeInstance();
      if (!currentStripe) {
        console.log("Stripe not configured - using demo mode");
        return res.status(200).json({ 
          clientSecret: "pi_demo_" + Date.now() + "_secret_demo",
          demoMode: true,
          message: "Demo payment mode - Stripe configuration pending"
        });
      }
      
      // Define pricing based on plan
      const pricing = {
        basic: { monthly: 499, annual: 4900 }, // $4.99, $49
        premium: { monthly: 1299, annual: 12900 }, // $12.99, $129
        family: { monthly: 2499, annual: 24900 } // $24.99, $249
      };
      
      const amount = pricing[planType as keyof typeof pricing]?.[billingCycle as keyof typeof pricing.basic] || 1299;
      
      const paymentIntent = await currentStripe.paymentIntents.create({
        amount,
        currency: "usd",
        metadata: {
          planType,
          billingCycle,
          userId: "1" // Replace with actual user ID
        }
      });
      
      res.json({ 
        clientSecret: paymentIntent.client_secret,
        demoMode: false,
        message: "Live payment processing enabled"
      });
    } catch (error: any) {
      console.error("Error creating payment intent:", error);
      
      // Handle specific Stripe authentication errors
      if (error.type === 'StripeAuthenticationError') {
        console.log("Stripe authentication failed - falling back to demo mode");
        
        // Fallback to demo mode while Stripe account is being activated
        return res.status(200).json({ 
          clientSecret: "pi_demo_" + Date.now() + "_secret_demo",
          demoMode: true,
          message: "Demo payment mode - your Stripe account is being activated"
        });
      }
      
      res.status(500).json({ 
        message: "Failed to create payment intent",
        error: error.message || "Unknown error"
      });
    }
  });

  // Upgrade user subscription after successful payment
  app.post("/api/upgrade-subscription", async (req, res) => {
    try {
      const { planType, billingCycle, paymentIntentId } = req.body;
      const user = storage.getCurrentUser();
      
      if (!user) {
        return res.status(401).json({ message: "Authentication required" });
      }
      
      // Verify payment intent was successful (in production, verify with Stripe)
      const currentStripe = getStripeInstance();
      if (currentStripe && paymentIntentId) {
        const paymentIntent = await currentStripe.paymentIntents.retrieve(paymentIntentId);
        if (paymentIntent.status !== 'succeeded') {
          return res.status(400).json({ message: "Payment not confirmed" });
        }
      }
      
      // Upgrade user subscription
      const subscriptionTier = planType === 'basic' ? 'basic' : 
                              planType === 'premium' ? 'premium' : 'family';
      
      const expiresAt = new Date();
      if (billingCycle === 'annual') {
        expiresAt.setFullYear(expiresAt.getFullYear() + 1);
      } else {
        expiresAt.setMonth(expiresAt.getMonth() + 1);
      }
      
      // Update user subscription in storage
      await storage.updateUserSubscription(user.id, {
        subscriptionTier,
        subscriptionStatus: 'active',
        subscriptionExpiresAt: expiresAt
      });
      
      res.json({ 
        message: "Subscription upgraded successfully",
        plan: planType,
        billing: billingCycle,
        expiresAt: expiresAt.toISOString()
      });
    } catch (error: any) {
      console.error("Error upgrading subscription:", error);
      res.status(500).json({ 
        message: "Failed to upgrade subscription",
        error: error.message || "Unknown error"
      });
    }
  });

  // Demo subscription creation (simulates successful payment)
  app.post("/api/create-checkout-session", async (req, res) => {
    try {
      const { planType, billingCycle } = req.body;
      
      // For demo purposes, simulate successful subscription creation
      const subscription = {
        id: 'sub_demo_' + Date.now(),
        plan: planType,
        billing: billingCycle,
        status: 'active',
        created: new Date().toISOString()
      };
      
      // Simulate processing delay
      setTimeout(() => {
        res.json({ 
          success: true, 
          subscription,
          message: 'Subscription created successfully' 
        });
      }, 1000);
      
    } catch (error: any) {
      console.error('Checkout session error:', error);
      res.status(500).json({ 
        message: "Error creating subscription", 
        error: error.message 
      });
    }
  });

  app.post("/api/create-subscription", async (req, res) => {
    try {
      const { planType, billingCycle, paymentMethodId } = req.body;
      
      // Create customer
      const customer = await stripe.customers.create({
        payment_method: paymentMethodId,
        email: "user@example.com", // Replace with actual user email
        invoice_settings: {
          default_payment_method: paymentMethodId,
        },
      });

      // Define price IDs (you'll need to create these in Stripe Dashboard)
      const priceIds = {
        basic: { monthly: "price_basic_monthly", annual: "price_basic_annual" },
        premium: { monthly: "price_premium_monthly", annual: "price_premium_annual" },
        family: { monthly: "price_family_monthly", annual: "price_family_annual" }
      };

      const subscription = await stripe.subscriptions.create({
        customer: customer.id,
        items: [{ price: priceIds[planType][billingCycle] }],
        expand: ["latest_invoice.payment_intent"],
      });

      res.json({
        subscriptionId: subscription.id,
        clientSecret: subscription.latest_invoice.payment_intent.client_secret,
      });
    } catch (error) {
      console.error("Error creating subscription:", error);
      res.status(500).json({ message: "Failed to create subscription" });
    }
  });

  app.get("/api/subscription/payment-history", async (req, res) => {
    try {
      // Get actual payment history from Stripe
      const payments = await stripe.paymentIntents.list({
        limit: 10,
        metadata: { userId: "1" } // Replace with actual user ID
      });
      
      const formattedPayments = payments.data.map(payment => ({
        id: payment.id,
        amount: payment.amount,
        currency: payment.currency,
        status: payment.status,
        description: payment.description || "Adaptalyfe Subscription",
        paidAt: new Date(payment.created * 1000).toISOString(),
        paymentMethod: payment.payment_method ? "•••• " + payment.payment_method.slice(-4) : "N/A"
      }));
      
      res.json(formattedPayments);
    } catch (error) {
      console.error("Error fetching payment history:", error);
      res.status(500).json({ message: "Failed to fetch payment history" });
    }
  });

  // Caregiver dashboard routes
  app.get("/api/caregiver-users", async (req, res) => {
    try {
      // In a real app, this would get users assigned to the authenticated caregiver
      // For demo purposes, return the demo user
      const users = await storage.getAllUsers();
      const userProgress = users.map(user => ({
        userId: user.id,
        userName: user.name || user.username,
        streakDays: user.streakDays || 12,
        lastActive: new Date().toISOString(),
        completionRate: 85,
        moodTrend: 'stable' as const,
        alertsCount: 1
      }));
      res.json(userProgress);
    } catch (error) {
      console.error("Error fetching caregiver users:", error);
      res.status(500).json({ message: "Failed to fetch users" });
    }
  });

  app.get("/api/user-summary/:userId", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      const user = await storage.getUser(userId);
      const tasks = await storage.getDailyTasks(userId);
      const moods = await storage.getMoodEntries(userId);
      const appointments = await storage.getAppointments(userId);
      const medications = await storage.getMedications(userId);

      const summary = {
        user,
        taskCompletion: {
          total: tasks.length,
          completed: tasks.filter(t => t.isCompleted).length,
          rate: tasks.length > 0 ? Math.round((tasks.filter(t => t.isCompleted).length / tasks.length) * 100) : 0
        },
        moodData: {
          recent: moods.slice(-7),
          average: moods.length > 0 ? (moods.reduce((sum, m) => sum + m.mood, 0) / moods.length).toFixed(1) : 0
        },
        upcomingAppointments: appointments.filter(a => new Date(a.appointmentDate) > new Date()).slice(0, 3),
        medications: medications.filter(m => !m.isDiscontinued)
      };

      res.json(summary);
    } catch (error) {
      console.error("Error fetching user summary:", error);
      res.status(500).json({ message: "Failed to fetch user summary" });
    }
  });

  // Banking demo routes (simplified for now)
  app.post('/api/bank-accounts/connect-plaid', (req, res) => {
    res.json({ 
      message: 'Demo bank accounts connected successfully',
      demo_mode: true,
      linkToken: 'demo-link-token-12345'
    });
  });

  app.get('/api/bank-accounts', (req, res) => {
    res.json([
      {
        id: 1,
        accountName: 'Demo Checking Account',
        accountType: 'checking',
        bankName: 'Demo Bank',
        accountNumber: '****1234',
        routingNumber: '****5678',
        balance: 2500.00,
        isActive: true,
        lastSynced: new Date().toISOString()
      },
      {
        id: 2,
        accountName: 'Demo Savings Account',
        accountType: 'savings',
        bankName: 'Demo Bank',
        accountNumber: '****9876',
        routingNumber: '****5678',
        balance: 8750.00,
        isActive: true,
        lastSynced: new Date().toISOString()
      }
    ]);
  });

  app.get('/api/bill-payments', (req, res) => {
    res.json([
      {
        id: 1,
        billName: 'Electric Bill',
        payeeWebsite: 'demo-electric.com',
        accountNumber: '****1234',
        isAutoPay: true,
        paymentAmount: 85.00,
        paymentDate: 15,
        nextPayment: '2025-08-15',
        status: 'active'
      }
    ]);
  });

  app.post('/api/bill-payments', (req, res) => {
    try {
      const { billName, payeeWebsite, accountNumber, paymentAmount, paymentDate, isAutoPay } = req.body;
      
      // Create a new bill payment record
      const newPayment = {
        id: Date.now(), // Simple ID generation for demo
        billName,
        payeeWebsite: payeeWebsite || 'demo-payee.com',
        accountNumber: accountNumber || '****1234',
        isAutoPay,
        paymentAmount,
        paymentDate,
        isActive: true,
        nextPayment: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0], // 30 days from now
        status: 'active'
      };
      
      res.json(newPayment);
    } catch (error) {
      console.error('Error creating bill payment:', error);
      res.status(400).json({ message: 'Failed to create bill payment' });
    }
  });

  // Payment limits endpoint
  app.get('/api/payment-limits', (req, res) => {
    res.json([
      {
        id: 1,
        limitType: 'daily',
        amount: 500,
        isActive: true
      },
      {
        id: 2,
        limitType: 'monthly',
        amount: 2000,
        isActive: true
      },
      {
        id: 3,
        limitType: 'per_transaction',
        amount: 1000,
        isActive: true
      }
    ]);
  });

  // Bank account sync endpoint
  app.post('/api/bank-accounts/:id/sync', (req, res) => {
    const accountId = parseInt(req.params.id);
    res.json({ 
      message: 'Account balance synced successfully',
      accountId,
      lastSynced: new Date().toISOString()
    });
  });

  // Bill payment toggle endpoint
  app.patch('/api/bill-payments/:id/toggle', (req, res) => {
    const paymentId = parseInt(req.params.id);
    const { isActive } = req.body;
    res.json({ 
      message: 'Auto pay setting updated',
      paymentId,
      isActive
    });
  });

  // Serve screenshot capture tool
  app.get("/screenshot-capture", (_req, res) => {
    res.sendFile(path.resolve("screenshot-capture.html"));
  });

  // Alternative route for screenshots
  app.get("/screenshots", (_req, res) => {
    res.sendFile(path.resolve("public/screenshot-capture.html"));
  });

  // Simple screenshot generator
  app.get("/screenshots-simple", (_req, res) => {
    res.sendFile(path.resolve("screenshot-simple.html"));
  });

  const httpServer = createServer(app);
  return httpServer;
}
