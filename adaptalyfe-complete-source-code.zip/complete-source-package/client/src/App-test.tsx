import React from 'react';
// import { QueryClient, QueryClientProvider } from "@tanstack/react-query";

// const queryClient = new QueryClient({
//   defaultOptions: {
//     queries: {
//       retry: false,
//       refetchOnWindowFocus: false,
//     },
//   },
// });

// Minimal test component
function TestComponent() {
  return (
    <div style={{ padding: '20px', fontFamily: 'Arial, sans-serif' }}>
      <h1>React Test App</h1>
      <p>This is a minimal React app with QueryClient but no complex routing.</p>
      <p>Current time: {new Date().toLocaleTimeString()}</p>
    </div>
  );
}

function App() {
  return (
    <TestComponent />
  );
}

export default App;