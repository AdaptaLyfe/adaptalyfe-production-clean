import React from 'react';

function App() {
  return (
    <div style={{ padding: '20px', fontFamily: 'Arial, sans-serif' }}>
      <h1>Minimal React App</h1>
      <p>This is a completely minimal React app with no external dependencies.</p>
      <p>If you see this, React is working correctly.</p>
    </div>
  );
}

export default App;