import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { Shield, User, Crown, Lock } from "lucide-react";
import { Link, useLocation } from "wouter";
import { apiRequest } from "@/lib/queryClient";
import Navigation from "@/components/navigation";

export default function DemoLogin() {
  const [, setLocation] = useLocation();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [adminKey, setAdminKey] = useState("");
  const [isAuthorized, setIsAuthorized] = useState(false);
  const { toast } = useToast();

  const demoAccounts = [
    {
      username: "admin",
      password: "demo2025",
      name: "Demo Administrator",
      role: "Admin",
      description: "Full access to all features, admin dashboard, and comprehensive demo data",
      icon: Crown,
      color: "bg-purple-100 text-purple-700 border-purple-300"
    },
    {
      username: "alex",
      password: "password",
      name: "Alex Chen",
      role: "User",
      description: "Standard user account with basic demo data for testing user features",
      icon: User,
      color: "bg-blue-100 text-blue-700 border-blue-300"
    }
  ];

  const handleAuthorizeAccess = () => {
    if (adminKey === "adaptalyfe-admin-2025") {
      setIsAuthorized(true);
      toast({
        title: "Access Authorized",
        description: "You can now view demo credentials",
      });
    } else {
      toast({
        title: "Access Denied",
        description: "Invalid admin key",
        variant: "destructive"
      });
    }
  };

  const handleQuickLogin = (account: typeof demoAccounts[0]) => {
    if (!isAuthorized) {
      toast({
        title: "Authorization Required",
        description: "Please enter the admin key to view credentials",
        variant: "destructive"
      });
      return;
    }
    
    // Show credentials only if authorized
    toast({
      title: "Demo Account Credentials",
      description: `Username: ${account.username} | Password: ${account.password}`,
    });
  };

  const handleLogin = async () => {
    if (!username || !password) {
      toast({
        title: "Missing Credentials",
        description: "Please enter both username and password",
        variant: "destructive"
      });
      return;
    }

    setIsSubmitting(true);
    
    try {
      await apiRequest("POST", "/api/demo-login", {
        username,
        password
      });

      toast({
        title: "Demo Login Successful!",
        description: `Welcome to Adaptalyfe demo`,
      });

      setLocation("/dashboard");
    } catch (error: any) {
      toast({
        title: "Login Failed",
        description: error.message || "Invalid credentials",
        variant: "destructive"
      });
    } finally {
      setIsSubmitting(false);
    }
  };



  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50">
      <Navigation />
      
      <main className="container mx-auto px-4 py-12">
        <div className="max-w-4xl mx-auto">
          {/* Header */}
          <div className="text-center mb-12">
            <h1 className="text-4xl font-bold text-gray-900 mb-4">
              Adaptalyfe Demo Access
            </h1>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Experience the full power of Adaptalyfe with our comprehensive demo accounts. 
              Choose admin access for complete feature demonstration or user access for the standard experience.
            </p>
          </div>

          {/* Admin Authorization */}
          {!isAuthorized && (
            <div className="mb-8">
              <Card className="border-red-200 bg-red-50">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-red-800">
                    <Lock className="h-5 w-5" />
                    Admin Authorization Required
                  </CardTitle>
                  <CardDescription className="text-red-700">
                    Enter the admin key to access demo credentials
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label htmlFor="adminKey">Admin Key</Label>
                    <Input
                      id="adminKey"
                      type="password"
                      value={adminKey}
                      onChange={(e) => setAdminKey(e.target.value)}
                      placeholder="Enter admin key"
                      className="mt-1"
                    />
                  </div>
                  <Button 
                    onClick={handleAuthorizeAccess}
                    className="w-full"
                    disabled={!adminKey}
                  >
                    Authorize Access
                  </Button>
                </CardContent>
              </Card>
            </div>
          )}

          <div className="grid lg:grid-cols-2 gap-8">
            {/* Demo Accounts */}
            <div className="space-y-6">
              <h2 className="text-2xl font-bold text-gray-900 mb-6">Available Demo Accounts</h2>
              
              {demoAccounts.map((account, index) => (
                <Card key={index} className="border-2 hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-3">
                      <div className={`p-2 rounded-lg ${account.color}`}>
                        <account.icon className="h-6 w-6" />
                      </div>
                      {account.name}
                      <Badge className={account.color}>{account.role}</Badge>
                    </CardTitle>
                    <CardDescription className="text-base">
                      {account.description}
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Button 
                      onClick={() => handleQuickLogin(account)}
                      className="w-full"
                      variant={account.role === "Admin" ? "default" : "outline"}
                      disabled={!isAuthorized}
                    >
                      {isAuthorized ? "Show Credentials" : "Authorization Required"}
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>

            {/* Login Form */}
            <div>
              <Card className="border-2">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Shield className="h-6 w-6" />
                    Demo Login
                  </CardTitle>
                  <CardDescription>
                    Enter credentials manually for secure demo access
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="username">Username</Label>
                      <Input
                        id="username"
                        type="text"
                        value={username}
                        onChange={(e) => setUsername(e.target.value)}
                        placeholder="Enter username"
                        className="mt-1"
                      />
                    </div>
                    <div>
                      <Label htmlFor="password">Password</Label>
                      <Input
                        id="password"
                        type="password"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        placeholder="Enter password"
                        className="mt-1"
                      />
                    </div>
                  </div>

                  <Button 
                    onClick={handleLogin} 
                    className="w-full" 
                    size="lg"
                    disabled={isSubmitting || !username || !password}
                  >
                    {isSubmitting ? "Logging in..." : "Login to Demo"}
                  </Button>

                  <div className="pt-6 border-t">
                    <h3 className="font-semibold text-gray-900 mb-3">Features Available:</h3>
                    <div className="space-y-2 text-sm text-gray-600">
                      <div className="flex items-center gap-2">
                        <Crown className="h-4 w-4 text-purple-600" />
                        <span><strong>Admin Account:</strong> Full access, admin dashboard, all premium features</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <User className="h-4 w-4 text-blue-600" />
                        <span><strong>User Account:</strong> Standard experience, basic features, user perspective</span>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Additional Info */}
          <div className="mt-12 text-center">
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-6">
              <h3 className="text-lg font-semibold text-blue-900 mb-2">Demo Environment Notice</h3>
              <p className="text-blue-700">
                This is a comprehensive demonstration environment. All data is simulated and reset periodically. 
                Use the admin account to showcase the full capabilities of SkillBridge to potential users, 
                healthcare providers, and stakeholders.
              </p>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}