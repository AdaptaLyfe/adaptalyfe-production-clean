import { useQuery, useMutation } from "@tanstack/react-query";
import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Calendar, DollarSign, Plus, CheckCircle, AlertCircle, CreditCard } from "lucide-react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { formatCurrency, getDaysUntilDue } from "@/lib/utils";
import type { Bill, BudgetEntry } from "@shared/schema";

const billSchema = z.object({
  name: z.string().min(1, "Bill name is required"),
  amount: z.number().min(0.01, "Amount must be greater than 0"),
  dueDate: z.number().min(1).max(31),
  category: z.string().min(1, "Category is required"),
  isRecurring: z.boolean(),
});

const budgetSchema = z.object({
  category: z.string().min(1, "Category is required"),
  amount: z.number().min(0.01, "Amount must be greater than 0"),
  type: z.enum(["income", "expense"]),
  description: z.string().optional(),
});

export default function Financial() {
  const { toast } = useToast();
  const [showBillDialog, setShowBillDialog] = useState(false);
  const [showBudgetDialog, setShowBudgetDialog] = useState(false);
  
  const { data: bills = [], isLoading: billsLoading } = useQuery<Bill[]>({
    queryKey: ["/api/bills"],
  });

  const { data: budgetEntries = [], isLoading: budgetLoading } = useQuery<BudgetEntry[]>({
    queryKey: ["/api/budget-entries"],
  });

  const billForm = useForm({
    resolver: zodResolver(billSchema),
    defaultValues: {
      name: "",
      amount: 0,
      dueDate: 1,
      category: "",
      isRecurring: true,
    },
  });

  const budgetForm = useForm({
    resolver: zodResolver(budgetSchema),
    defaultValues: {
      category: "",
      amount: 0,
      type: "expense" as const,
      description: "",
    },
  });

  // Check if we should auto-open expense dialog based on URL params
  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    if (urlParams.get('action') === 'add-expense') {
      setShowBudgetDialog(true);
      // Set the form to expense type by default
      budgetForm.setValue('type', 'expense');
      // Clear the URL params
      window.history.replaceState({}, '', window.location.pathname);
    }
  }, [budgetForm]);

  const createBillMutation = useMutation({
    mutationFn: async (data: z.infer<typeof billSchema>) => {
      return apiRequest("POST", "/api/bills", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/bills"] });
      setShowBillDialog(false);
      billForm.reset();
      toast({
        title: "Bill added!",
        description: "Your new bill has been added to the calendar.",
      });
    },
  });

  const createBudgetMutation = useMutation({
    mutationFn: async (data: z.infer<typeof budgetSchema>) => {
      return apiRequest("POST", "/api/budget-entries", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/budget-entries"] });
      setShowBudgetDialog(false);
      budgetForm.reset();
      toast({
        title: "Budget entry added!",
        description: "Your budget has been updated.",
      });
    },
  });

  const payBillMutation = useMutation({
    mutationFn: async ({ billId, isPaid }: { billId: number; isPaid: boolean }) => {
      return apiRequest("PATCH", `/api/bills/${billId}/pay`, { isPaid });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/bills"] });
      toast({
        title: "Bill updated!",
        description: "Payment status has been updated.",
      });
    },
  });

  const totalIncome = budgetEntries
    .filter(entry => entry.type === "income")
    .reduce((sum, entry) => sum + entry.amount, 0);
  
  const totalExpenses = budgetEntries
    .filter(entry => entry.type === "expense")
    .reduce((sum, entry) => sum + entry.amount, 0);

  const budgetUsed = totalIncome > 0 ? (totalExpenses / totalIncome) * 100 : 0;

  const upcomingBills = bills
    .filter(bill => !bill.isPaid)
    .sort((a, b) => getDaysUntilDue(a.dueDate) - getDaysUntilDue(b.dueDate));

  if (billsLoading || budgetLoading) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="animate-pulse space-y-6">
          <div className="h-8 bg-gray-200 rounded w-1/3"></div>
          <div className="grid md:grid-cols-3 gap-6">
            {[1, 2, 3].map((i) => (
              <div key={i} className="h-32 bg-gray-200 rounded"></div>
            ))}
          </div>
          <div className="h-64 bg-gray-200 rounded"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-4">Financial Management</h1>
        
        <div className="grid md:grid-cols-3 gap-6 mb-8">
          <Card className="border-t-4 border-bright-blue">
            <CardContent className="p-6">
              <div className="flex items-center space-x-3">
                <div className="w-12 h-12 bg-bright-blue rounded-lg flex items-center justify-center">
                  <DollarSign className="text-white" size={24} />
                </div>
                <div>
                  <p className="text-sm text-gray-600">Monthly Income</p>
                  <p className="text-2xl font-bold text-gray-900">{formatCurrency(totalIncome)}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-t-4 border-sunny-orange">
            <CardContent className="p-6">
              <div className="flex items-center space-x-3">
                <div className="w-12 h-12 bg-sunny-orange rounded-lg flex items-center justify-center">
                  <CreditCard className="text-white" size={24} />
                </div>
                <div>
                  <p className="text-sm text-gray-600">Total Expenses</p>
                  <p className="text-2xl font-bold text-gray-900">{formatCurrency(totalExpenses)}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-t-4 border-vibrant-green">
            <CardContent className="p-6">
              <div className="flex items-center space-x-3">
                <div className="w-12 h-12 bg-vibrant-green rounded-lg flex items-center justify-center">
                  <CheckCircle className="text-white" size={24} />
                </div>
                <div>
                  <p className="text-sm text-gray-600">Budget Status</p>
                  <p className="text-2xl font-bold text-gray-900">{Math.round(budgetUsed)}%</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <Card className="border-t-4 border-bright-blue mb-8">
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <span>Monthly Budget Overview</span>
              <div className="flex gap-2">
                <Dialog open={showBudgetDialog} onOpenChange={setShowBudgetDialog}>
                  <DialogTrigger asChild>
                    <Button 
                      className="bg-red-600 hover:bg-red-700 text-white"
                      onClick={() => budgetForm.setValue('type', 'expense')}
                    >
                      <Plus size={16} className="mr-2" />
                      Add Expense
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Add Budget Entry</DialogTitle>
                    </DialogHeader>
                    <Form {...budgetForm}>
                      <form onSubmit={budgetForm.handleSubmit((data) => createBudgetMutation.mutate(data))} className="space-y-4">
                        <FormField
                          control={budgetForm.control}
                          name="type"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Type</FormLabel>
                              <Select onValueChange={field.onChange} value={field.value}>
                                <FormControl>
                                  <SelectTrigger>
                                    <SelectValue placeholder="Select type" />
                                  </SelectTrigger>
                                </FormControl>
                                <SelectContent>
                                  <SelectItem value="income">Income</SelectItem>
                                  <SelectItem value="expense">Expense</SelectItem>
                                </SelectContent>
                              </Select>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <FormField
                          control={budgetForm.control}
                          name="category"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Category</FormLabel>
                              <FormControl>
                                <Input placeholder="e.g., Groceries, Gas, Shopping" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <FormField
                          control={budgetForm.control}
                          name="amount"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Amount</FormLabel>
                              <FormControl>
                                <Input 
                                  type="number" 
                                  step="0.01" 
                                  placeholder="0.00"
                                  {...field}
                                  onChange={e => field.onChange(parseFloat(e.target.value) || 0)}
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <FormField
                          control={budgetForm.control}
                          name="description"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Description (Optional)</FormLabel>
                              <FormControl>
                                <Input placeholder="Add a note..." {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <Button type="submit" className="w-full" disabled={createBudgetMutation.isPending}>
                          {createBudgetMutation.isPending ? "Adding..." : "Add Entry"}
                        </Button>
                      </form>
                    </Form>
                  </DialogContent>
                </Dialog>
                <Button 
                  className="bg-green-600 hover:bg-green-700 text-white"
                  onClick={() => {
                    budgetForm.setValue('type', 'income');
                    setShowBudgetDialog(true);
                  }}
                >
                  <Plus size={16} className="mr-2" />
                  Add Income
                </Button>
              </div>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="mb-4">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium text-gray-700">Budget Usage</span>
                <span className={`text-sm font-medium ${
                  budgetUsed < 80 ? "text-green-600" : budgetUsed < 100 ? "text-yellow-600" : "text-red-600"
                }`}>
                  {budgetUsed < 80 ? "On track" : budgetUsed < 100 ? "Watch spending" : "Over budget"}
                </span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-3">
                <div 
                  className={`h-3 rounded-full ${
                    budgetUsed < 80 ? "bg-bright-blue" : budgetUsed < 100 ? "bg-sunny-orange" : "bg-red-500"
                  }`}
                  style={{ width: `${Math.min(budgetUsed, 100)}%` }}
                ></div>
              </div>
              <p className="text-sm text-gray-600 mt-2">
                {formatCurrency(totalExpenses)} of {formatCurrency(totalIncome)} used this month
              </p>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card className="border-t-4 border-sunny-orange">
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <Calendar className="text-sunny-orange" size={24} />
              <span>Bill Calendar</span>
            </div>
            <Dialog open={showBillDialog} onOpenChange={setShowBillDialog}>
              <DialogTrigger asChild>
                <Button className="bg-sunny-orange hover:bg-sunny-orange">
                  <Plus size={16} className="mr-2" />
                  Add Bill
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Add New Bill</DialogTitle>
                </DialogHeader>
                <Form {...billForm}>
                  <form onSubmit={billForm.handleSubmit((data) => createBillMutation.mutate(data))} className="space-y-4">
                    <FormField
                      control={billForm.control}
                      name="name"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Bill Name</FormLabel>
                          <FormControl>
                            <Input placeholder="e.g., Phone Bill" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={billForm.control}
                      name="amount"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Amount</FormLabel>
                          <FormControl>
                            <Input 
                              type="number" 
                              step="0.01" 
                              placeholder="0.00" 
                              {...field}
                              onChange={e => field.onChange(parseFloat(e.target.value) || 0)}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={billForm.control}
                      name="dueDate"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Due Date (Day of Month)</FormLabel>
                          <FormControl>
                            <Input 
                              type="number" 
                              min="1" 
                              max="31" 
                              placeholder="15" 
                              {...field}
                              onChange={e => field.onChange(parseInt(e.target.value) || 1)}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={billForm.control}
                      name="category"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Category</FormLabel>
                          <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select category" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="utilities">Utilities</SelectItem>
                              <SelectItem value="entertainment">Entertainment</SelectItem>
                              <SelectItem value="transportation">Transportation</SelectItem>
                              <SelectItem value="healthcare">Healthcare</SelectItem>
                              <SelectItem value="other">Other</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <Button type="submit" className="w-full" disabled={createBillMutation.isPending}>
                      Add Bill
                    </Button>
                  </form>
                </Form>
              </DialogContent>
            </Dialog>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {upcomingBills.length === 0 ? (
              <p className="text-gray-600 text-center py-8">No upcoming bills</p>
            ) : (
              upcomingBills.map((bill) => {
                const daysUntil = getDaysUntilDue(bill.dueDate);
                const isUrgent = daysUntil <= 3;
                
                return (
                  <div key={bill.id} className={`flex items-center space-x-4 p-4 rounded-lg border-2 ${
                    isUrgent ? "bg-red-50 border-red-200" : "bg-gray-50 border-gray-200"
                  }`}>
                    <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                      isUrgent ? "bg-red-500" : "bg-sunny-orange"
                    }`}>
                      {isUrgent ? (
                        <AlertCircle className="text-white" size={20} />
                      ) : (
                        <Calendar className="text-white" size={20} />
                      )}
                    </div>
                    <div className="flex-1">
                      <h4 className="font-medium text-gray-900">{bill.name}</h4>
                      <p className="text-sm text-gray-600">
                        {formatCurrency(bill.amount)} • Due in {daysUntil} day{daysUntil !== 1 ? 's' : ''}
                      </p>
                    </div>
                    <Button
                      variant="outline"
                      size="sm"
                      className="border-vibrant-green text-vibrant-green hover:bg-green-50"
                      onClick={() => payBillMutation.mutate({ billId: bill.id, isPaid: true })}
                      disabled={payBillMutation.isPending}
                    >
                      Mark Paid
                    </Button>
                  </div>
                );
              })
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
