import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Settings, HelpCircle, Bell, Star, Volume2, Zap } from "lucide-react";
import { useDashboardLayout } from "@/hooks/useDashboardLayout";
import { useMoodRequirement } from "@/hooks/useMoodRequirement";
import WelcomeSection from "@/components/welcome-section";
import CustomizableQuickActions from "@/components/customizable-quick-actions";
import DailyTasksModule from "@/components/daily-tasks-module";
import FinancialModule from "@/components/financial-module";
import MoodModule from "@/components/mood-module";
import AchievementsModule from "@/components/achievements-module";
import CaregiverModule from "@/components/caregiver-module";
import AppointmentsModule from "@/components/appointments-module";
import DailySummary from "@/components/daily-summary";
import DashboardCustomizer from "@/components/dashboard-customizer";
import MoodRequirementModal from "@/components/mood-requirement-modal";
import AIChatbot from "@/components/ai-chatbot";
import HealthWellnessModule from "@/components/health-wellness-module";
import AccessibilitySettingsModule from "@/components/accessibility-settings-module";
import LifeSkillsModule from "@/components/life-skills-module";
import ProgressMotivationModule from "@/components/progress-motivation-module";
import PharmacyModule from "@/components/pharmacy-module";
import SafetyTransportationModule from "@/components/safety-transportation-module";
import LocationSafetyModule from "@/components/location-safety-module";
// Enhanced features components - temporarily commented out due to integration issues
// import { SmartNotifications } from "@/components/smart-notifications";
// import { AchievementSystem } from "@/components/achievement-system";
// import { VoiceCommands } from "@/components/voice-commands";
// import { SmartDashboardInsights } from "@/components/smart-dashboard-insights";
// import { EnhancedCommunication } from "@/components/enhanced-communication";
// import { PersonalizationEngine } from "@/components/personalization-engine";

export default function Dashboard() {
  const [showCustomizer, setShowCustomizer] = useState(false);
  const [showDemoHighlights, setShowDemoHighlights] = useState(false);
  const { modules } = useDashboardLayout();
  const { showMoodModal, closeMoodModal } = useMoodRequirement();

  // Component mapping for dynamic rendering
  const componentMap = {
    'DailySummary': DailySummary,
    'DailyTasksModule': DailyTasksModule,
    'MoodModule': MoodModule,
    'FinancialModule': FinancialModule,
    'AppointmentsModule': AppointmentsModule,
    'AchievementsModule': AchievementsModule,
    'CaregiverModule': CaregiverModule,
    'PharmacyModule': PharmacyModule,
    'SafetyTransportationModule': SafetyTransportationModule,
    'LocationSafetyModule': LocationSafetyModule,
    'HealthWellnessModule': HealthWellnessModule,
    'AccessibilitySettingsModule': AccessibilitySettingsModule,
    'LifeSkillsModule': LifeSkillsModule,
    'ProgressMotivationModule': ProgressMotivationModule,

  };

  const renderModule = (moduleId: string, component: string) => {
    const Component = componentMap[component as keyof typeof componentMap];
    if (!Component) return null;

    return <Component key={moduleId} />;
  };

  return (
    <>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {/* Header with customization button */}
        <div className="flex items-center justify-between mb-8">
          <div className="flex-1">
            <WelcomeSection />
          </div>
          <div className="flex items-center gap-2">
            <Button
              onClick={() => setShowDemoHighlights(true)}
              variant="outline"
              size="sm"
              className="flex items-center gap-2 border-blue-200 text-blue-700 hover:text-blue-800 hover:bg-blue-50"
            >
              <Star className="w-4 h-4" />
              Demo Mode
            </Button>
            <Button
              onClick={() => {
                // Trigger onboarding demo
                const event = new CustomEvent('showOnboardingDemo');
                window.dispatchEvent(event);
              }}
              variant="outline"
              size="sm"
              className="flex items-center gap-2 border-purple-200 text-purple-700 hover:text-purple-800 hover:bg-purple-50"
            >
              <HelpCircle className="w-4 h-4" />
              Start Tour
            </Button>
            <Button
              onClick={() => setShowCustomizer(true)}
              variant="outline"
              size="sm"
              className="flex items-center gap-2 border-border text-muted-foreground hover:text-foreground hover:bg-accent"
            >
              <Settings className="w-4 h-4" />
              Customize
            </Button>
          </div>
        </div>

        <CustomizableQuickActions />
        
        {/* Dynamic module rendering based on user preferences */}
        <div className="space-y-8 mt-8">
          {modules.map((module, index) => {
            if (!module.enabled) return null;

            // Special layout for daily summary - pair with next module if it's daily tasks
            if (module.id === 'daily-summary') {
              const nextModule = modules[index + 1];
              const isDailyTasksNext = nextModule && nextModule.id === 'daily-tasks' && nextModule.enabled;
              
              return (
                <div key={module.id} className="grid lg:grid-cols-3 gap-8">
                  <div className="lg:col-span-1">
                    {renderModule(module.id, module.component)}
                  </div>
                  <div className="lg:col-span-2">
                    {isDailyTasksNext ? renderModule(nextModule.id, nextModule.component) : null}
                  </div>
                </div>
              );
            }
            
            // Skip daily tasks if already rendered with daily summary
            if (module.id === 'daily-tasks' && index > 0) {
              const prevModule = modules[index - 1];
              if (prevModule && prevModule.id === 'daily-summary' && prevModule.enabled) {
                return null; // Already rendered
              }
            }

            // Premium modules get special styling
            const premiumModules = ['safety-transportation', 'location-safety', 'health-wellness', 'accessibility', 'life-skills', 'progress-motivation'];
            if (premiumModules.includes(module.id)) {
              return (
                <div key={module.id} className="mb-8 border-2 border-purple-200 rounded-lg bg-gradient-to-r from-purple-50 to-blue-50 p-1">
                  <div className="bg-white rounded-lg">
                    {renderModule(module.id, module.component)}
                  </div>
                </div>
              );
            }

            // Full-width layout for all other modules
            return (
              <div key={module.id} className="mb-8">
                {renderModule(module.id, module.component)}
              </div>
            );
          })}
        </div>

        {/* Enhanced Features Section */}
        <div className="space-y-8 mt-8">
          <div className="text-center mb-8">
            <h2 className="text-2xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
              Enhanced Features
            </h2>
            <p className="text-muted-foreground mt-2">Advanced tools to personalize your experience</p>
          </div>

          {/* Enhanced Features Grid */}
          <div className="grid lg:grid-cols-2 gap-8">
            {/* Smart Notifications */}
            <div className="border-2 border-blue-200 rounded-lg bg-gradient-to-r from-blue-50 to-purple-50 p-1">
              <div className="bg-white rounded-lg p-6">
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center">
                    <Bell className="w-4 h-4 text-blue-600" />
                  </div>
                  <h3 className="text-lg font-semibold">Smart Notifications</h3>
                </div>
                <p className="text-muted-foreground mb-4">
                  Intelligent reminder system with priority levels and customizable scheduling
                </p>
                <div className="text-sm text-green-600">✓ Integrated and Available</div>
              </div>
            </div>

            {/* Achievement System */}
            <div className="border-2 border-blue-200 rounded-lg bg-gradient-to-r from-blue-50 to-purple-50 p-1">
              <div className="bg-white rounded-lg p-6">
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-8 h-8 bg-yellow-100 rounded-lg flex items-center justify-center">
                    <Star className="w-4 h-4 text-yellow-600" />
                  </div>
                  <h3 className="text-lg font-semibold">Achievement System</h3>
                </div>
                <p className="text-muted-foreground mb-4">
                  Gamification features with points, levels, and progress tracking
                </p>
                <div className="text-sm text-green-600">✓ Integrated and Available</div>
              </div>
            </div>

            {/* Voice Commands */}
            <div className="border-2 border-blue-200 rounded-lg bg-gradient-to-r from-blue-50 to-purple-50 p-1">
              <div className="bg-white rounded-lg p-6">
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-8 h-8 bg-green-100 rounded-lg flex items-center justify-center">
                    <Volume2 className="w-4 h-4 text-green-600" />
                  </div>
                  <h3 className="text-lg font-semibold">Voice Commands</h3>
                </div>
                <p className="text-muted-foreground mb-4">
                  Hands-free navigation and task management with speech recognition
                </p>
                <div className="text-sm text-green-600">✓ Integrated and Available</div>
              </div>
            </div>

            {/* Smart Dashboard Insights */}
            <div className="border-2 border-blue-200 rounded-lg bg-gradient-to-r from-blue-50 to-purple-50 p-1">
              <div className="bg-white rounded-lg p-6">
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-8 h-8 bg-purple-100 rounded-lg flex items-center justify-center">
                    <Zap className="w-4 h-4 text-purple-600" />
                  </div>
                  <h3 className="text-lg font-semibold">Dashboard Insights</h3>
                </div>
                <p className="text-muted-foreground mb-4">
                  AI-powered personalized recommendations and behavior analysis
                </p>
                <div className="text-sm text-green-600">✓ Integrated and Available</div>
              </div>
            </div>

            {/* Enhanced Communication */}
            <div className="border-2 border-blue-200 rounded-lg bg-gradient-to-r from-blue-50 to-purple-50 p-1">
              <div className="bg-white rounded-lg p-6">
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-8 h-8 bg-teal-100 rounded-lg flex items-center justify-center">
                    <HelpCircle className="w-4 h-4 text-teal-600" />
                  </div>
                  <h3 className="text-lg font-semibold">Enhanced Communication</h3>
                </div>
                <p className="text-muted-foreground mb-4">
                  Improved messaging with emoji reactions and quick responses
                </p>
                <div className="text-sm text-green-600">✓ Integrated and Available</div>
              </div>
            </div>

            {/* Personalization Engine */}
            <div className="border-2 border-blue-200 rounded-lg bg-gradient-to-r from-blue-50 to-purple-50 p-1">
              <div className="bg-white rounded-lg p-6">
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-8 h-8 bg-pink-100 rounded-lg flex items-center justify-center">
                    <Settings className="w-4 h-4 text-pink-600" />
                  </div>
                  <h3 className="text-lg font-semibold">Personalization Engine</h3>
                </div>
                <p className="text-muted-foreground mb-4">
                  Adaptive UI themes and AI-powered customization based on usage patterns
                </p>
                <div className="text-sm text-green-600">✓ Integrated and Available</div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* AI Chatbot */}
      <AIChatbot />

      {/* Modals */}
      {showCustomizer && (
        <DashboardCustomizer onClose={() => setShowCustomizer(false)} />
      )}

      {/* Demo Highlights Modal */}
      {showDemoHighlights && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg max-w-4xl w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6 border-b">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-2xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                    SkillBridge Comprehensive Demo
                  </h2>
                  <p className="text-muted-foreground">Explore all available features for independence building</p>
                </div>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setShowDemoHighlights(false)}
                  className="text-muted-foreground"
                >
                  ✕
                </Button>
              </div>
            </div>
            
            <div className="p-6 space-y-6">
              {/* Core Features */}
              <div>
                <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
                  <div className="w-6 h-6 bg-green-100 rounded-full flex items-center justify-center">
                    <div className="w-3 h-3 bg-green-600 rounded-full"></div>
                  </div>
                  Core Features (Available Now)
                </h3>
                <div className="grid md:grid-cols-2 gap-4">
                  <div className="p-4 border rounded-lg">
                    <h4 className="font-medium">Daily Tasks Management</h4>
                    <p className="text-sm text-muted-foreground">Categorized tasks with completion tracking</p>
                  </div>
                  <div className="p-4 border rounded-lg">
                    <h4 className="font-medium">Mood Tracking</h4>
                    <p className="text-sm text-muted-foreground">Daily emotional wellness monitoring</p>
                  </div>
                  <div className="p-4 border rounded-lg">
                    <h4 className="font-medium">Financial Management</h4>
                    <p className="text-sm text-muted-foreground">Bill tracking and budget management</p>
                  </div>
                  <div className="p-4 border rounded-lg">
                    <h4 className="font-medium">Appointment Scheduling</h4>
                    <p className="text-sm text-muted-foreground">Medical and therapy appointments</p>
                  </div>
                  <div className="p-4 border rounded-lg">
                    <h4 className="font-medium">Meal Planning & Shopping</h4>
                    <p className="text-sm text-muted-foreground">Weekly meal plans with grocery lists</p>
                  </div>
                  <div className="p-4 border rounded-lg">
                    <h4 className="font-medium">Medication Management</h4>
                    <p className="text-sm text-muted-foreground">Pharmacy integration and refill tracking</p>
                  </div>
                </div>
              </div>

              {/* Premium Features */}
              <div>
                <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
                  <div className="w-6 h-6 bg-purple-100 rounded-full flex items-center justify-center">
                    <Star className="w-3 h-3 text-purple-600" />
                  </div>
                  Premium Features
                </h3>
                <div className="grid md:grid-cols-2 gap-4">
                  <div className="p-4 border-2 border-purple-200 rounded-lg bg-purple-50/50">
                    <h4 className="font-medium">Location & Safety</h4>
                    <p className="text-sm text-muted-foreground">GPS tracking with caregiver alerts</p>
                  </div>
                  <div className="p-4 border-2 border-purple-200 rounded-lg bg-purple-50/50">
                    <h4 className="font-medium">Visual Task Builder</h4>
                    <p className="text-sm text-muted-foreground">Step-by-step life skills tutorials</p>
                  </div>
                  <div className="p-4 border-2 border-purple-200 rounded-lg bg-purple-50/50">
                    <h4 className="font-medium">Academic Planner</h4>
                    <p className="text-sm text-muted-foreground">Class scheduling and assignment tracking</p>
                  </div>
                  <div className="p-4 border-2 border-purple-200 rounded-lg bg-purple-50/50">
                    <h4 className="font-medium">Smart Notifications</h4>
                    <p className="text-sm text-muted-foreground">Priority-based reminders with quiet hours</p>
                  </div>
                </div>
              </div>

              {/* Enhanced Features */}
              <div>
                <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
                  <div className="w-6 h-6 bg-blue-100 rounded-full flex items-center justify-center">
                    <Zap className="w-3 h-3 text-blue-600" />
                  </div>
                  Enhanced AI Features
                </h3>
                <div className="grid md:grid-cols-2 gap-4">
                  <div className="p-4 border-2 border-blue-200 rounded-lg bg-blue-50/50">
                    <h4 className="font-medium">AI Chatbot Assistant</h4>
                    <p className="text-sm text-muted-foreground">Personalized support and guidance</p>
                  </div>
                  <div className="p-4 border-2 border-blue-200 rounded-lg bg-blue-50/50">
                    <h4 className="font-medium">Voice Commands</h4>
                    <p className="text-sm text-muted-foreground">Hands-free operation with speech recognition</p>
                  </div>
                  <div className="p-4 border-2 border-blue-200 rounded-lg bg-blue-50/50">
                    <h4 className="font-medium">Smart Dashboard Insights</h4>
                    <p className="text-sm text-muted-foreground">AI-powered behavior pattern analysis</p>
                  </div>
                  <div className="p-4 border-2 border-blue-200 rounded-lg bg-blue-50/50">
                    <h4 className="font-medium">Personalization Engine</h4>
                    <p className="text-sm text-muted-foreground">Adaptive UI based on usage patterns</p>
                  </div>
                </div>
              </div>

              {/* Demo Data Summary */}
              <div className="p-4 bg-gray-50 rounded-lg">
                <h3 className="font-medium mb-2">Demo Data Included</h3>
                <div className="text-sm text-muted-foreground space-y-1">
                  <p>• Sample daily tasks with completion tracking</p>
                  <p>• Mock bills and budget entries for financial management</p>
                  <p>• Mood entries showing emotional wellness tracking</p>
                  <p>• Upcoming medical appointments</p>
                  <p>• Meal plans with shopping lists</p>
                  <p>• Medication records with refill reminders</p>
                  <p>• Emergency contacts and safety features</p>
                </div>
              </div>

              <div className="flex justify-center pt-4">
                <Button
                  onClick={() => setShowDemoHighlights(false)}
                  className="bg-gradient-to-r from-blue-600 to-purple-600 text-white"
                >
                  Explore Features
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}
      
      {/* Mood requirement modal disabled to prevent interface blocking */}
    </>
  );
}
