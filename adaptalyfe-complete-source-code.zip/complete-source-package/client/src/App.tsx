import React, { useState, useEffect, Suspense } from "react";
import { Switch, Route } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { AppWrapper } from "./components/app-wrapper";
import { RuntimeErrorHandler } from "./components/runtime-error-handler";
import { AppStatusIndicator } from "./components/app-status-indicator";
import { apiRequest } from "./lib/queryClient";
import SimpleNavigation from "@/components/simple-navigation";
import { SimpleOnboarding } from "@/components/simple-onboarding";
import { PageLoadingSkeleton } from "@/components/loading-skeleton";
import NotFound from "@/pages/not-found";
import Dashboard from "@/pages/dashboard";
import DailyTasks from "@/pages/daily-tasks";
import Financial from "@/pages/financial";
import MoodTracking from "@/pages/mood-tracking";
import Resources from "@/pages/resources";
import Caregiver from "@/pages/caregiver";
import MealShopping from "@/pages/meal-shopping";
import CalendarSimple from "@/pages/calendar-simple";
import Calendar from "@/pages/calendar";
import Pharmacy from "@/pages/pharmacy";
import Medical from "@/pages/medical";
import CaregiverDemo from "@/pages/caregiver-demo";
import CaregiverDashboard from "@/pages/caregiver-dashboard";
import CaregiverSetup from "@/pages/caregiver-setup";
import AcceptInvitation from "@/pages/accept-invitation";
import AcademicPlanner from "@/pages/academic-planner";
import TaskBuilder from "@/pages/task-builder";
import WearableDevices from "@/pages/wearable-devices";
import Pricing from "@/pages/pricing";
import CheckoutSimple from "@/pages/checkout-simple";
import AdminDashboard from "@/pages/admin-dashboard";
import TestCheckout from "@/pages/test-checkout";
import DemoLogin from "@/pages/demo-login";
import AdminDemo from "@/pages/admin-demo";
import BankingIntegration from "@/pages/banking-integration";
import Landing from "@/pages/landing";
import Register from "@/pages/register";
import Login from "@/pages/login";
import ErrorTest from "@/pages/error-test";
import MinimalTest from "@/pages/minimal-test";
import AIChatbot from "./components/ai-chatbot";
import EnhancedOnboarding from "./components/enhanced-onboarding";
import { ErrorBoundary } from "./components/error-boundary";



// Protected Route Component
function ProtectedRoute({ component: Component }: { component: React.ComponentType }) {
  const { data: user, isLoading, error } = useQuery({
    queryKey: ["/api/user"],
    retry: false,
  });

  if (isLoading) {
    return <PageLoadingSkeleton />;
  }

  if (error || !user) {
    return <Landing />;
  }

  return <Component />;
}

function Router() {
  const [showOnboarding, setShowOnboarding] = useState(false);

  // Listen for demo event
  useEffect(() => {
    const handleShowDemo = () => {
      setShowOnboarding(true);
    };
    
    window.addEventListener('showOnboardingDemo', handleShowDemo);
    return () => window.removeEventListener('showOnboardingDemo', handleShowDemo);
  }, []);

  const handleOnboardingComplete = () => {
    setShowOnboarding(false);
  };

  const handleOnboardingSkip = () => {
    setShowOnboarding(false);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-100 via-purple-50 to-pink-100 text-foreground overflow-x-hidden">
      <ErrorBoundary>
        <SimpleNavigation />
      </ErrorBoundary>
      
      <Switch>
        {/* Public routes */}
        <Route path="/admin-demo" component={AdminDemo} />
        <Route path="/register" component={Register} />
        <Route path="/login" component={Login} />
        <Route path="/demo-login" component={DemoLogin} />
        <Route path="/pricing" component={Pricing} />
        <Route path="/checkout" component={CheckoutSimple} />
        <Route path="/test-checkout" component={TestCheckout} />
        <Route path="/error-test" component={ErrorTest} />
        <Route path="/minimal-test" component={MinimalTest} />
        <Route path="/" component={Landing} />
        
        {/* Protected routes */}
        <Route path="/dashboard" component={() => <ProtectedRoute component={Dashboard} />} />
        <Route path="/daily-tasks" component={() => <ProtectedRoute component={DailyTasks} />} />
        <Route path="/financial" component={() => <ProtectedRoute component={Financial} />} />
        <Route path="/mood-tracking" component={() => <ProtectedRoute component={MoodTracking} />} />
        <Route path="/meal-shopping" component={() => <ProtectedRoute component={MealShopping} />} />
        <Route path="/calendar" component={() => <ProtectedRoute component={Calendar} />} />
        <Route path="/pharmacy" component={() => <ProtectedRoute component={Pharmacy} />} />
        <Route path="/medical" component={() => <ProtectedRoute component={Medical} />} />
        <Route path="/resources" component={() => <ProtectedRoute component={Resources} />} />
        <Route path="/caregiver" component={() => <ProtectedRoute component={Caregiver} />} />
        <Route path="/caregiver-demo" component={() => <ProtectedRoute component={CaregiverDemo} />} />
        <Route path="/caregiver-dashboard" component={() => <ProtectedRoute component={CaregiverDashboard} />} />
        <Route path="/caregiver-setup" component={() => <ProtectedRoute component={CaregiverSetup} />} />
        <Route path="/accept-invitation" component={() => <ProtectedRoute component={AcceptInvitation} />} />
        <Route path="/academic-planner" component={() => <ProtectedRoute component={AcademicPlanner} />} />
        <Route path="/task-builder" component={() => <ProtectedRoute component={TaskBuilder} />} />
        <Route path="/wearable-devices" component={() => <ProtectedRoute component={WearableDevices} />} />
        <Route path="/admin" component={() => <ProtectedRoute component={AdminDashboard} />} />
        <Route path="/banking" component={() => <ProtectedRoute component={BankingIntegration} />} />
        
        <Route component={NotFound} />
      </Switch>
      
      {/* AI Chatbot - only show for authenticated users */}
      <ErrorBoundary fallback={<div>{/* AI Chatbot temporarily disabled */}</div>}>
        <AuthenticatedComponent>
          <AIChatbot />
        </AuthenticatedComponent>
      </ErrorBoundary>
    </div>
  );
}

// Component to only show content for authenticated users
function AuthenticatedComponent({ children }: { children: React.ReactNode }) {
  const { data: user } = useQuery({
    queryKey: ["/api/user"],
    retry: false,
  });

  return user ? <>{children}</> : null;
}

function App() {
  console.log('App component rendering');
  
  return (
    <AppWrapper>
      <Router />
      <RuntimeErrorHandler />
    </AppWrapper>
  );
}

export default App;
