import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";

// Add global error handler
window.addEventListener('error', (event) => {
  console.error('Global error:', event.error);
  // Don't prevent default - let React handle it
});

window.addEventListener('unhandledrejection', (event) => {
  console.error('Unhandled promise rejection:', event.reason);
});

// Register Service Worker for PWA
if ('serviceWorker' in navigator) {
  navigator.serviceWorker.register('/sw.js')
    .then((registration) => {
      console.log('SW registered:', registration);
      
      // Listen for updates
      registration.addEventListener('updatefound', () => {
        const newWorker = registration.installing;
        if (newWorker) {
          newWorker.addEventListener('statechange', () => {
            if (newWorker.state === 'installed' && navigator.serviceWorker.controller) {
              // New version available, force update
              newWorker.postMessage({ type: 'SKIP_WAITING' });
              window.location.reload();
            }
          });
        }
      });
    })
    .catch((error) => {
      console.log('SW registration failed:', error);
    });
}

// Enhanced error recovery system
const initApp = () => {
  try {
    const container = document.getElementById("root");
    if (!container) {
      throw new Error("Root container not found");
    }
    
    const root = createRoot(container);
    root.render(<App />);
    
    // Check if app rendered successfully after a delay
    setTimeout(() => {
      const hasContent = container.children.length > 0;
      if (!hasContent) {
        showErrorRecovery();
      }
    }, 3000);
    
  } catch (error) {
    console.error('Failed to render app:', error);
    showErrorRecovery();
  }
};

const showErrorRecovery = () => {
  const container = document.getElementById("root");
  if (container) {
    container.innerHTML = `
      <div style="
        min-height: 100vh;
        background: linear-gradient(135deg, #dbeafe 0%, #faf5ff 50%, #fce7f3 100%);
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 20px;
        font-family: Arial, sans-serif;
      ">
        <div style="
          background: white;
          padding: 30px;
          border-radius: 10px;
          box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
          max-width: 400px;
          text-align: center;
        ">
          <h1 style="color: #dc2626; margin-bottom: 15px;">Development Mode Issue</h1>
          <p style="color: #6b7280; margin-bottom: 20px;">
            The development server is experiencing a runtime error loop. This is a known issue with the development environment.
          </p>
          <p style="color: #6b7280; margin-bottom: 20px; font-size: 14px;">
            The application works correctly in production mode.
          </p>
          <button 
            onclick="window.location.reload()" 
            style="
              background: #2563eb;
              color: white;
              padding: 10px 20px;
              border: none;
              border-radius: 5px;
              margin: 5px;
              cursor: pointer;
              font-size: 14px;
            "
          >
            Try Again
          </button>
          <button 
            onclick="window.location.href='/test-static.html'" 
            style="
              background: #f3f4f6;
              color: #374151;
              padding: 10px 20px;
              border: 1px solid #d1d5db;
              border-radius: 5px;
              margin: 5px;
              cursor: pointer;
              font-size: 14px;
            "
          >
            Static Test Page
          </button>
        </div>
      </div>
    `;
  }
};

initApp();
