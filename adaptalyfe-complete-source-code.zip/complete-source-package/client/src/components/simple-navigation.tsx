import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Menu, Home, CheckSquare, DollarSign, Heart, Calendar, ShoppingCart, Pill, Stethoscope, BookOpen, Users, GraduationCap, Building, AlertTriangle, Bell, BarChart3, UserPlus, CreditCard, LogOut } from "lucide-react";
import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Sheet, SheetContent, SheetTrigger, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { apiRequest } from "@/lib/queryClient";

export default function SimpleNavigation() {
  const [location] = useLocation();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const queryClient = useQueryClient();

  // Check user authentication
  const { data: user } = useQuery({
    queryKey: ["/api/user"],
    retry: false,
  });

  // Check caregiver access
  const { data: caregiverAccess } = useQuery({
    queryKey: ["/api/caregiver-access"],
    enabled: !!user,
  });

  const isCaregiver = caregiverAccess?.isCaregiver || false;

  // Logout mutation
  const logoutMutation = useMutation({
    mutationFn: async () => {
      await apiRequest("POST", "/api/logout");
    },
    onSuccess: () => {
      queryClient.clear();
      window.location.href = "/";
    },
  });

  const baseNavigationItems = [
    { href: "/", label: "Dashboard", icon: Home },
    { href: "/daily-tasks", label: "Daily Tasks", icon: CheckSquare },
    { href: "/financial", label: "Financial", icon: DollarSign },
    { href: "/banking", label: "Banking & Bill Pay", icon: CreditCard },
    { href: "/mood-tracking", label: "Mood Tracking", icon: Heart },
    { href: "/calendar", label: "Calendar", icon: Calendar },
    { href: "/meal-shopping", label: "Meals & Shopping", icon: ShoppingCart },
    { href: "/pharmacy", label: "Pharmacy", icon: Pill },
    { href: "/medical", label: "Medical", icon: Stethoscope },
    { href: "/resources", label: "Resources", icon: BookOpen },
    { href: "/caregiver", label: "Caregiver", icon: Users },
    { href: "/academic-planner", label: "Student", icon: GraduationCap },
    { href: "/task-builder", label: "Task Builder", icon: Building },
  ];

  // Add caregiver dashboard and setup only for authorized users
  const navigationItems = isCaregiver 
    ? [...baseNavigationItems, 
       { href: "/caregiver-dashboard", label: "Caregiver Dashboard", icon: BarChart3 },
       { href: "/caregiver-setup", label: "Caregiver Setup", icon: UserPlus }]
    : baseNavigationItems;

  // Don't show navigation menu for unauthenticated users on certain pages
  const publicPages = ["/", "/register", "/login", "/demo-login", "/pricing", "/checkout", "/test-checkout"];
  const isPublicPage = publicPages.includes(location);
  
  return (
    <nav className="bg-white shadow-sm border-b-4 border-blue-500 sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <Link href="/">
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
                <span className="text-white font-bold text-sm">AL</span>
              </div>
              <div>
                <h1 className="text-xl font-bold text-gray-900">Adaptalyfe</h1>
                <p className="text-xs text-gray-600">Grow with Guidance. Thrive with Confidence.</p>
              </div>
            </div>
          </Link>

          {user ? (
            <>
              {/* Desktop Navigation - Only show for authenticated users */}
              <div className="hidden lg:flex items-center space-x-2">
                {navigationItems.slice(0, 6).map((item) => {
                  const Icon = item.icon;
                  const isActive = location === item.href;
                  return (
                    <Link key={item.href} href={item.href}>
                      <Button 
                        variant={isActive ? "default" : "ghost"} 
                        size="sm"
                        className="touch-manipulation min-h-[44px]"
                      >
                        <Icon className="w-4 h-4 mr-1" />
                        <span className="hidden xl:inline">{item.label}</span>
                      </Button>
                    </Link>
                  );
                })}
                
                {/* Emergency Button */}
                <Link href="/resources">
                  <Button 
                    variant="destructive" 
                    size="sm"
                    className="touch-manipulation min-h-[44px] animate-pulse"
                  >
                    <AlertTriangle className="w-4 h-4 mr-1" />
                    <span className="hidden xl:inline">Emergency</span>
                  </Button>
                </Link>
                
                {/* Notifications */}
                <Button 
                  variant="ghost" 
                  size="sm"
                  className="touch-manipulation min-h-[44px] p-2 relative"
                >
                  <Bell className="w-4 h-4" />
                </Button>
                
                {/* User Profile & Logout */}
                <div className="flex items-center space-x-2 ml-4">
                  <span className="text-sm text-gray-700">Hi, {user.name}</span>
                  <Button 
                    variant="ghost" 
                    size="sm"
                    onClick={() => logoutMutation.mutate()}
                    className="touch-manipulation min-h-[44px]"
                  >
                    <LogOut className="w-4 h-4 mr-1" />
                    <span className="hidden xl:inline">Logout</span>
                  </Button>
                </div>
              </div>

              {/* Mobile Menu - Only show for authenticated users */}
              <Sheet open={isMobileMenuOpen} onOpenChange={setIsMobileMenuOpen}>
                <SheetTrigger asChild>
                  <Button 
                    variant="ghost" 
                    size="sm"
                    className="touch-manipulation min-h-[44px] p-2 lg:hidden"
                  >
                    <Menu className="w-5 h-5" />
                    <span className="sr-only">Open menu</span>
                  </Button>
                </SheetTrigger>
                <SheetContent side="right" className="w-full sm:w-80 h-full overflow-y-auto bg-white text-gray-900">
                  <SheetHeader>
                    <SheetTitle className="text-gray-900">Adaptalyfe Menu</SheetTitle>
                  </SheetHeader>
                  <div className="mt-6 space-y-3 pb-20">
                    {navigationItems.map((item) => {
                      const Icon = item.icon;
                      const isActive = location === item.href;
                      return (
                        <Link 
                          key={item.href} 
                          href={item.href}
                          onClick={() => setIsMobileMenuOpen(false)}
                        >
                          <Button 
                            variant={isActive ? "default" : "ghost"} 
                            className="w-full justify-start touch-manipulation min-h-[44px] text-gray-900 hover:bg-gray-100"
                          >
                            <Icon className="w-5 h-5 mr-3" />
                            {item.label}
                          </Button>
                        </Link>
                      );
                    })}
                    
                    {/* Emergency Button */}
                    <Link 
                      href="/resources"
                      onClick={() => setIsMobileMenuOpen(false)}
                    >
                      <Button 
                        variant="destructive" 
                        className="w-full justify-start touch-manipulation min-h-[44px] animate-pulse bg-red-600 text-white hover:bg-red-700"
                      >
                        <AlertTriangle className="w-5 h-5 mr-3" />
                        Emergency
                      </Button>
                    </Link>
                    
                    {/* User Profile & Logout in Mobile */}
                    <div className="border-t pt-4 mt-4">
                      <div className="text-sm text-gray-700 mb-2">Hi, {user.name}</div>
                      <Button 
                        variant="ghost" 
                        className="w-full justify-start touch-manipulation min-h-[44px] text-gray-900 hover:bg-gray-100"
                        onClick={() => {
                          setIsMobileMenuOpen(false);
                          logoutMutation.mutate();
                        }}
                      >
                        <LogOut className="w-5 h-5 mr-3" />
                        Logout
                      </Button>
                    </div>
                  </div>
                </SheetContent>
              </Sheet>
            </>
          ) : (
            /* Public Navigation - Show login/register for unauthenticated users */
            <div className="flex items-center space-x-2">
              <Link href="/login">
                <Button variant="ghost" size="sm">
                  Login
                </Button>
              </Link>
              <Link href="/register">
                <Button variant="default" size="sm">
                  Get Started
                </Button>
              </Link>
            </div>
          )}
        </div>
      </div>
    </nav>
  );
}