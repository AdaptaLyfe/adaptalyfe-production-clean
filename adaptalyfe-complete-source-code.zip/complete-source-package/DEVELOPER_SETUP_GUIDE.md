# AdaptaLyfe Complete Source Code - Developer Setup Guide

## Project Overview
This is the complete source code for AdaptaLyfe, a comprehensive independence-building mobile app for teens and adults with neurodevelopmental disorders. The application is currently a fully functional PWA that needs to be converted to native iOS and Android apps.

## Live Application
- **URL**: https://adaptalyfe.replit.app (or current Replit URL)
- **Demo Access**: Admin key "adaptalyfe-admin-2025" via footer link
- **Status**: Production-ready with working payments

## Source Code Structure

```
complete-source-package/
├── client/                     # React frontend application
│   ├── src/
│   │   ├── components/         # UI components
│   │   ├── pages/             # Application pages
│   │   ├── hooks/             # Custom React hooks
│   │   ├── lib/               # Utility libraries
│   │   ├── App.tsx            # Main application component
│   │   └── main.tsx           # Application entry point
│   ├── public/                # Static assets
│   │   ├── manifest.json      # PWA manifest
│   │   ├── sw.js              # Service worker
│   │   └── icon-*.png         # App icons
│   └── index.html             # HTML template
├── server/                    # Express.js backend
│   ├── index.ts               # Server entry point
│   ├── routes.ts              # API routes
│   ├── storage.ts             # Data storage layer
│   └── db.ts                  # Database configuration
├── shared/                    # Shared TypeScript schemas
│   └── schema.ts              # Database and API schemas
├── package.json               # Dependencies and scripts
├── tsconfig.json              # TypeScript configuration
├── vite.config.ts             # Vite build configuration
├── tailwind.config.ts         # Tailwind CSS configuration
├── capacitor.config.ts        # Capacitor mobile configuration
├── eas.json                   # Expo build configuration
└── iOS certificates/          # Apple signing certificates
```

## Technology Stack

### Frontend
- **React 18** with TypeScript
- **Vite** for build tooling
- **Tailwind CSS** for styling
- **Radix UI** for accessible components
- **React Query** for state management
- **Wouter** for routing
- **React Hook Form** for forms

### Backend
- **Express.js** with TypeScript
- **PostgreSQL** database
- **Drizzle ORM** for database operations
- **Stripe** for payment processing
- **OpenAI API** for AI chatbot

### Mobile (Target)
- **Capacitor** for native mobile conversion
- **iOS** and **Android** native features
- **Push notifications**
- **Camera access**
- **Location services**

## Prerequisites

### Development Environment
- **Node.js 18+** 
- **npm** or **yarn**
- **PostgreSQL** database
- **Git**

### For iOS Development
- **macOS** with Xcode
- **Apple Developer Account** (already set up)
- **iOS signing certificates** (included in package)

### For Android Development
- **Android Studio**
- **Google Play Developer Account**
- **Android SDK**

## Environment Variables Required

Create a `.env` file with these variables:

```bash
# Database
DATABASE_URL=postgresql://username:password@host:port/database

# Stripe Payment Processing
STRIPE_SECRET_KEY=sk_test_...
VITE_STRIPE_PUBLIC_KEY=pk_test_...

# OpenAI for AI Assistant
OPENAI_API_KEY=sk-...

# Session Security
SESSION_SECRET=your-session-secret-key
```

## Setup Instructions

### 1. Install Dependencies
```bash
cd complete-source-package
npm install
```

### 2. Database Setup
```bash
# Push database schema
npm run db:push

# (Optional) View database in browser
npm run db:studio
```

### 3. Development Server
```bash
# Start both frontend and backend
npm run dev
```

### 4. Build for Production
```bash
# Build frontend
npm run build

# Start production server
npm start
```

## Mobile App Conversion Process

### Phase 1: Setup Capacitor
```bash
# Install Capacitor
npm install @capacitor/core @capacitor/cli

# Initialize Capacitor (already configured)
npx cap init

# Add iOS platform
npx cap add ios

# Add Android platform
npx cap add android
```

### Phase 2: Configure Native Features
```bash
# Install required plugins
npm install @capacitor/camera @capacitor/push-notifications @capacitor/geolocation @capacitor/local-notifications

# Sync with native projects
npx cap sync
```

### Phase 3: iOS Development
```bash
# Open in Xcode
npx cap open ios

# Configure signing with provided certificates:
# - ios_distribution.cer
# - Adaptalyfe_Distribution.p12 (password: adaptalyfe2025)
# - AdaptaLyfe_App_Store_Distribution (3).mobileprovision
```

### Phase 4: Android Development
```bash
# Open in Android Studio
npx cap open android

# Configure signing and build
```

## Key Features to Preserve

### Core Functionality
- ✅ User authentication and profiles
- ✅ Daily task management with visual breakdowns
- ✅ Mood tracking and wellness features
- ✅ Emergency contact system
- ✅ Caregiver communication tools
- ✅ Payment processing (Stripe integration)
- ✅ AI assistant (AdaptAI)
- ✅ Academic planning tools
- ✅ Medical information management
- ✅ Banking integration

### Accessibility Features
- ✅ High contrast mode
- ✅ Large text options
- ✅ Screen reader compatibility
- ✅ Touch targets (44px minimum)
- ✅ Keyboard navigation
- ✅ Voice commands support

### Mobile-Specific Features to Implement
- 📱 Push notifications for medication reminders
- 📱 Camera integration for photo documentation
- 📱 GPS location services for safety features
- 📱 Offline functionality with data sync
- 📱 Biometric authentication
- 📱 Native sharing capabilities

## App Store Information

### iOS App Store
- **Bundle ID**: com.adaptalyfe.app
- **App Name**: AdaptaLyfe
- **Category**: Medical
- **Age Rating**: 4+
- **Price**: Free with in-app purchases

### Google Play Store
- **Package Name**: com.adaptalyfe.app
- **App Name**: AdaptaLyfe
- **Category**: Medical
- **Content Rating**: Everyone

### In-App Purchases
- Basic Plan: $4.99/month
- Premium Plan: $12.99/month
- Family Plan: $24.99/month

## Testing Checklist

### Functionality Tests
- [ ] User registration and login
- [ ] All navigation menus work
- [ ] Task creation and completion
- [ ] Payment processing
- [ ] AI chatbot responses
- [ ] Emergency contact access
- [ ] Offline functionality
- [ ] Data synchronization

### Accessibility Tests
- [ ] Screen reader navigation
- [ ] High contrast mode
- [ ] Large text scaling
- [ ] Touch target accessibility
- [ ] Keyboard navigation

### Platform-Specific Tests
- [ ] iOS: Health app integration
- [ ] iOS: Siri shortcuts
- [ ] Android: Adaptive icons
- [ ] Android: Google Assistant
- [ ] Both: Push notifications
- [ ] Both: Camera functionality
- [ ] Both: Location services

## Deployment Pipeline

### Continuous Integration
The `codemagic.yaml` file is configured for automated builds:
- Builds on code commits
- Runs tests automatically
- Generates signed builds
- Deploys to app stores

### Manual Deployment
1. Build and test locally
2. Create signed builds
3. Upload to App Store Connect / Google Play Console
4. Submit for review

## Support and Documentation

### API Documentation
- Backend API endpoints are documented in `server/routes.ts`
- Database schema is defined in `shared/schema.ts`
- Frontend components are in `client/src/components/`

### Troubleshooting
- Check console logs for JavaScript errors
- Verify environment variables are set
- Ensure database connection is working
- Test API endpoints individually

## Contact Information
- **Original Developer**: [Your contact information]
- **Live Application**: https://adaptalyfe.replit.app
- **Support Email**: [Your support email]

## Success Criteria
- [ ] Successfully builds for iOS and Android
- [ ] All features work in native environment
- [ ] Passes app store review guidelines
- [ ] Payment processing functions correctly
- [ ] Accessibility features remain intact
- [ ] Published to both app stores

This source code package contains a fully functional, production-ready application. The web version is currently live and working perfectly with integrated payments and all features tested by users.