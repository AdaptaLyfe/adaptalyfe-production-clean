// Mobile-optimized authentication utilities
export const AuthUtils = {
  // Check if user is logged in
  isAuthenticated(): boolean {
    return !!localStorage.getItem('authToken') || !!sessionStorage.getItem('authToken');
  },

  // Get current user from session
  getCurrentUser() {
    try {
      const user = localStorage.getItem('currentUser') || sessionStorage.getItem('currentUser');
      return user ? JSON.parse(user) : null;
    } catch (error) {
      console.error('Error parsing user data:', error);
      return null;
    }
  },

  // Store auth token
  setAuthToken(token: string, remember = false) {
    if (remember) {
      localStorage.setItem('authToken', token);
    } else {
      sessionStorage.setItem('authToken', token);
    }
  },

  // Store current user data
  setCurrentUser(user: any, remember = false) {
    const userStr = JSON.stringify(user);
    if (remember) {
      localStorage.setItem('currentUser', userStr);
    } else {
      sessionStorage.setItem('currentUser', userStr);
    }
  },

  // Clear all auth data
  clearAuth() {
    localStorage.removeItem('authToken');
    localStorage.removeItem('currentUser');
    sessionStorage.removeItem('authToken');
    sessionStorage.removeItem('currentUser');
  },

  // Get auth headers for API requests
  getAuthHeaders() {
    const token = localStorage.getItem('authToken') || sessionStorage.getItem('authToken');
    return token ? { Authorization: `Bearer ${token}` } : {};
  },

  // Mobile-friendly logout
  logout() {
    this.clearAuth();
    // For mobile app, don't redirect - let the component handle navigation
    if (typeof window !== 'undefined' && !window.location.href.includes('capacitor://')) {
      window.location.href = '/login';
    }
  },

  // Check if running in mobile app
  isMobileApp(): boolean {
    return typeof window !== 'undefined' && (
      window.location.href.includes('capacitor://') || 
      window.location.href.includes('file://') ||
      navigator.userAgent.includes('Adaptalyfe')
    );
  },

  // Handle mobile deep links
  handleMobileAuth(token?: string, user?: any) {
    if (this.isMobileApp() && token && user) {
      this.setAuthToken(token, true);
      this.setCurrentUser(user, true);
      return true;
    }
    return false;
  }
};