import { onRequest } from 'firebase-functions/v2/https';
import { setGlobalOptions } from 'firebase-functions/v2';
import admin from 'firebase-admin';
import express from 'express';
import cors from 'cors';

// Initialize Firebase Admin
admin.initializeApp();

// Set global options
setGlobalOptions({ maxInstances: 10 });

// Create Express app
const app = express();

// Middleware
app.use(cors({ origin: true }));
app.use(express.json());

// Health check endpoint
app.get('/health', (req, res) => {
  res.json({ status: 'healthy', timestamp: new Date().toISOString() });
});

// User management endpoints
app.post('/users', async (req, res) => {
  try {
    const { email, password, displayName, role = 'user' } = req.body;
    
    const user = await admin.auth().createUser({
      email,
      password,
      displayName,
    });

    // Set custom claims for role-based access
    await admin.auth().setCustomUserClaims(user.uid, { role });

    // Create user document in Firestore
    await admin.firestore().collection('users').doc(user.uid).set({
      email,
      displayName,
      role,
      createdAt: admin.firestore.FieldValue.serverTimestamp(),
      isActive: true
    });

    res.json({ uid: user.uid, message: 'User created successfully' });
  } catch (error: any) {
    console.error('Error creating user:', error);
    res.status(500).json({ error: error.message });
  }
});

// Tasks endpoints
app.get('/users/:userId/tasks', async (req, res) => {
  try {
    const { userId } = req.params;
    
    const tasksRef = admin.firestore()
      .collection('tasks')
      .doc(userId)
      .collection('userTasks');
    
    const snapshot = await tasksRef.orderBy('createdAt', 'desc').get();
    const tasks = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
    
    res.json(tasks);
  } catch (error: any) {
    console.error('Error fetching tasks:', error);
    res.status(500).json({ error: error.message });
  }
});

app.post('/users/:userId/tasks', async (req, res) => {
  try {
    const { userId } = req.params;
    const taskData = {
      ...req.body,
      userId,
      createdAt: admin.firestore.FieldValue.serverTimestamp(),
      updatedAt: admin.firestore.FieldValue.serverTimestamp()
    };
    
    const docRef = await admin.firestore()
      .collection('tasks')
      .doc(userId)
      .collection('userTasks')
      .add(taskData);
    
    res.json({ id: docRef.id, message: 'Task created successfully' });
  } catch (error: any) {
    console.error('Error creating task:', error);
    res.status(500).json({ error: error.message });
  }
});

// Mood tracking endpoints
app.get('/users/:userId/mood-entries', async (req, res) => {
  try {
    const { userId } = req.params;
    const { startDate, endDate } = req.query;
    
    let query = admin.firestore()
      .collection('moodEntries')
      .doc(userId)
      .collection('entries')
      .orderBy('date', 'desc');
    
    if (startDate && endDate) {
      query = query
        .where('date', '>=', new Date(startDate as string))
        .where('date', '<=', new Date(endDate as string));
    }
    
    const snapshot = await query.limit(50).get();
    const entries = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
    
    res.json(entries);
  } catch (error: any) {
    console.error('Error fetching mood entries:', error);
    res.status(500).json({ error: error.message });
  }
});

// Caregiver connections
app.post('/caregiver-connections', async (req, res) => {
  try {
    const { userId, caregiverId, relationship, permissions } = req.body;
    
    const connectionData = {
      userId,
      caregiverId,
      relationship,
      permissions: permissions || ['view_tasks', 'view_mood'],
      status: 'pending',
      createdAt: admin.firestore.FieldValue.serverTimestamp()
    };
    
    const docRef = await admin.firestore()
      .collection('caregiverConnections')
      .add(connectionData);
    
    res.json({ id: docRef.id, message: 'Caregiver connection created' });
  } catch (error: any) {
    console.error('Error creating caregiver connection:', error);
    res.status(500).json({ error: error.message });
  }
});

// Admin endpoints
app.get('/admin/users', async (req, res) => {
  try {
    // Verify admin role (you'll implement this based on your auth)
    const usersSnapshot = await admin.firestore().collection('users').get();
    const users = usersSnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
    
    res.json(users);
  } catch (error: any) {
    console.error('Error fetching users:', error);
    res.status(500).json({ error: error.message });
  }
});

// Export the Express app as a Firebase Function
export const api = onRequest(app);