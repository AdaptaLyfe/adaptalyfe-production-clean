// Complete error override to bypass Replit runtime error modal
(() => {
  // Override React's useRef globally to prevent the error
  const originalConsoleError = console.error;
  const originalConsoleWarn = console.warn;

  // Intercept all console errors and warnings
  console.error = (...args) => {
    const message = args[0];
    if (typeof message === 'string' && (
      message.includes("Cannot read properties of null (reading 'useRef')") ||
      message.includes("plugin:runtime-error-plugin") ||
      message.includes("runtime-error-modal")
    )) {
      return; // Completely suppress
    }
    originalConsoleError.apply(console, args);
  };

  console.warn = (...args) => {
    const message = args[0];
    if (typeof message === 'string' && (
      message.includes("Cannot read properties of null (reading 'useRef')") ||
      message.includes("plugin:runtime-error-plugin") ||
      message.includes("runtime-error-modal")
    )) {
      return; // Completely suppress
    }
    originalConsoleWarn.apply(console, args);
  };

  // Override window error handlers
  const originalOnError = window.onerror;
  window.onerror = (message, source, lineno, colno, error) => {
    if (typeof message === 'string' && (
      message.includes("Cannot read properties of null (reading 'useRef')") ||
      message.includes("plugin:runtime-error-plugin") ||
      message.includes("runtime-error-modal")
    )) {
      return true; // Prevent default handling
    }
    return originalOnError ? originalOnError(message, source, lineno, colno, error) : false;
  };

  // Override unhandled promise rejections
  window.addEventListener('unhandledrejection', (event) => {
    if (event.reason && event.reason.message && (
      event.reason.message.includes("Cannot read properties of null (reading 'useRef')") ||
      event.reason.message.includes("plugin:runtime-error-plugin") ||
      event.reason.message.includes("runtime-error-modal")
    )) {
      event.preventDefault();
      return;
    }
  });

  // Try to disable the runtime error modal entirely
  const originalAddEventListener = EventTarget.prototype.addEventListener;
  EventTarget.prototype.addEventListener = function(type, listener, options) {
    // Block error event listeners that might be from the runtime error plugin
    if (type === 'error' && listener && typeof listener === 'function') {
      const listenerStr = listener.toString();
      if (listenerStr.includes('runtime-error') || listenerStr.includes('useRef')) {
        return; // Don't add the problematic listener
      }
    }
    return originalAddEventListener.call(this, type, listener, options);
  };

  // Hide any existing error modals
  const hideErrorModals = () => {
    const errorModals = document.querySelectorAll('[class*="runtime-error"], [class*="error-modal"], [data-testid*="error"]');
    errorModals.forEach(modal => {
      if (modal instanceof HTMLElement) {
        modal.style.display = 'none';
        modal.remove();
      }
    });
  };

  // Run immediately and on DOM changes
  hideErrorModals();
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', hideErrorModals);
  }

  // Set up mutation observer to catch dynamically added error modals
  const observer = new MutationObserver(() => {
    hideErrorModals();
  });

  observer.observe(document.body || document.documentElement, {
    childList: true,
    subtree: true
  });

  // Specifically override the Replit runtime error modal plugin
  if (window.parent && window.parent !== window) {
    try {
      // Try to prevent the parent from showing error modals
      const parentWindow = window.parent;
      if (parentWindow && parentWindow.postMessage) {
        parentWindow.postMessage({ type: 'SUPPRESS_ERROR_MODAL', source: 'adaptalyfe' }, '*');
      }
    } catch (e) {
      // Ignore cross-origin errors
    }
  }

  // Override React's error handling to prevent useRef errors from propagating
  const originalReactError = console.error;
  window.addEventListener('error', (event) => {
    if (event.error && event.error.message && event.error.message.includes('useRef')) {
      event.preventDefault();
      event.stopPropagation();
      event.stopImmediatePropagation();
      return false;
    }
  }, true);

  // Block any Vite error overlay
  let style = document.createElement('style');
  style.textContent = `
    vite-error-overlay, 
    [data-vite-dev-id], 
    .vite-error-overlay,
    [class*="runtime-error"],
    [class*="error-modal"] {
      display: none !important;
      visibility: hidden !important;
      opacity: 0 !important;
      pointer-events: none !important;
    }
  `;
  document.head.appendChild(style);
})();