// Ultimate runtime error plugin blocker
(() => {
  // Block immediately on page load
  const blockRuntimeErrorPlugin = () => {
    // Override createHotContext if it exists
    if ((window as any).createHotContext) {
      (window as any).createHotContext = () => ({
        send: () => {}, // Do nothing
        dispose: () => {},
        invalidate: () => {},
        decline: () => {},
        accept: () => {}
      });
    }

    // Block hot module replacement context
    if ((window as any).__vite_plugin_runtime_error_hot) {
      delete (window as any).__vite_plugin_runtime_error_hot;
    }

    // Remove any existing runtime error scripts
    const scripts = document.querySelectorAll('script');
    scripts.forEach(script => {
      if (script.textContent && script.textContent.includes('runtime-error-plugin')) {
        script.remove();
      }
    });

    // Block future runtime error scripts
    const observer = new MutationObserver((mutations) => {
      mutations.forEach((mutation) => {
        mutation.addedNodes.forEach((node) => {
          if (node.nodeType === 1) { // Element node
            const element = node as Element;
            if (element.tagName === 'SCRIPT') {
              const script = element as HTMLScriptElement;
              if (script.textContent && script.textContent.includes('runtime-error-plugin')) {
                script.remove();
              }
            }
          }
        });
      });
    });

    observer.observe(document.documentElement, {
      childList: true,
      subtree: true
    });
  };

  // Run immediately
  blockRuntimeErrorPlugin();

  // Also run when DOM is ready
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', blockRuntimeErrorPlugin);
  }

  // Block all error sending mechanisms
  const originalFetch = window.fetch;
  window.fetch = function(input: RequestInfo | URL, init?: RequestInit) {
    const url = typeof input === 'string' ? input : input.toString();
    if (url.includes('runtime-error') || url.includes('sendError')) {
      return Promise.resolve(new Response());
    }
    return originalFetch.call(this, input, init);
  };

  // Block WebSocket connections related to runtime errors
  const originalWebSocket = window.WebSocket;
  window.WebSocket = class extends WebSocket {
    constructor(url: string | URL, protocols?: string | string[]) {
      const urlStr = url.toString();
      if (urlStr.includes('runtime-error') || urlStr.includes('vite')) {
        // Create a fake WebSocket that does nothing
        super('wss://localhost/fake');
        this.close();
        return this;
      }
      super(url, protocols);
    }
  } as any;
})();