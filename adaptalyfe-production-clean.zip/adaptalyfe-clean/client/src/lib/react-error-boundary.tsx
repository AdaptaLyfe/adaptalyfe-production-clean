import React, { Component, ReactNode } from 'react';

interface Props {
  children: ReactNode;
}

interface State {
  hasError: boolean;
}

export class ReactErrorBoundary extends Component<Props, State> {
  constructor(props: Props) {
    super(props);
    this.state = { hasError: false };
  }

  static getDerivedStateFromError(error: Error): State {
    // Only suppress useRef-related errors, show others
    if (error.message && error.message.includes('useRef')) {
      return { hasError: false };
    }
    // Update state so the next render will show the fallback UI for other errors
    return { hasError: true };
  }

  componentDidCatch(error: Error, errorInfo: React.ErrorInfo) {
    // Suppress useRef errors completely
    if (error.message && error.message.includes('useRef')) {
      return; // Don't log or report useRef errors
    }
    
    // Log other errors for debugging
    console.log('Error caught by boundary:', error, errorInfo);
  }

  render() {
    if (this.state.hasError) {
      const isMobile = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
      
      // Fallback UI for non-useRef errors with mobile support
      return (
        <div style={{
          minHeight: '100vh',
          background: 'linear-gradient(to bottom right, #e0f2fe, #f3e8ff, #f0fdfa)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          padding: '1rem'
        }}>
          <div style={{
            textAlign: 'center',
            background: 'white',
            padding: '2rem',
            borderRadius: '0.5rem',
            boxShadow: '0 10px 15px rgba(0, 0, 0, 0.1)',
            maxWidth: isMobile ? '90vw' : '28rem',
            width: '100%'
          }}>
            <h2 style={{
              fontSize: '1.5rem',
              fontWeight: 'bold',
              color: '#dc2626',
              marginBottom: '1rem'
            }}>
              Something went wrong
            </h2>
            <p style={{
              color: '#4b5563',
              marginBottom: '1rem'
            }}>
              An error occurred while loading the app on your {isMobile ? 'mobile' : 'desktop'} device.
            </p>
            <button 
              onClick={() => window.location.reload()}
              style={{
                background: '#2563eb',
                color: 'white',
                padding: '0.75rem 1.5rem',
                borderRadius: '0.25rem',
                border: 'none',
                cursor: 'pointer',
                fontSize: '1rem'
              }}
            >
              Reload Page
            </button>
          </div>
        </div>
      );
    }
    
    return this.props.children;
  }
}