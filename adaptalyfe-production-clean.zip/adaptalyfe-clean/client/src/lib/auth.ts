// Mobile-optimized authentication utilities
export const AuthUtils = {
  // Check if device is mobile
  isMobileDevice(): boolean {
    return /Mobile|Android|iPhone|iPad|iPod|BlackBerry|Opera Mini/i.test(navigator.userAgent);
  },

  // Ensure session persistence on mobile
  async ensureSessionPersistence(): Promise<boolean> {
    try {
      // Attempt to verify session with server
      const response = await fetch('/api/user', {
        method: 'GET',
        credentials: 'include',
        headers: {
          'Cache-Control': 'no-cache',
          'Pragma': 'no-cache'
        }
      });
      
      console.log('Session verification response:', response.status);
      return response.ok;
    } catch (error) {
      console.error('Session verification failed:', error);
      return false;
    }
  },

  // Mobile-safe navigation with session preservation
  async navigateWithSessionCheck(path: string): Promise<void> {
    const isMobile = this.isMobileDevice();
    console.log('Navigating to:', path, 'Mobile:', isMobile);
    
    if (isMobile) {
      // For mobile, ensure session is valid before navigation
      const sessionValid = await this.ensureSessionPersistence();
      console.log('Session valid before navigation:', sessionValid);
      
      if (!sessionValid) {
        console.warn('Session invalid on mobile, redirecting to login');
        window.location.href = '/login';
        return;
      }
    }
    
    // Use pushState for client-side navigation without page reload
    window.history.pushState({}, '', path);
    
    // Dispatch a custom event to trigger route change
    window.dispatchEvent(new PopStateEvent('popstate'));
  }
};