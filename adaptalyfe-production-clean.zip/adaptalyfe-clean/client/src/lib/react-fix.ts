// Complete override to prevent runtime error plugin issues
(() => {
  // Completely disable the Vite runtime error plugin
  const originalScript = document.createElement;
  document.createElement = function(tagName: string, options?: ElementCreationOptions) {
    const element = originalScript.call(this, tagName, options);
    
    if (tagName.toLowerCase() === 'script') {
      const originalSetAttribute = element.setAttribute;
      element.setAttribute = function(name: string, value: string) {
        // Block any script that contains runtime-error-plugin
        if (name === 'src' && value.includes('runtime-error-plugin')) {
          return; // Don't set the src
        }
        return originalSetAttribute.call(this, name, value);
      };
      
      // Override textContent to prevent inline runtime error scripts
      Object.defineProperty(element, 'textContent', {
        set: function(value: string) {
          if (value && value.includes('runtime-error-plugin')) {
            return; // Don't set the content
          }
          Object.getOwnPropertyDescriptor(Element.prototype, 'textContent')?.set?.call(this, value);
        },
        get: function() {
          return Object.getOwnPropertyDescriptor(Element.prototype, 'textContent')?.get?.call(this);
        }
      });
    }
    
    return element;
  };

  // Block the specific runtime error event listeners
  const originalAddEventListener = EventTarget.prototype.addEventListener;
  EventTarget.prototype.addEventListener = function(type: string, listener: any, options?: any) {
    if (type === 'error' && listener && typeof listener === 'function') {
      const listenerStr = listener.toString();
      if (listenerStr.includes('sendError') || listenerStr.includes('runtime-error-plugin')) {
        return; // Don't add this listener
      }
    }
    
    if (type === 'unhandledrejection' && listener && typeof listener === 'function') {
      const listenerStr = listener.toString();
      if (listenerStr.includes('sendError') || listenerStr.includes('runtime-error-plugin')) {
        return; // Don't add this listener
      }
    }
    
    return originalAddEventListener.call(this, type, listener, options);
  };

  // Override window.hot if it exists (Vite HMR)
  if ((window as any).hot) {
    const originalSend = (window as any).hot.send;
    (window as any).hot.send = function(event: string, data: any) {
      if (event && event.includes('runtime-error-plugin')) {
        return; // Don't send runtime error events
      }
      return originalSend.call(this, event, data);
    };
  }
})();