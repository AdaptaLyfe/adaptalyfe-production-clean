const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-DcdpEx4p.js","assets/index-BKmqncYp.js","assets/index-Dz9kwIum.css"])))=>i.map(i=>d[i]);
import{r as p,_ as r}from"./index-BKmqncYp.js";const _=p("App",{web:()=>r(()=>import("./web-DcdpEx4p.js"),__vite__mapDeps([0,1,2])).then(e=>new e.AppWeb)});export{_ as App};
