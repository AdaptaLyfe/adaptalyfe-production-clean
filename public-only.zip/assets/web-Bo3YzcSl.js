import{b7 as n}from"./index-CwUJTS30.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};
