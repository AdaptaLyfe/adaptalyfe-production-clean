const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-Bo3YzcSl.js","assets/index-CwUJTS30.js","assets/index-Dz9kwIum.css"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-CwUJTS30.js";const n=r("SplashScreen",{web:()=>t(()=>import("./web-Bo3YzcSl.js"),__vite__mapDeps([0,1,2])).then(e=>new e.SplashScreenWeb)});export{n as SplashScreen};
