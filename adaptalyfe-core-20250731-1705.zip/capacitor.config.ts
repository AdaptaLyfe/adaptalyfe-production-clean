import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.adaptalyfe.app',
  appName: 'Adaptalyfe',
  webDir: 'dist/public',
  server: {
    androidScheme: 'https'
  }
};

export default config;
