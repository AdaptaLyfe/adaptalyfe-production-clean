import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { CheckCircle, Circle, Star, Plus, Clock } from "lucide-react";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { DailyTask } from "@shared/schema";

export default function DailyTasks() {
  const { toast } = useToast();
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [newTask, setNewTask] = useState({
    title: "",
    description: "",
    category: "personal_care",
    estimatedMinutes: 15,
    pointValue: 5
  });
  
  const { data: tasks = [], isLoading } = useQuery<DailyTask[]>({
    queryKey: ["/api/daily-tasks"],
  });

  const createTaskMutation = useMutation({
    mutationFn: async (taskData: any) => {
      return apiRequest("POST", "/api/daily-tasks", taskData);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/daily-tasks"] });
      setIsAddDialogOpen(false);
      setNewTask({ title: "", description: "", category: "personal_care", estimatedMinutes: 15, pointValue: 5 });
      toast({
        title: "Task created!",
        description: "New task added to your daily list",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to create task. Please try again.",
        variant: "destructive",
      });
    },
  });

  const toggleTaskMutation = useMutation({
    mutationFn: async ({ taskId, isCompleted, task }: { taskId: number; isCompleted: boolean; task?: any }) => {
      return apiRequest("PATCH", `/api/daily-tasks/${taskId}/complete`, { isCompleted });
    },
    onSuccess: (data, variables) => {
      queryClient.invalidateQueries({ queryKey: ["/api/daily-tasks"] });
      queryClient.invalidateQueries({ queryKey: ["/api/points/balance"] });
      
      const { isCompleted, task } = variables;
      let description = "Great job staying on track!";
      
      if (isCompleted && task && task.pointValue > 0) {
        description = `Excellent! You earned ${task.pointValue} points for completing this task!`;
      }
      
      toast({
        title: isCompleted ? "Task completed!" : "Task updated!",
        description,
      });
    },
  });

  const handleCreateTask = () => {
    if (!newTask.title.trim()) {
      toast({
        title: "Error",
        description: "Please enter a task title",
        variant: "destructive",
      });
      return;
    }
    createTaskMutation.mutate(newTask);
  };

  const completedTasks = tasks.filter(task => task.isCompleted).length;
  const totalTasks = tasks.length;
  const progressPercentage = totalTasks > 0 ? Math.round((completedTasks / totalTasks) * 100) : 0;

  const tasksByCategory = tasks.reduce((acc, task) => {
    if (!acc[task.category]) {
      acc[task.category] = [];
    }
    acc[task.category].push(task);
    return acc;
  }, {} as Record<string, DailyTask[]>);

  const categoryColors = {
    morning: "bg-sunny-orange",
    cooking: "bg-vibrant-green",
    organization: "bg-bright-blue",
    planning: "bg-happy-purple",
  };

  if (isLoading) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="animate-pulse space-y-6">
          <div className="h-8 bg-gray-200 rounded w-1/3"></div>
          <div className="h-32 bg-gray-200 rounded"></div>
          <div className="grid gap-6">
            {[1, 2, 3].map((i) => (
              <div key={i} className="h-64 bg-gray-200 rounded"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-4">Daily Tasks</h1>
        <Card className="border-t-4 border-vibrant-green">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="text-xl font-semibold text-gray-900">Today's Progress</h3>
                <p className="text-gray-600">{completedTasks} of {totalTasks} tasks completed</p>
              </div>
              <div className="text-right">
                <div className="text-3xl font-bold text-vibrant-green">{progressPercentage}%</div>
                <p className="text-sm text-gray-600">Complete</p>
              </div>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-3">
              <div 
                className="bg-vibrant-green h-3 rounded-full transition-all duration-300"
                style={{ width: `${progressPercentage}%` }}
              ></div>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-6">
        {Object.entries(tasksByCategory).map(([category, categoryTasks]) => (
          <Card key={category} className="border-t-4 border-gray-200">
            <CardHeader>
              <CardTitle className="flex items-center space-x-3">
                <div className={`w-8 h-8 ${categoryColors[category as keyof typeof categoryColors] || 'bg-gray-400'} rounded-lg`}></div>
                <span className="capitalize">{category} Tasks</span>
                <span className="text-sm font-normal text-gray-600">
                  ({categoryTasks.filter(t => t.isCompleted).length}/{categoryTasks.length})
                </span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {categoryTasks.map((task) => (
                  <div key={task.id} className="flex items-center space-x-4 p-4 bg-gray-50 rounded-lg">
                    <Button
                      variant="ghost"
                      size="sm"
                      className={`w-8 h-8 p-0 rounded-full flex items-center justify-center ${
                        task.isCompleted
                          ? "bg-vibrant-green hover:bg-vibrant-green"
                          : "bg-green-500 hover:bg-vibrant-green"
                      }`}
                      onClick={() => toggleTaskMutation.mutate({ 
                        taskId: task.id, 
                        isCompleted: !task.isCompleted,
                        task: task
                      })}
                      disabled={toggleTaskMutation.isPending}
                    >
                      {task.isCompleted ? (
                        <CheckCircle className="text-white" size={20} />
                      ) : (
                        <Circle className="text-white" size={20} />
                      )}
                    </Button>
                    <div className="flex-1">
                      <h4 className={`font-medium text-gray-900 ${task.isCompleted ? 'line-through' : ''}`}>
                        {task.title}
                      </h4>
                      <p className="text-sm text-gray-600">{task.description}</p>
                      <div className="flex items-center space-x-4 mt-1">
                        <div className="flex items-center space-x-1">
                          <Clock size={14} className="text-gray-400" />
                          <span className="text-xs text-gray-500">{task.estimatedMinutes} minutes</span>
                        </div>
                        {task.pointValue && task.pointValue > 0 && (
                          <div className="flex items-center space-x-1">
                            <Star size={14} className="text-yellow-500" />
                            <span className="text-xs text-yellow-600 font-medium">{task.pointValue} points</span>
                          </div>
                        )}
                      </div>
                    </div>
                    {task.isCompleted && (
                      <div className="w-10 h-10 bg-sunny-orange rounded-full flex items-center justify-center">
                        <Star className="text-white" size={20} />
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="mt-8 text-center">
        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <DialogTrigger asChild>
            <Button className="bg-vibrant-green hover:bg-green-600 text-black font-bold shadow-lg border border-green-700">
              <Plus size={20} className="mr-2 text-black" />
              <span className="text-black font-bold">Add New Task</span>
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>Add New Daily Task</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <Input
                placeholder="Task title"
                value={newTask.title}
                onChange={(e) => setNewTask({ ...newTask, title: e.target.value })}
              />
              <Textarea
                placeholder="Description (optional)"
                value={newTask.description}
                onChange={(e) => setNewTask({ ...newTask, description: e.target.value })}
              />
              <Select 
                value={newTask.category} 
                onValueChange={(value) => setNewTask({ ...newTask, category: value })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select category" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="personal_care">Personal Care</SelectItem>
                  <SelectItem value="household">Household</SelectItem>
                  <SelectItem value="work">Work</SelectItem>
                  <SelectItem value="health">Health</SelectItem>
                  <SelectItem value="social">Social</SelectItem>
                  <SelectItem value="education">Education</SelectItem>
                </SelectContent>
              </Select>
              <Input
                type="number"
                placeholder="Estimated minutes"
                value={newTask.estimatedMinutes}
                onChange={(e) => setNewTask({ ...newTask, estimatedMinutes: parseInt(e.target.value) || 15 })}
                min="1"
                max="480"
              />
              <div className="space-y-2">
                <label className="text-sm font-medium text-gray-700">Point Value (awarded when completed)</label>
                <Input
                  type="number"
                  placeholder="Points to award"
                  value={newTask.pointValue}
                  onChange={(e) => setNewTask({ ...newTask, pointValue: parseInt(e.target.value) || 0 })}
                  min="0"
                  max="100"
                />
                <p className="text-xs text-gray-500">Set to 0 for no point reward</p>
              </div>
              <div className="flex space-x-2">
                <Button 
                  onClick={handleCreateTask} 
                  disabled={createTaskMutation.isPending}
                  className="flex-1 bg-green-600 hover:bg-green-700 text-white"
                >
                  {createTaskMutation.isPending ? "Creating..." : "Create Task"}
                </Button>
                <Button 
                  onClick={() => setIsAddDialogOpen(false)} 
                  variant="outline"
                  className="flex-1"
                >
                  Cancel
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}
