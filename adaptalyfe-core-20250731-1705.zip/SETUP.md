# AdaptaLyfe Core Setup

## Project Structure
This is the core AdaptaLyfe source code package containing:
- Complete React frontend (`client/src/`)
- Express.js backend (`server/`)
- Shared schemas (`shared/`)
- Build configuration files
- Capacitor mobile configuration

## Quick Setup

1. Create `client/public/` directory
2. Install dependencies: `npm install`
3. Setup database: `npm run db:push`
4. Start development: `npm run dev`

## Missing Files (Add these manually)
- `client/public/` directory with app icons
- Environment variables for database connection

## Mobile Build
Run `npx cap sync` after building to prepare for mobile deployment.

This core package contains all the essential source code for the complete AdaptaLyfe application.