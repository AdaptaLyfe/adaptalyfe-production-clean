import 'package:flutter/services.dart';

/// US phone number:
/// 10 digits
/// Example: 5551234567
List<TextInputFormatter> phoneNumberInputFormatters() => [
      FilteringTextInputFormatter.digitsOnly,
      LengthLimitingTextInputFormatter(10),
    ];

String? validatePhoneNumber(
  String? value, {
  bool required = false,
}) {
  final digits = (value ?? '').replaceAll(RegExp(r'\D'), '');

  if (digits.isEmpty) {
    return required ? 'Phone number is required' : null;
  }

  // Must contain exactly 10 digits.
  if (digits.length != 10) {
    return 'Enter a valid 10-digit US phone number';
  }

  // US area code cannot start with 0 or 1.
  if (digits[0] == '0' || digits[0] == '1') {
    return 'Enter a valid US phone number';
  }

  // US phone exchange/prefix cannot start with 0 or 1.
  if (digits[3] == '0' || digits[3] == '1') {
    return 'Enter a valid US phone number';
  }

  return null;
}
