import 'package:flutter/material.dart';

abstract final class AppTextStyles {
  static TextStyle title(BuildContext context) {
    return TextStyle(
      color: Theme.of(context).colorScheme.onSurface,
      fontSize: 24,
      fontWeight: FontWeight.w700,
      height: 1.2,
    );
  }

  static TextStyle sectionTitle(BuildContext context) {
    return TextStyle(
      color: Theme.of(context).colorScheme.onSurface,
      fontSize: 18,
      fontWeight: FontWeight.w600,
      height: 1.3,
    );
  }

  static TextStyle body(BuildContext context) {
    return TextStyle(
      color: Theme.of(context).colorScheme.onSurface,
      fontSize: 14,
      fontWeight: FontWeight.w400,
      height: 1.45,
    );
  }

  static TextStyle bodyMedium(BuildContext context) {
    return TextStyle(
      color: Theme.of(context).colorScheme.onSurface,
      fontSize: 14,
      fontWeight: FontWeight.w500,
      height: 1.4,
    );
  }

  static TextStyle caption(BuildContext context) {
    return TextStyle(
      color: Theme.of(context).colorScheme.onSurfaceVariant,
      fontSize: 12,
      fontWeight: FontWeight.w400,
      height: 1.35,
    );
  }

  static TextStyle button(BuildContext context) {
    return TextStyle(
      color: Theme.of(context).colorScheme.onPrimary,
      fontSize: 14,
      fontWeight: FontWeight.w600,
      letterSpacing: 0.1,
    );
  }
}
