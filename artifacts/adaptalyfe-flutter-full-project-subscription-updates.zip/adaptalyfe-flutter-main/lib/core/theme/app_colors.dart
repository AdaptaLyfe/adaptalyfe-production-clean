import 'package:flutter/material.dart';

abstract final class AppColors {
  static const Color primaryLight = Color(0xFF4F7CAC);
  static const Color primaryDark = Color(0xFF8FB8D8);

  static const Color secondaryLight = Color(0xFF5BAFA6);
  static const Color secondaryDark = Color(0xFF78C7BF);

  static const Color lightBackground = Color(0xFFF7F9FC);
  static const Color lightSurface = Color(0xFFFFFFFF);

  static const Color lightText = Color(0xFF263238);
  static const Color lightSecondaryText = Color(0xFF667781);

  static const Color lightBorder = Color(0xFFDCE4E9);

  static const Color darkBackground = Color(0xFF121A21);
  static const Color darkSurface = Color(0xFF1C2730);

  static const Color darkText = Color(0xFFF1F5F7);
  static const Color darkSecondaryText = Color(0xFFB7C3CA);

  static const Color darkBorder = Color(0xFF34434D);

  static const Color successLight = Color(0xFF4F9D69);
  static const Color successDark = Color(0xFF76C893);

  static const Color errorLight = Color(0xFFC95C5C);
  static const Color errorDark = Color(0xFFE58A8A);

  static const Color warningLight = Color(0xFFC9953D);
  static const Color warningDark = Color(0xFFE6B866);
}
