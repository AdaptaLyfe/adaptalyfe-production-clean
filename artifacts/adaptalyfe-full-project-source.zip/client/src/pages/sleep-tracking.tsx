import { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Calendar } from '@/components/ui/calendar';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { Moon, Sun, Clock, TrendingUp, Heart, Brain, Star, Award, Target, BarChart3, Calendar as CalendarIcon, Plus, Pencil, Trash2 } from 'lucide-react';
import { format, startOfWeek, endOfWeek, subDays, isToday } from 'date-fns';
import { apiRequest } from '@/lib/queryClient';
import {
  getRecentSleepSessions,
  sortSleepSessionsChronologically,
} from '@/lib/sleep-trends';
import {
  calculateSleepMetrics,
  calculateSleepStats,
  type SleepStats,
} from '@shared/sleep-calculations';
import {
  getLocalDateString,
  getSleepDateValidationError,
  isValidSleepDate,
} from '@shared/sleep-date-validation';
import {
  combineLocalDateAndTime,
  getSleepRoutineTimeValidationError,
} from '@shared/sleep-time-validation';
import { useToast } from '@/hooks/use-toast';

interface SleepSession {
  id: number;
  userId: number;
  sleepDate: string;
  bedtime: string | null;
  sleepTime: string | null;
  wakeTime: string | null;
  totalSleepDuration: number | null;
  deepSleepDuration: number | null;
  lightSleepDuration: number | null;
  remSleepDuration: number | null;
  awakeDuration: number | null;
  sleepEfficiency: number | null;
  sleepScore: number | null;
  quality: string | null;
  notes: string | null;
  heartRateVariability: number | null;
  restingHeartRate: number | null;
}

type SleepLogMode = 'create' | 'edit';

interface SleepFormData {
  sleepDate: string;
  bedtime: string;
  sleepTime: string;
  wakeDate: string;
  wakeTime: string;
  quality: string;
  notes: string;
}

function getDefaultSleepFormData(date: Date): SleepFormData {
  const dateValue = format(date, 'yyyy-MM-dd');
  return {
    sleepDate: dateValue,
    bedtime: '',
    sleepTime: '',
    wakeDate: dateValue,
    wakeTime: '',
    quality: '',
    notes: '',
  };
}

interface SleepGoal {
  targetSleepDuration: number; // minutes
  targetBedtime: string; // HH:MM format
  targetWakeTime: string; // HH:MM format
}

export default function SleepTracking() {
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [isLogging, setIsLogging] = useState(false);
  const [sleepLogMode, setSleepLogMode] = useState<SleepLogMode>('create');
  const [editingSleepSession, setEditingSleepSession] = useState<SleepSession | null>(null);
  const [sleepGoals, setSleepGoals] = useState<SleepGoal>({
    targetSleepDuration: 480, // 8 hours
    targetBedtime: '22:00',
    targetWakeTime: '06:00'
  });
  const [sessionToDelete, setSessionToDelete] = useState<SleepSession | null>(null);
  
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch sleep sessions
  const { data: sleepSessions = [], isLoading } = useQuery({
    queryKey: ['/api/sleep-sessions'],
    queryFn: () => apiRequest('GET', '/api/sleep-sessions').then(res => res.json())
  });

  // Create/update sleep session mutation
  const createSleepSession = useMutation({
    mutationFn: ({ data, sessionId }: { data: Partial<SleepSession>; sessionId?: number }) =>
      apiRequest(
        sessionId ? 'PUT' : 'POST',
        sessionId ? `/api/sleep-sessions/${sessionId}` : '/api/sleep-sessions',
        data,
      ).then(res => res.json()),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/sleep-sessions'] });
      toast({ title: 'Sleep session saved successfully!' });
      setIsLogging(false);
      setSleepLogMode('create');
      setEditingSleepSession(null);
    },
    onError: () => {
      toast({ title: 'Failed to save sleep session', variant: 'destructive' });
    }
  });

  const deleteSleepSession = useMutation({
    mutationFn: (sessionId: number) =>
      apiRequest('DELETE', `/api/sleep-sessions/${sessionId}`),
    onMutate: async (sessionId) => {
      await queryClient.cancelQueries({ queryKey: ['/api/sleep-sessions'] });

      const previousSessions = queryClient.getQueryData<SleepSession[]>(['/api/sleep-sessions']);
      queryClient.setQueryData<SleepSession[]>(
        ['/api/sleep-sessions'],
        (currentSessions = []) => currentSessions.filter(session => session.id !== sessionId)
      );

      return { previousSessions };
    },
    onError: (_error, _sessionId, context) => {
      if (context?.previousSessions) {
        queryClient.setQueryData(['/api/sleep-sessions'], context.previousSessions);
      }
      toast({
        title: 'Failed to delete sleep log',
        description: 'Please try again.',
        variant: 'destructive',
      });
    },
    onSuccess: () => {
      setSessionToDelete(null);
      toast({
        title: 'Sleep log deleted',
        description: 'The sleep log was permanently deleted.',
      });
    },
    onSettled: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/sleep-sessions'] });
    },
  });

  const availableSleepSessions: SleepSession[] = Array.isArray(sleepSessions) ? sleepSessions : [];
  const stats: SleepStats | null = calculateSleepStats(
    availableSleepSessions,
    sleepGoals.targetSleepDuration,
    format(selectedDate, 'yyyy-MM-dd'),
  );

  // Format time helpers
  const formatDuration = (minutes: number | null | undefined) => {
    if (minutes === null || minutes === undefined || !Number.isFinite(minutes)) return '--';
    const hours = Math.floor(minutes / 60);
    const mins = minutes % 60;
    return `${hours}h ${mins}m`;
  };

  const formatTime = (timeString: string | null) => {
    if (!timeString) return '--';
    return format(new Date(timeString), 'h:mm a');
  };

  const getQualityColor = (quality: string | null) => {
    switch (quality) {
      case 'excellent': return 'bg-green-100 text-green-800';
      case 'good': return 'bg-blue-100 text-blue-800';
      case 'fair': return 'bg-yellow-100 text-yellow-800';
      case 'poor': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getSleepScoreColor = (score: number | null) => {
    if (!score) return 'bg-gray-500';
    if (score >= 80) return 'bg-green-500';
    if (score >= 60) return 'bg-blue-500';
    if (score >= 40) return 'bg-yellow-500';
    return 'bg-red-500';
  };

  const openCreateSleepLog = () => {
    setSleepLogMode('create');
    setEditingSleepSession(null);
    setSelectedDate(new Date());
    setIsLogging(true);
  };

  const openEditSleepLog = (session: SleepSession) => {
    setSleepLogMode('edit');
    setEditingSleepSession(session);
    setSelectedDate(new Date(`${session.sleepDate}T00:00:00`));
    setIsLogging(true);
  };

  return (
    <div className="container mx-auto p-6 max-w-7xl">
      <div className="flex items-center gap-4 mb-8">
        <div className="p-3 bg-blue-100 rounded-full">
          <Moon className="h-8 w-8 text-blue-600" />
        </div>
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Sleep Routine</h1>
          <p className="text-gray-600 mt-1">Monitor your sleep patterns and improve your rest quality</p>
        </div>
      </div>

       <Tabs
         defaultValue="overview"
         className="space-y-6"
         value={isLogging ? "log" : undefined}
         onValueChange={(value) => {
           if (value === "log") {
             openCreateSleepLog();
           } else {
             setIsLogging(false);
           }
         }}
       >
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="log">Log Sleep</TabsTrigger>
          <TabsTrigger value="trends">Trends</TabsTrigger>
          <TabsTrigger value="goals">Goals</TabsTrigger>
        </TabsList>

        {/* Overview Tab */}
        <TabsContent value="overview" className="space-y-6">
          {/* Quick Stats Cards */}
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Avg Sleep Duration</CardTitle>
                <Moon className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {formatDuration(stats?.avgSleepDuration)}
                </div>
                <p className="text-xs text-muted-foreground">Last 7 days</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Sleep Score</CardTitle>
                <Star className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {stats?.avgSleepScore != null ? `${stats.avgSleepScore}/100` : '--'}
                </div>
                <p className="text-xs text-muted-foreground">Average quality</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Sleep Efficiency</CardTitle>
                <TrendingUp className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {stats?.avgEfficiency != null ? `${stats.avgEfficiency}%` : '--'}
                </div>
                <p className="text-xs text-muted-foreground">Time asleep vs time in bed</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Goal Progress</CardTitle>
                <Target className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {stats?.goalProgress != null ? `${stats.goalProgress}%` : '--'}
                </div>
                <Progress value={stats?.goalProgress ?? 0} className="mt-2" />
              </CardContent>
            </Card>
          </div>

          {/* Recent Sleep Sessions */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>Recent Sleep Sessions</CardTitle>
                <div className="p-2 border-2 border-blue-300 rounded-lg bg-blue-50 shadow-sm hover:shadow-md transition-shadow">
                  <Button 
                     onClick={openCreateSleepLog}
                    size="sm"
                    className="bg-blue-600 hover:bg-blue-700 text-white font-semibold"
                  >
                    <Plus className="h-4 w-4 mr-2" />
                    Log Sleep
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {getRecentSleepSessions(availableSleepSessions).map((session: SleepSession) => {
                  const metrics = calculateSleepMetrics(session);
                  return (
                  <div key={session.id} className="flex flex-wrap items-center justify-between gap-4 p-4 border rounded-lg">
                    <div className="flex items-center gap-4">
                      <div className="p-2 bg-blue-100 rounded-full">
                        <Moon className="h-4 w-4 text-blue-600" />
                      </div>
                      <div>
                        <p className="font-medium">
                          {format(new Date(session.sleepDate), 'MMM dd, yyyy')}
                          {isToday(new Date(session.sleepDate)) && (
                            <Badge variant="outline" className="ml-2">Today</Badge>
                          )}
                        </p>
                        <p className="text-sm text-gray-600">
                          {formatTime(session.bedtime)} - {formatTime(session.wakeTime)}
                        </p>
                      </div>
                    </div>
                    <div className="flex flex-wrap items-center gap-4 text-sm">
                      <div className="text-center">
                        <p className="font-medium">{formatDuration(metrics.totalSleepDuration)}</p>
                        <p className="text-gray-500">Duration</p>
                      </div>
                      <div className="text-center">
                        <p className="font-medium">{metrics.sleepScore != null ? `${metrics.sleepScore}/100` : '--'}</p>
                        <p className="text-gray-500">Score</p>
                      </div>
                      {session.quality && (
                        <Badge className={getQualityColor(session.quality)}>
                          {session.quality}
                        </Badge>
                      )}
                      <Button
                         type="button"
                         variant="outline"
                         size="sm"
                         className="text-blue-600 hover:bg-blue-50 hover:text-blue-700"
                         onClick={() => openEditSleepLog(session)}
                         aria-label={`Edit sleep log from ${format(new Date(session.sleepDate), 'MMM dd, yyyy')}`}
                         title="Edit sleep log"
                       >
                         <Pencil className="h-4 w-4 mr-1" />
                         Edit
                       </Button>
                       <Button
                        type="button"
                        variant="ghost"
                        size="icon"
                        className="h-9 w-9 shrink-0 text-red-600 hover:bg-red-50 hover:text-red-700"
                        onClick={() => setSessionToDelete(session)}
                        disabled={deleteSleepSession.isPending}
                        aria-label={`Delete sleep log from ${format(new Date(session.sleepDate), 'MMM dd, yyyy')}`}
                        title="Delete sleep log"
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                  );
                })}
                {availableSleepSessions.length === 0 && (
                  <div className="text-center py-8 text-gray-500">
                    <Moon className="h-12 w-12 mx-auto mb-4 opacity-50" />
                    <p>No sleep sessions recorded yet</p>
                    <div className="p-2 border-2 border-blue-300 rounded-lg bg-blue-50 shadow-sm hover:shadow-md transition-shadow mt-4 inline-block">
                      <Button onClick={openCreateSleepLog} className="bg-blue-600 hover:bg-blue-700 text-white font-semibold">
                        Log your first sleep session
                      </Button>
                    </div>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          <AlertDialog
            open={!!sessionToDelete}
            onOpenChange={(open) => {
              if (!open && !deleteSleepSession.isPending) {
                setSessionToDelete(null);
              }
            }}
          >
            <AlertDialogContent className="w-[calc(100%-2rem)] max-w-md max-h-[calc(100vh-2rem)] overflow-y-auto rounded-xl border border-slate-200 bg-white p-5 text-slate-900 shadow-2xl sm:p-6">
              <AlertDialogHeader className="space-y-3 text-left">
                <AlertDialogTitle className="text-base leading-6 text-slate-900 sm:text-lg">
                  Are you sure you want to delete this log?
                </AlertDialogTitle>
                <AlertDialogDescription className="text-sm leading-5 text-slate-600">
                  This action cannot be undone.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter className="flex flex-col-reverse gap-3 sm:flex-row sm:justify-end sm:gap-2 sm:space-x-0">
                <AlertDialogCancel
                  disabled={deleteSleepSession.isPending}
                  className="mt-0 w-full sm:w-auto"
                >
                  Cancel
                </AlertDialogCancel>
                <AlertDialogAction
                  onClick={(event) => {
                    event.preventDefault();
                    if (sessionToDelete) {
                      deleteSleepSession.mutate(sessionToDelete.id);
                    }
                  }}
                  disabled={deleteSleepSession.isPending}
                  className="mt-0 w-full bg-red-600 text-white hover:bg-red-700 sm:w-auto"
                >
                  Delete
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        </TabsContent>

        {/* Log Sleep Tab */}
        <TabsContent value="log" className="space-y-6">
          <SleepLoggingForm 
            onSubmit={(data, sessionId) => createSleepSession.mutate({ data, sessionId })}
            isLoading={createSleepSession.isPending}
            selectedDate={selectedDate}
            mode={sleepLogMode}
            existingSession={sleepLogMode === 'edit' ? editingSleepSession : undefined}
          />
        </TabsContent>

        {/* Trends Tab */}
        <TabsContent value="trends" className="space-y-6">
          <SleepTrends sleepSessions={availableSleepSessions} />
        </TabsContent>

        {/* Goals Tab */}
        <TabsContent value="goals" className="space-y-6">
          <SleepGoals 
            goals={sleepGoals}
            onUpdateGoals={setSleepGoals}
            stats={stats}
          />
        </TabsContent>
      </Tabs>
    </div>
  );
}

// Sleep Logging Form Component
function SleepLoggingForm({ 
  onSubmit, 
  isLoading, 
  selectedDate, 
  mode,
  existingSession,
}: {
  onSubmit: (data: any, sessionId?: number) => void;
  isLoading: boolean;
  selectedDate: Date;
  mode: SleepLogMode;
  existingSession?: SleepSession | null;
}) {
  const [dateError, setDateError] = useState<string | null>(null);
  const [wakeDateError, setWakeDateError] = useState<string | null>(null);
  const [timeError, setTimeError] = useState<string | null>(null);
  const [formData, setFormData] = useState<SleepFormData>(() => getDefaultSleepFormData(selectedDate));

  useEffect(() => {
    if (mode === 'edit' && existingSession) {
      setFormData({
        sleepDate: existingSession.sleepDate,
        bedtime: existingSession.bedtime ? format(new Date(existingSession.bedtime), 'HH:mm') : '',
        sleepTime: existingSession.sleepTime ? format(new Date(existingSession.sleepTime), 'HH:mm') : '',
        wakeDate: existingSession.wakeTime
          ? format(new Date(existingSession.wakeTime), 'yyyy-MM-dd')
          : existingSession.sleepDate,
        wakeTime: existingSession.wakeTime ? format(new Date(existingSession.wakeTime), 'HH:mm') : '',
        quality: existingSession.quality || '',
        notes: existingSession.notes || ''
      });
      setWakeDateError(null);
      setTimeError(getFormTimeValidationError({
        sleepDate: existingSession.sleepDate,
        bedtime: existingSession.bedtime ? format(new Date(existingSession.bedtime), 'HH:mm') : '',
        sleepTime: existingSession.sleepTime ? format(new Date(existingSession.sleepTime), 'HH:mm') : '',
        wakeDate: existingSession.wakeTime
          ? format(new Date(existingSession.wakeTime), 'yyyy-MM-dd')
          : existingSession.sleepDate,
        wakeTime: existingSession.wakeTime ? format(new Date(existingSession.wakeTime), 'HH:mm') : '',
      }));
    } else if (mode === 'create') {
      setFormData(getDefaultSleepFormData(selectedDate));
      setDateError(null);
      setWakeDateError(null);
      setTimeError(null);
    }
  }, [existingSession, mode, selectedDate]);

  const getFormTimeValidationError = (values: typeof formData): string | null => {
    if (!values.bedtime || !values.sleepTime || !values.wakeTime) return null;

    const bedtime = combineLocalDateAndTime(values.sleepDate, values.bedtime);
    const sleepTime = combineLocalDateAndTime(values.sleepDate, values.sleepTime);
    const wakeTime = combineLocalDateAndTime(values.wakeDate, values.wakeTime);
    if (!bedtime || !sleepTime || !wakeTime) {
      return 'Sleep dates and times must be valid';
    }

    return getSleepRoutineTimeValidationError(bedtime, sleepTime, wakeTime);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    const sleepDateError = getSleepDateValidationError(formData.sleepDate);
    if (sleepDateError) {
      setDateError(sleepDateError);
      return;
    }
    setDateError(null);

    const wakeDateErrorMessage = !isValidSleepDate(formData.wakeDate)
      ? 'Wake date must be a valid date'
      : formData.wakeDate < formData.sleepDate
        ? 'Wake date must be the same as or later than sleep date'
        : null;
    if (wakeDateErrorMessage) {
      setWakeDateError(wakeDateErrorMessage);
      return;
    }
    setWakeDateError(null);

    const sleepTimeError = getFormTimeValidationError(formData);
    if (sleepTimeError) {
      setTimeError(sleepTimeError);
      return;
    }
    setTimeError(null);
    
    const bedtime = combineLocalDateAndTime(formData.sleepDate, formData.bedtime);
    const sleepTime = combineLocalDateAndTime(formData.sleepDate, formData.sleepTime);
    const wakeTime = combineLocalDateAndTime(formData.wakeDate, formData.wakeTime);
    if (!bedtime || !sleepTime || !wakeTime) {
      setTimeError('Sleep dates and times must be valid');
      return;
    }

    const sleepData = {
      sleepDate: formData.sleepDate,
      bedtime: bedtime.toISOString(),
      sleepTime: sleepTime.toISOString(),
      wakeTime: wakeTime.toISOString(),
      quality: formData.quality,
      notes: formData.notes,
    };
    
    onSubmit(sleepData, mode === 'edit' ? existingSession?.id : undefined);
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Log Sleep Session</CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid gap-4 md:grid-cols-2">
            <div>
              <Label htmlFor="sleepDate">Sleep Date</Label>
              <Input
                id="sleepDate"
                type="date"
                value={formData.sleepDate}
                max={getLocalDateString()}
                onChange={(e) => {
                  const sleepDate = e.target.value;
                  setFormData({ ...formData, sleepDate });
                  setDateError(getSleepDateValidationError(sleepDate));
                   setTimeError(getFormTimeValidationError({ ...formData, sleepDate }));
                }}
                aria-invalid={dateError ? 'true' : undefined}
                required
              />
              {dateError && (
                <p className="mt-1 text-sm text-red-600" role="alert">
                  {dateError}
                </p>
              )}
            </div>
            <div>
              <Label htmlFor="quality">Sleep Quality</Label>
              <select
                id="quality"
                value={formData.quality}
                onChange={(e) => setFormData({ ...formData, quality: e.target.value })}
                className="w-full p-2 border rounded-md"
                required
              >
                <option value="">Select quality</option>
                <option value="excellent">Excellent</option>
                <option value="good">Good</option>
                <option value="fair">Fair</option>
                <option value="poor">Poor</option>
              </select>
            </div>
          </div>

          <div className="grid gap-4 md:grid-cols-2">
            <div>
              <Label htmlFor="bedtime">Bedtime</Label>
              <Input
                id="bedtime"
                type="time"
                value={formData.bedtime}
                onChange={(e) => {
                  const bedtime = e.target.value;
                  setFormData({ ...formData, bedtime });
                   setTimeError(getFormTimeValidationError({ ...formData, bedtime }));
                }}
                aria-invalid={timeError ? 'true' : undefined}
                required
              />
            </div>
            <div>
              <Label htmlFor="sleepTime">Time Fell Asleep</Label>
              <Input
                id="sleepTime"
                type="time"
                value={formData.sleepTime}
                onChange={(e) => {
                  const sleepTime = e.target.value;
                  setFormData({ ...formData, sleepTime });
                   setTimeError(getFormTimeValidationError({ ...formData, sleepTime }));
                }}
                aria-invalid={timeError ? 'true' : undefined}
                required
              />
              {timeError && (
                <p className="mt-1 text-sm text-red-600" role="alert">
                  {timeError}
                </p>
              )}
            </div>
            <div>
              <Label htmlFor="wakeDate">Wake Date</Label>
              <Input
                id="wakeDate"
                type="date"
                value={formData.wakeDate}
                min={formData.sleepDate}
                onChange={(e) => {
                  const wakeDate = e.target.value;
                  const nextFormData = { ...formData, wakeDate };
                  setFormData(nextFormData);
                  setWakeDateError(
                    !isValidSleepDate(wakeDate)
                      ? 'Wake date must be a valid date'
                      : wakeDate < formData.sleepDate
                        ? 'Wake date must be the same as or later than sleep date'
                        : null,
                  );
                  setTimeError(getFormTimeValidationError(nextFormData));
                }}
                aria-invalid={wakeDateError || timeError ? 'true' : undefined}
                required
              />
              {wakeDateError && (
                <p className="mt-1 text-sm text-red-600" role="alert">
                  {wakeDateError}
                </p>
              )}
            </div>
            <div>
              <Label htmlFor="wakeTime">Wake Time</Label>
              <Input
                id="wakeTime"
                type="time"
                value={formData.wakeTime}
                onChange={(e) => {
                  const wakeTime = e.target.value;
                  setFormData({ ...formData, wakeTime });
                   setTimeError(getFormTimeValidationError({ ...formData, wakeTime }));
                }}
                aria-invalid={timeError ? 'true' : undefined}
                required
              />
            </div>
          </div>

          <div>
            <Label htmlFor="notes">Notes</Label>
            <Textarea
              id="notes"
              placeholder="How did you feel? What might have affected your sleep?"
              value={formData.notes}
              onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
              rows={3}
            />
          </div>

          <div className="p-3 border-2 border-green-300 rounded-lg bg-green-50 shadow-sm hover:shadow-md transition-shadow">
            <Button type="submit" disabled={isLoading} className="w-full bg-green-600 hover:bg-green-700 text-white font-semibold py-3 text-lg">
              {isLoading ? 'Saving...' : 'Save Sleep Session'}
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}

// Sleep Trends Component
function SleepTrends({ sleepSessions }: { sleepSessions: SleepSession[] }) {
  const trendSessions = sortSleepSessionsChronologically(sleepSessions);

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Sleep Trends</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {sleepSessions.length === 0 ? (
              <div className="text-center py-8 text-gray-500">
                <BarChart3 className="h-12 w-12 mx-auto mb-4 opacity-50" />
                <p>Not enough data to show trends</p>
                <p className="text-sm">Log at least 3 sleep sessions to see trends</p>
              </div>
            ) : (
              <div className="grid gap-6 md:grid-cols-2">
                <div>
                  <h3 className="font-medium mb-3">Sleep Duration Trend</h3>
                  <div className="space-y-2">
                    {trendSessions.map((session) => (
                      <div key={session.id} className="flex items-center justify-between">
                        <span className="text-sm">{format(new Date(session.sleepDate), 'MMM dd')}</span>
                        <div className="flex items-center gap-2">
                          <div 
                            className="h-2 bg-blue-500 rounded"
                            style={{ 
                              width: `${Math.min((session.totalSleepDuration || 0) / 600 * 100, 100)}px` 
                            }}
                          />
                          <span className="text-sm font-medium w-12">
                            {session.totalSleepDuration ? `${Math.round(session.totalSleepDuration / 60)}h` : '--'}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
                <div>
                  <h3 className="font-medium mb-3">Sleep Quality Trend</h3>
                  <div className="space-y-2">
                    {trendSessions.map((session) => (
                      <div key={session.id} className="flex items-center justify-between">
                        <span className="text-sm">{format(new Date(session.sleepDate), 'MMM dd')}</span>
                        <Badge className={`${session.quality ? getQualityColor(session.quality) : 'bg-gray-100 text-gray-800'}`}>
                          {session.quality || 'Not rated'}
                        </Badge>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

// Sleep Goals Component
function SleepGoals({ 
  goals, 
  onUpdateGoals, 
  stats 
}: { 
  goals: SleepGoal; 
  onUpdateGoals: (goals: SleepGoal) => void;
  stats: SleepStats | null;
}) {
  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Sleep Goals</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid gap-4 md:grid-cols-3">
            <div>
              <Label htmlFor="targetDuration">Target Sleep Duration</Label>
              <select
                id="targetDuration"
                value={goals.targetSleepDuration}
                onChange={(e) => onUpdateGoals({ ...goals, targetSleepDuration: parseInt(e.target.value) })}
                className="w-full p-2 border rounded-md"
              >
                <option value={420}>7 hours</option>
                <option value={450}>7.5 hours</option>
                <option value={480}>8 hours</option>
                <option value={510}>8.5 hours</option>
                <option value={540}>9 hours</option>
              </select>
            </div>
            <div>
              <Label htmlFor="targetBedtime">Target Bedtime</Label>
              <Input
                id="targetBedtime"
                type="time"
                value={goals.targetBedtime}
                onChange={(e) => onUpdateGoals({ ...goals, targetBedtime: e.target.value })}
              />
            </div>
            <div>
              <Label htmlFor="targetWakeTime">Target Wake Time</Label>
              <Input
                id="targetWakeTime"
                type="time"
                value={goals.targetWakeTime}
                onChange={(e) => onUpdateGoals({ ...goals, targetWakeTime: e.target.value })}
              />
            </div>
          </div>

          {stats && (
            <div className="p-4 bg-blue-50 rounded-lg">
              <h3 className="font-medium mb-2">Progress This Week</h3>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span>Sleep Duration Goal</span>
                  <span className="font-medium">
                    {stats.goalProgress != null ? `${stats.goalProgress}%` : '--'}
                  </span>
                </div>
                <Progress value={stats.goalProgress ?? 0} />
                <p className="text-sm text-gray-600">
                  Average: {formatDuration(stats.weeklyAvgSleepDuration)} / Target: {formatDuration(goals.targetSleepDuration)}
                </p>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

// Helper function used in trends
function getQualityColor(quality: string | null) {
  switch (quality) {
    case 'excellent': return 'bg-green-100 text-green-800';
    case 'good': return 'bg-blue-100 text-blue-800';
    case 'fair': return 'bg-yellow-100 text-yellow-800';
    case 'poor': return 'bg-red-100 text-red-800';
    default: return 'bg-gray-100 text-gray-800';
  }
}

// Helper function to format duration
function formatDuration(minutes: number | null) {
  if (!minutes) return '--';
  const hours = Math.floor(minutes / 60);
  const mins = minutes % 60;
  return `${hours}h ${mins}m`;
}