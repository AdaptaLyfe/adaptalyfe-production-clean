import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Calendar, Clock, ChefHat, Plus, CheckCircle2, Trash2 } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { insertMealPlanSchema, type MealPlan, type InsertMealPlan } from "@shared/schema";
import { format } from "date-fns";
import { useToast } from "@/hooks/use-toast";
import { useState } from "react";

export default function MealPlanningModule() {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const [mealPendingDeletion, setMealPendingDeletion] = useState<MealPlan | null>(null);

  const { data: mealPlans, isLoading } = useQuery<MealPlan[]>({
    queryKey: ["/api/meal-plans"],
  });

  const createMealPlanMutation = useMutation({
    mutationFn: async (data: InsertMealPlan) => {
      const response = await apiRequest("POST", "/api/meal-plans", data);
      return response;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/meal-plans"] });
      form.reset();
      toast({
        title: "Success",
        description: "Meal plan saved successfully!",
      });
    },
    onError: (error) => {
      console.error("Failed to create meal plan:", error);
      toast({
        title: "Error",
        description: "Failed to save meal plan. Please try again.",
        variant: "destructive",
      });
    },
  });

  const updateCompletionMutation = useMutation({
    mutationFn: async ({ id, isCompleted }: { id: number; isCompleted: boolean }) => {
      const response = await apiRequest("PATCH", `/api/meal-plans/${id}/completion`, { isCompleted });
      return response;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/meal-plans"] });
      queryClient.invalidateQueries({ queryKey: ["/api/user"] });
    },
  });

  const deleteMealPlanMutation = useMutation({
    mutationFn: async (id: number) => {
      return await apiRequest("DELETE", `/api/meal-plans/${id}`);
    },
    onMutate: async (id) => {
      await queryClient.cancelQueries({ queryKey: ["/api/meal-plans"] });
      const previousMealPlans = queryClient.getQueryData<MealPlan[]>(["/api/meal-plans"]);

      queryClient.setQueryData<MealPlan[]>(["/api/meal-plans"], (currentMealPlans) =>
        currentMealPlans?.filter((mealPlan) => mealPlan.id !== id),
      );

      return { previousMealPlans };
    },
    onSuccess: () => {
      setMealPendingDeletion(null);
      toast({
        title: "Meal deleted",
        description: "The meal was removed from your meal list.",
      });
    },
    onError: (error, _id, context) => {
      console.error("Failed to delete meal plan:", error);
      if (context?.previousMealPlans) {
        queryClient.setQueryData(["/api/meal-plans"], context.previousMealPlans);
      }
      toast({
        title: "Error",
        description: "Failed to delete the meal. Please try again.",
        variant: "destructive",
      });
    },
    onSettled: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/meal-plans"] });
    },
  });

  const form = useForm<Omit<InsertMealPlan, 'userId'>>({
    resolver: zodResolver(insertMealPlanSchema.omit({ userId: true })),
    defaultValues: {
      mealType: "breakfast",
      mealName: "",
      plannedDate: format(new Date(), "yyyy-MM-dd"),
      isCompleted: false,
      recipe: "",
      cookingTime: 30,
    },
  });

  const handleSubmit = (data: Omit<InsertMealPlan, 'userId'>) => {
    console.log("Submitting meal plan data:", data);
    createMealPlanMutation.mutate(data as InsertMealPlan);
  };

  const toggleCompletion = (mealPlan: MealPlan) => {
    updateCompletionMutation.mutate({
      id: mealPlan.id,
      isCompleted: !mealPlan.isCompleted,
    });
  };

  const selectMeal = (mealPlan: MealPlan) => {
    toast({
      title: `Meal selected: ${mealPlan.mealName}`,
    });
  };

  const getMealTypeColor = (mealType: string) => {
    switch (mealType) {
      case "breakfast": return "bg-sunny-orange text-white";
      case "lunch": return "bg-vibrant-green text-white";
      case "dinner": return "bg-bright-blue text-white";
      case "snack": return "bg-cheerful-pink text-white";
      default: return "bg-gray-500 text-white";
    }
  };

  const groupedMealPlans = mealPlans?.reduce((acc, meal) => {
    const date = meal.plannedDate;
    if (!acc[date]) acc[date] = [];
    acc[date].push(meal);
    return acc;
  }, {} as Record<string, MealPlan[]>);

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <ChefHat className="text-sunny-orange" />
            <span>Meal Planning</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {[1, 2, 3].map((i) => (
              <div key={i} className="h-16 bg-gray-100 rounded-lg animate-pulse" />
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <ChefHat className="text-sunny-orange" />
            <span>Add New Meal</span>
          </CardTitle>
          <CardDescription>
            Plan your meals to develop healthy eating habits and cooking skills
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(handleSubmit, (errors) => {
              console.error("Form validation errors:", errors);
              toast({
                title: "Form Error",
                description: "Please fill in all required fields correctly.",
                variant: "destructive",
              });
            })} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="mealName"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel required>Meal Name</FormLabel>
                      <FormControl>
                        <Input placeholder="e.g., Scrambled eggs and toast" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="mealType"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel required>Meal Type</FormLabel>
                      <FormControl>
                        <select 
                          {...field}
                          className="flex h-10 w-full items-center justify-between rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                        >
                          <option value="">Select meal type</option>
                          <option value="breakfast">Breakfast</option>
                          <option value="lunch">Lunch</option>
                          <option value="dinner">Dinner</option>
                          <option value="snack">Snack</option>
                        </select>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="plannedDate"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel required>Planned Date</FormLabel>
                      <FormControl>
                        <Input type="date" min={format(new Date(), "yyyy-MM-dd")} {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="cookingTime"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel optional>Cooking Time (minutes)</FormLabel>
                      <FormControl>
                        <Input
                          type="number"
                          placeholder="30"
                          value={field.value?.toString() || ""}
                          onChange={(e) => field.onChange(parseInt(e.target.value) || 0)}
                          onBlur={field.onBlur}
                          name={field.name}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <FormField
                control={form.control}
                name="recipe"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Recipe/Instructions (Optional)</FormLabel>
                    <FormControl>
                      <Textarea
                        placeholder="Write simple cooking instructions or notes..."
                        className="min-h-[100px]"
                        value={field.value || ""}
                        onChange={field.onChange}
                        onBlur={field.onBlur}
                        name={field.name}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <Button 
                type="submit" 
                disabled={createMealPlanMutation.isPending} 
                className="w-full bg-green-600 hover:bg-green-700 text-white"
                onClick={() => console.log("Button clicked, form values:", form.getValues())}
              >
                <Plus className="w-4 h-4 mr-2" />
                {createMealPlanMutation.isPending ? "Adding..." : "Add Meal Plan"}
              </Button>
            </form>
          </Form>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Calendar className="text-bright-blue" />
            <span>Meal Schedule</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          {!groupedMealPlans || Object.keys(groupedMealPlans).length === 0 ? (
            <div className="text-center py-8 text-gray-500">
              <ChefHat className="w-12 h-12 mx-auto mb-4 opacity-50" />
              <p>No meals planned yet. Add your first meal plan above!</p>
            </div>
          ) : (
            <div className="space-y-6">
              {Object.entries(groupedMealPlans)
                .sort(([a], [b]) => new Date(a).getTime() - new Date(b).getTime())
                .map(([date, meals]) => (
                  <div key={date} className="space-y-3">
                    <h3 className="font-semibold text-lg border-b pb-2">
                      {format(new Date(date), "EEEE, MMMM d, yyyy")}
                    </h3>
                    <div className="grid gap-3">
                      {meals
                        .sort((a, b) => {
                          const order = { breakfast: 1, lunch: 2, dinner: 3, snack: 4 };
                          return order[a.mealType as keyof typeof order] - order[b.mealType as keyof typeof order];
                        })
                        .map((meal) => (
                          <div
                            key={meal.id}
                             role="button"
                             tabIndex={0}
                             onClick={() => selectMeal(meal)}
                             onKeyDown={(event) => {
                               if (event.key === "Enter" || event.key === " ") {
                                 event.preventDefault();
                                 selectMeal(meal);
                               }
                             }}
                            className={`p-4 rounded-lg border-2 transition-all ${
                              meal.isCompleted
                                ? "border-vibrant-green bg-green-50"
                                : "border-gray-200 bg-white hover:border-gray-300"
                            }`}
                          >
                            <div className="flex items-center justify-between">
                              <div className="flex items-center space-x-3">
                                <Checkbox
                                  checked={meal.isCompleted || false}
                                   onClick={(event) => {
                                     event.stopPropagation();
                                     selectMeal(meal);
                                   }}
                                  onCheckedChange={() => toggleCompletion(meal)}
                                   disabled={
                                     updateCompletionMutation.isPending ||
                                     deleteMealPlanMutation.isPending
                                   }
                                />
                                <div>
                                  <div className="flex items-center space-x-2">
                                    <h4 className="font-medium">{meal.mealName}</h4>
                                    <Badge className={getMealTypeColor(meal.mealType)}>
                                      {meal.mealType}
                                    </Badge>
                                  </div>
                                  {meal.cookingTime && (
                                    <div className="flex items-center space-x-1 text-sm text-gray-500 mt-1">
                                      <Clock className="w-3 h-3" />
                                      <span>{meal.cookingTime} minutes</span>
                                    </div>
                                  )}
                                  {meal.recipe && (
                                    <p className="text-sm text-gray-600 mt-2 max-w-2xl">
                                      {meal.recipe}
                                    </p>
                                  )}
                                </div>
                              </div>
                               <div className="flex items-center space-x-2">
                                 <Button
                                   type="button"
                                   variant="outline"
                                   size="sm"
                                   aria-label={`Delete ${meal.mealName}`}
                                   onClick={(event) => {
                                     event.stopPropagation();
                                     setMealPendingDeletion(meal);
                                   }}
                                   disabled={deleteMealPlanMutation.isPending}
                                   className="text-red-600 border-red-200 hover:bg-red-50"
                                   data-testid={`button-delete-meal-${meal.id}`}
                                 >
                                   <Trash2 className="w-4 h-4" />
                                 </Button>
                                 {meal.isCompleted && (
                                   <CheckCircle2 className="w-5 h-5 text-vibrant-green" />
                                 )}
                               </div>
                            </div>
                          </div>
                        ))}
                    </div>
                  </div>
                ))}
            </div>
          )}
        </CardContent>
      </Card>

       <AlertDialog
         open={mealPendingDeletion !== null}
         onOpenChange={(open) => {
           if (!open && !deleteMealPlanMutation.isPending) {
             setMealPendingDeletion(null);
           }
         }}
       >
         <AlertDialogContent className="w-[calc(100%-2rem)] max-w-md max-h-[calc(100vh-2rem)] overflow-y-auto rounded-xl border border-slate-200 bg-white p-5 text-slate-900 shadow-2xl sm:p-6">
           <AlertDialogHeader className="space-y-3 text-left">
             <AlertDialogTitle className="text-base leading-6 text-slate-900 sm:text-lg">
               Delete this meal?
             </AlertDialogTitle>
             <AlertDialogDescription className="text-sm leading-5 text-slate-600">
               {mealPendingDeletion
                 ? `Are you sure you want to delete ${mealPendingDeletion.mealName}? This action cannot be undone.`
                 : "This action cannot be undone."}
             </AlertDialogDescription>
           </AlertDialogHeader>
           <AlertDialogFooter className="flex flex-col-reverse gap-3 sm:flex-row sm:justify-end sm:gap-2 sm:space-x-0">
             <AlertDialogCancel
               disabled={deleteMealPlanMutation.isPending}
               className="mt-0 w-full sm:w-auto"
             >
               Cancel
             </AlertDialogCancel>
             <AlertDialogAction
               onClick={(event) => {
                 event.preventDefault();
                 if (mealPendingDeletion) {
                   deleteMealPlanMutation.mutate(mealPendingDeletion.id);
                 }
               }}
               disabled={deleteMealPlanMutation.isPending}
               className="mt-0 w-full bg-red-600 text-white hover:bg-red-700 sm:w-auto"
             >
               {deleteMealPlanMutation.isPending ? "Deleting..." : "Delete"}
             </AlertDialogAction>
           </AlertDialogFooter>
         </AlertDialogContent>
       </AlertDialog>
    </div>
  );
}