const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-rbblko9u.js","assets/index-DBSteVtt.js"])))=>i.map(i=>d[i]);
import{_ as e}from"./index-BMJoZHBZ.js";import{r as p}from"./index-DBSteVtt.js";const _=p("App",{web:()=>e(()=>import("./web-rbblko9u.js"),__vite__mapDeps([0,1])).then(r=>new r.AppWeb)});export{_ as App};
