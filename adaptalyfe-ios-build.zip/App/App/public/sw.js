// Service Worker for SkillBridge mobile app
const CACHE_NAME = 'skillbridge-v1';
const OFFLINE_URL = '/offline.html';

// Files to cache for offline functionality
const CACHE_FILES = [
  '/',
  '/offline.html',
  '/icon-192.png',
  '/icon-512.png',
  '/manifest.json',
  // Add other critical assets here
];

// Install event - cache critical files
self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then((cache) => {
        return cache.addAll(CACHE_FILES);
      })
      .then(() => {
        return self.skipWaiting();
      })
  );
});

// Activate event - clean up old caches
self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((cacheNames) => {
      return Promise.all(
        cacheNames.map((cacheName) => {
          if (cacheName !== CACHE_NAME) {
            return caches.delete(cacheName);
          }
        })
      );
    }).then(() => {
      return self.clients.claim();
    })
  );
});

// Fetch event - serve cached content when offline
self.addEventListener('fetch', (event) => {
  // Handle API requests
  if (event.request.url.includes('/api/')) {
    event.respondWith(
      fetch(event.request)
        .catch(() => {
          // Return offline response for API calls
          return new Response(
            JSON.stringify({ 
              error: 'Offline mode', 
              message: 'This feature requires internet connection' 
            }),
            {
              status: 503,
              headers: { 'Content-Type': 'application/json' }
            }
          );
        })
    );
    return;
  }

  // Handle navigation requests
  if (event.request.mode === 'navigate') {
    event.respondWith(
      fetch(event.request)
        .catch(() => {
          return caches.match(OFFLINE_URL);
        })
    );
    return;
  }

  // Handle other requests
  event.respondWith(
    caches.match(event.request)
      .then((response) => {
        return response || fetch(event.request);
      })
      .catch(() => {
        // Fallback for failed requests
        if (event.request.destination === 'image') {
          return new Response('Image unavailable offline', {
            status: 503,
            headers: { 'Content-Type': 'text/plain' }
          });
        }
      })
  );
});

// Handle notification click events
self.addEventListener('notificationclick', (event) => {
  event.notification.close();

  const action = event.action;
  const tag = event.notification.tag;

  if (action === 'view' || !action) {
    // Open the app to relevant section based on notification tag
    let url = '/';
    
    if (tag.includes('medication')) {
      url = '/pharmacy';
    } else if (tag.includes('appointment')) {
      url = '/medical';
    } else if (tag.includes('task')) {
      url = '/daily-tasks';
    } else if (tag.includes('emergency')) {
      url = '/resources';
    }

    event.waitUntil(
      clients.matchAll().then((clientList) => {
        if (clientList.length > 0) {
          return clientList[0].focus();
        }
        return clients.openWindow(url);
      })
    );
  }
});

// Handle push events (for future push notification implementation)
self.addEventListener('push', (event) => {
  if (!event.data) return;

  const data = event.data.json();
  const options = {
    body: data.body,
    icon: '/icon-192.png',
    badge: '/icon-192.png',
    tag: data.tag || 'adaptalyfe-notification',
    requireInteraction: data.requireInteraction || false,
    actions: [
      { action: 'view', title: 'View' },
      { action: 'dismiss', title: 'Dismiss' }
    ]
  };

  event.waitUntil(
    self.registration.showNotification(data.title, options)
  );
});

// Background sync for offline actions
self.addEventListener('sync', (event) => {
  if (event.tag === 'adaptalyfe-sync') {
    event.waitUntil(syncOfflineData());
  }
});

// Function to sync offline data when connection is restored
async function syncOfflineData() {
  try {
    // Get offline task completions
    const offlineData = await getOfflineData();
    
    if (offlineData && offlineData.length > 0) {
      // Send offline data to server
      for (const item of offlineData) {
        await fetch('/api/sync-offline-data', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify(item)
        });
      }
      
      // Clear offline data after successful sync
      await clearOfflineData();
    }
  } catch (error) {
    console.error('Failed to sync offline data:', error);
  }
}

// Helper function to get offline data from IndexedDB or localStorage
async function getOfflineData() {
  // Implementation would depend on chosen storage method
  // This is a placeholder for the actual implementation
  return [];
}

// Helper function to clear offline data after sync
async function clearOfflineData() {
  // Implementation would depend on chosen storage method
  // This is a placeholder for the actual implementation
}