const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-VbVSg4ow.js","assets/index-DBSteVtt.js"])))=>i.map(i=>d[i]);
import{_ as r}from"./index-BeRZzrlL.js";import{r as o}from"./index-DBSteVtt.js";const i=o("SplashScreen",{web:()=>r(()=>import("./web-VbVSg4ow.js"),__vite__mapDeps([0,1])).then(e=>new e.SplashScreenWeb)});export{i as SplashScreen};
