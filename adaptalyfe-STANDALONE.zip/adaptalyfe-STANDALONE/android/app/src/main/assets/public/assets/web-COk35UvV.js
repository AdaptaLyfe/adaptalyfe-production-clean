import{W as n}from"./index-COP13_Mn.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};
