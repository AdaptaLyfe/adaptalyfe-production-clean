import{W as n}from"./index-DE4Bq0E7.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};
