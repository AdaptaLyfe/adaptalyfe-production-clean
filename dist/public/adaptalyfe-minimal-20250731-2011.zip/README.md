# AdaptaLyfe - Minimal Setup Package

## Quick Start
1. `npm install`
2. `npm run db:push`  
3. `npm run dev`

## Mobile Build
`eas build --platform android`

## Features
- Complete React frontend with 50+ components
- Express.js backend with PostgreSQL
- Mobile app configuration ready
- HIPAA compliant security
- Banking integration setup
- Production ready

This is the minimal package containing essential source code for the complete AdaptaLyfe application.