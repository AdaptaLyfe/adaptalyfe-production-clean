import { Link } from "wouter";
import { Brain, Menu, X } from "lucide-react";
import { useState } from "react";

export default function Navigation() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const navigation = [
    { name: 'Dashboard', href: '/' },
    { name: 'Daily Tasks', href: '/daily-tasks' },
    { name: 'Financial', href: '/financial' },
    { name: 'Medical', href: '/medical' },
    { name: 'Personal Documents', href: '/personal-documents' },
    { name: 'Rewards & Points', href: '/rewards' },
    { name: 'Mood Tracking', href: '/mood-tracking' },
    { name: 'Resources', href: '/resources' },
    { name: 'Caregiver', href: '/caregiver' },
    { name: 'Admin', href: '/admin' },
  ];

  return (
    <nav className="bg-white border-b border-gray-200 sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <Link href="/">
            <div className="flex items-center gap-3 cursor-pointer">
              <div className="bg-gradient-to-r from-blue-600 to-purple-600 p-2 rounded-lg">
                <Brain className="h-6 w-6 text-white" />
              </div>
              <span className="text-xl font-bold text-gray-900">AdaptaLyfe</span>
            </div>
          </Link>
          
          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center gap-4">
            {navigation.map((item) => (
              <Link 
                key={item.name}
                href={item.href} 
                className="text-gray-600 hover:text-gray-900 px-3 py-2 rounded-lg hover:bg-gray-100 transition-colors"
              >
                {item.name}
              </Link>
            ))}
            <span className="text-sm text-purple-600 bg-purple-100 px-3 py-1 rounded-full">
              Demo Mode
            </span>
          </div>

          {/* Mobile menu button */}
          <div className="md:hidden">
            <button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="text-gray-600 hover:text-gray-900 p-2"
            >
              {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <div className="md:hidden border-t border-gray-200 py-4">
            {navigation.map((item) => (
              <Link 
                key={item.name}
                href={item.href} 
                className="block text-gray-600 hover:text-gray-900 px-4 py-2 hover:bg-gray-50"
                onClick={() => setIsMenuOpen(false)}
              >
                {item.name}
              </Link>
            ))}
            <div className="px-4 py-2">
              <span className="text-sm text-purple-600 bg-purple-100 px-3 py-1 rounded-full">
                Demo Mode Active
              </span>
            </div>
          </div>
        )}
      </div>
    </nav>
  );
}