import React, { useEffect, useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { AlertTriangle, RefreshCw } from 'lucide-react';

export function RuntimeErrorHandler() {
  const [showError, setShowError] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');

  useEffect(() => {
    // Listen for the specific runtime error from the Replit plugin
    const handleRuntimeError = (event: any) => {
      if (event.detail && event.detail.message) {
        console.log('Runtime error detected:', event.detail.message);
        // Only show error for actual application errors, not the plugin loop
        if (!event.detail.message.includes('runtime-error-plugin')) {
          setErrorMessage(event.detail.message);
          setShowError(true);
        }
      }
    };

    // Listen for custom events from the runtime error plugin
    window.addEventListener('runtime-error', handleRuntimeError);

    // Also listen for regular errors
    const handleError = (event: ErrorEvent) => {
      console.log('Error event:', event.error);
      if (event.error && !event.error.message.includes('runtime-error-plugin')) {
        setErrorMessage(event.error.message);
        setShowError(true);
      }
    };

    window.addEventListener('error', handleError);

    return () => {
      window.removeEventListener('runtime-error', handleRuntimeError);
      window.removeEventListener('error', handleError);
    };
  }, []);

  if (!showError) {
    return null;
  }

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <Card className="w-full max-w-md">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-red-600">
            <AlertTriangle className="w-5 h-5" />
            Runtime Error Detected
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-gray-600 mb-4">
            The application encountered an error. This is usually temporary and can be resolved by refreshing the page.
          </p>
          
          <details className="mb-4 p-3 bg-gray-50 rounded text-sm">
            <summary className="font-medium cursor-pointer">Error Details</summary>
            <pre className="mt-2 text-xs overflow-auto max-h-32">
              {errorMessage}
            </pre>
          </details>
          
          <div className="flex gap-2">
            <Button
              onClick={() => window.location.reload()}
              className="flex items-center gap-2"
            >
              <RefreshCw className="w-4 h-4" />
              Reload Page
            </Button>
            <Button
              onClick={() => setShowError(false)}
              variant="outline"
            >
              Continue Anyway
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}