import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  SafeAreaView,
  Switch,
  Alert,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';

export default function SettingsScreen() {
  const [notifications, setNotifications] = useState(true);
  const [darkMode, setDarkMode] = useState(false);
  const [autoSync, setAutoSync] = useState(true);
  const [biometric, setBiometric] = useState(false);

  const settingsData = [
    {
      title: 'Notifications',
      sections: [
        {
          title: 'Push Notifications',
          description: 'Receive notifications when someone interacts with your content',
          value: notifications,
          onToggle: setNotifications,
          type: 'switch',
        },
        {
          title: 'Notification Sound',
          description: 'Choose your notification sound',
          onPress: () => Alert.alert('Sound Settings', 'Sound settings coming soon!'),
          type: 'button',
        },
      ],
    },
    {
      title: 'Appearance',
      sections: [
        {
          title: 'Dark Mode',
          description: 'Switch between light and dark themes',
          value: darkMode,
          onToggle: setDarkMode,
          type: 'switch',
        },
        {
          title: 'Text Size',
          description: 'Adjust text size for better readability',
          onPress: () => Alert.alert('Text Size', 'Text size settings coming soon!'),
          type: 'button',
        },
      ],
    },
    {
      title: 'Privacy & Security',
      sections: [
        {
          title: 'Biometric Lock',
          description: 'Use fingerprint or face recognition to unlock app',
          value: biometric,
          onToggle: setBiometric,
          type: 'switch',
        },
        {
          title: 'Privacy Policy',
          description: 'View our privacy policy',
          onPress: () => Alert.alert('Privacy Policy', 'Privacy policy will open here'),
          type: 'button',
        },
        {
          title: 'Terms of Service',
          description: 'View terms of service',
          onPress: () => Alert.alert('Terms', 'Terms of service will open here'),
          type: 'button',
        },
      ],
    },
    {
      title: 'Data & Storage',
      sections: [
        {
          title: 'Auto Sync',
          description: 'Automatically sync data across devices',
          value: autoSync,
          onToggle: setAutoSync,
          type: 'switch',
        },
        {
          title: 'Clear Cache',
          description: 'Free up storage space by clearing cache',
          onPress: () => Alert.alert('Clear Cache', 'Are you sure you want to clear cache?', [
            { text: 'Cancel', style: 'cancel' },
            { text: 'Clear', style: 'destructive' },
          ]),
          type: 'button',
        },
        {
          title: 'Export Data',
          description: 'Download your data',
          onPress: () => Alert.alert('Export Data', 'Data export feature coming soon!'),
          type: 'button',
        },
      ],
    },
    {
      title: 'About',
      sections: [
        {
          title: 'Version',
          description: '1.0.0 (Build 123)',
          type: 'info',
        },
        {
          title: 'Help & Support',
          description: 'Get help or contact support',
          onPress: () => Alert.alert('Support', 'Support center coming soon!'),
          type: 'button',
        },
        {
          title: 'Rate App',
          description: 'Rate us on the app store',
          onPress: () => Alert.alert('Rate App', 'Thank you for using our app!'),
          type: 'button',
        },
      ],
    },
  ];

  const renderSettingItem = (item: any, index: number) => {
    if (item.type === 'switch') {
      return (
        <View key={index} style={styles.settingItem}>
          <View style={styles.settingContent}>
            <Text style={styles.settingTitle}>{item.title}</Text>
            <Text style={styles.settingDescription}>{item.description}</Text>
          </View>
          <Switch
            value={item.value}
            onValueChange={item.onToggle}
            trackColor={{ false: '#e0e0e0', true: '#667eea' }}
            thumbColor={item.value ? '#ffffff' : '#f4f3f4'}
          />
        </View>
      );
    }

    if (item.type === 'button') {
      return (
        <TouchableOpacity
          key={index}
          style={styles.settingItem}
          onPress={item.onPress}
          activeOpacity={0.7}
        >
          <View style={styles.settingContent}>
            <Text style={styles.settingTitle}>{item.title}</Text>
            <Text style={styles.settingDescription}>{item.description}</Text>
          </View>
          <Ionicons name="chevron-forward" size={20} color="#ccc" />
        </TouchableOpacity>
      );
    }

    if (item.type === 'info') {
      return (
        <View key={index} style={styles.settingItem}>
          <View style={styles.settingContent}>
            <Text style={styles.settingTitle}>{item.title}</Text>
            <Text style={styles.settingDescription}>{item.description}</Text>
          </View>
        </View>
      );
    }

    return null;
  };

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Settings</Text>
      </View>

      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        {settingsData.map((group, groupIndex) => (
          <View key={groupIndex} style={styles.settingGroup}>
            <Text style={styles.groupTitle}>{group.title}</Text>
            <View style={styles.groupContainer}>
              {group.sections.map((item, itemIndex) => renderSettingItem(item, itemIndex))}
            </View>
          </View>
        ))}

        <View style={styles.footer}>
          <Text style={styles.footerText}>Mobile Builder Pro</Text>
          <Text style={styles.footerSubtext}>Built with React Native & Expo</Text>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8f9fa',
  },
  header: {
    paddingHorizontal: 20,
    paddingVertical: 16,
    backgroundColor: 'white',
    borderBottomWidth: 1,
    borderBottomColor: '#e0e0e0',
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#333',
  },
  content: {
    flex: 1,
    paddingHorizontal: 20,
  },
  settingGroup: {
    marginTop: 20,
  },
  groupTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#667eea',
    marginBottom: 12,
    textTransform: 'uppercase',
    letterSpacing: 0.5,
  },
  groupContainer: {
    backgroundColor: 'white',
    borderRadius: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  settingItem: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#f0f0f0',
  },
  settingContent: {
    flex: 1,
    marginRight: 16,
  },
  settingTitle: {
    fontSize: 16,
    fontWeight: '500',
    color: '#333',
    marginBottom: 4,
  },
  settingDescription: {
    fontSize: 14,
    color: '#666',
    lineHeight: 18,
  },
  footer: {
    alignItems: 'center',
    paddingVertical: 40,
  },
  footerText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#667eea',
    marginBottom: 4,
  },
  footerSubtext: {
    fontSize: 14,
    color: '#666',
  },
});