// Vercel-optimized API Configuration
export const VERCEL_API_CONFIG = {
  // Use environment variable for production API URL
  baseURL: import.meta.env.VITE_API_URL || '',
  
  // Enable credentials for cross-origin requests
  credentials: 'include' as RequestCredentials,
};

// Environment detection for Vercel deployment
export const isProduction = import.meta.env.PROD;
export const isDevelopment = import.meta.env.DEV;
export const isVercel = typeof window !== 'undefined' && window.location.hostname.includes('vercel.app');

// Auto-configure API based on environment
export const getApiConfig = () => {
  // In development, use current domain
  if (isDevelopment) {
    return {
      baseURL: '',
      credentials: 'include' as RequestCredentials,
    };
  }
  
  // In production, use environment variable or relative URLs
  return {
    baseURL: import.meta.env.VITE_API_URL || '',
    credentials: 'include' as RequestCredentials,
  };
};