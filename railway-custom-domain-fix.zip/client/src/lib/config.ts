// API Configuration for different environments
export const API_CONFIG = {
  // Smart backend detection
  baseURL: typeof window !== 'undefined' && window.location.hostname === 'app.adaptalyfeapp.com' 
    ? '' // Use same domain for Railway
    : 'https://f0feebb6-5db0-4265-92fd-0ed04d7aec9a-00-tpbqabot0m1.spock.replit.dev',
  
  // Enable credentials for cross-origin requests
  credentials: 'include' as RequestCredentials,
};

// Helper function to get full API URL
export function getApiUrl(path: string): string {
  const baseURL = API_CONFIG.baseURL;
  const fullUrl = `${baseURL}${path}`;
  console.log(`🌐 API Call: ${path} → ${fullUrl}`);
  console.log(`🏠 Window hostname: ${typeof window !== 'undefined' ? window.location.hostname : 'server'}`);
  return fullUrl;
}