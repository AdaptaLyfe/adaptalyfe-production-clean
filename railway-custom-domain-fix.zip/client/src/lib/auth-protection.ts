// Adaptalyfe Authentication Protection for React Routes
// This ensures consistent authentication across the React application

export interface AuthUser {
  id: number;
  username: string;
  name: string;
  email: string;
  plan: string;
  isActive: boolean;
  loginMethod?: string;
}

export class AuthProtection {
  static isAuthenticated(): boolean {
    const token = localStorage.getItem('authToken');
    const userData = localStorage.getItem('userData');
    return !!(token && userData);
  }

  static getCurrentUser(): AuthUser | null {
    const userData = localStorage.getItem('userData');
    if (!userData) return null;
    
    try {
      return JSON.parse(userData);
    } catch (error) {
      console.error('Failed to parse user data:', error);
      return null;
    }
  }

  static getAuthToken(): string | null {
    return localStorage.getItem('authToken');
  }

  static requireAuth(): AuthUser {
    if (!this.isAuthenticated()) {
      // Redirect to login if not authenticated
      window.location.href = '/login';
      throw new Error('Authentication required');
    }
    
    const user = this.getCurrentUser();
    if (!user) {
      window.location.href = '/login';
      throw new Error('Invalid user data');
    }
    
    return user;
  }

  static logout(): void {
    localStorage.removeItem('authToken');
    localStorage.removeItem('userData');
    localStorage.removeItem('loginTime');
    window.location.href = '/';
  }

  static hasRole(requiredRole: string): boolean {
    const user = this.getCurrentUser();
    if (!user) return false;
    
    // Demo users have all roles
    if (user.loginMethod === 'demo') return true;
    
    // Check specific roles based on plan or username
    switch (requiredRole) {
      case 'admin':
        return user.username === 'admin' || user.plan === 'premium';
      case 'caregiver':
        return user.username.includes('caregiver') || user.plan !== 'basic';
      default:
        return true;
    }
  }

  static createAuthHeaders(): HeadersInit {
    const token = this.getAuthToken();
    if (!token) return {};
    
    return {
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'application/json'
    };
  }
}

// Hook for React components
export function useAuth() {
  return {
    isAuthenticated: AuthProtection.isAuthenticated(),
    user: AuthProtection.getCurrentUser(),
    token: AuthProtection.getAuthToken(),
    requireAuth: () => AuthProtection.requireAuth(),
    logout: () => AuthProtection.logout(),
    hasRole: (role: string) => AuthProtection.hasRole(role),
    createAuthHeaders: () => AuthProtection.createAuthHeaders()
  };
}